package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TPraiseRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 点赞表(官网APP) Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-03-16
 */

public interface TPraiseRecordMapper extends BaseMapper<TPraiseRecord> {

}

