package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TMessage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-12-03
 */

public interface TMessageMapper extends BaseMapper<TMessage> {

}

