package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TAssoCity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * 省市陶协_市 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-02-14
 */

public interface TAssoCityMapper extends BaseMapper<TAssoCity> {

    void updateAllSort(@Param("proId") Integer proId);
}

