package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TReadHistory;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 阅读历史表(APP) Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-03-14
 */

public interface TReadHistoryMapper extends BaseMapper<TReadHistory> {

}

