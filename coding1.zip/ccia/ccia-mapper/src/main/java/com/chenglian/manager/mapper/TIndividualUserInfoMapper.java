package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TIndividualUserInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */

public interface TIndividualUserInfoMapper extends BaseMapper<TIndividualUserInfo> {

}

