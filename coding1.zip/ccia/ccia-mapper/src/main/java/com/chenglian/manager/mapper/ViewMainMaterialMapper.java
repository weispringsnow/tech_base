package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.ViewMainMaterial;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-12-05
 */

public interface ViewMainMaterialMapper extends BaseMapper<ViewMainMaterial> {

}

