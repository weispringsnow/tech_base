package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TCciaContactInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 公司各大部门联系方式表 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-03-24
 */

public interface TCciaContactInfoMapper extends BaseMapper<TCciaContactInfo> {

}

