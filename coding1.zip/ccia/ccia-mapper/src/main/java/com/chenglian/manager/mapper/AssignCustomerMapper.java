package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.AssignCustomer;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 划分客户记录表 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-02-26
 */

public interface AssignCustomerMapper extends BaseMapper<AssignCustomer> {

}

