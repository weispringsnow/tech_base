package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.ViewBrandName;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-26
 */

public interface ViewBrandNameMapper extends BaseMapper<ViewBrandName> {

}

