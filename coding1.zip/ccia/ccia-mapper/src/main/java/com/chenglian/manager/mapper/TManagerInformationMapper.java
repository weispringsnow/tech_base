package com.chenglian.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chenglian.manager.entity.TManagerInformation;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-15
 */

public interface TManagerInformationMapper extends BaseMapper<TManagerInformation> {

    void clearBindCom(@Param("infoId") Integer infoId);

    void updateAllSort(String comSortType);

    void clearEndVip();
}

