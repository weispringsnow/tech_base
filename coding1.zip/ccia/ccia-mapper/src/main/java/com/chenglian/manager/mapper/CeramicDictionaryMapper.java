package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.CeramicDictionary;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 陶瓷词典表 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-12-04
 */

public interface CeramicDictionaryMapper extends BaseMapper<CeramicDictionary> {

}

