package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TContentInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-18
 */

public interface TContentInfoMapper extends BaseMapper<TContentInfo> {

}

