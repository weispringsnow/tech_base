package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TPurchaseInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-12-05
 */

public interface TPurchaseInfoMapper extends BaseMapper<TPurchaseInfo> {

}

