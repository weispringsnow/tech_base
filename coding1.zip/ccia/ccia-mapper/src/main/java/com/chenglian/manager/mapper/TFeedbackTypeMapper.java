package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TFeedbackType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-12-07
 */

public interface TFeedbackTypeMapper extends BaseMapper<TFeedbackType> {

}

