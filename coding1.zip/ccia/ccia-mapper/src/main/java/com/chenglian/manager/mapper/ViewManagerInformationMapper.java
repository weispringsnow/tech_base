package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.ViewManagerInformation;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-28
 */

public interface ViewManagerInformationMapper extends BaseMapper<ViewManagerInformation> {

}

