package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.Bookstore;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 陶瓷书店表 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-23
 */

public interface BookstoreMapper extends BaseMapper<Bookstore> {

}

