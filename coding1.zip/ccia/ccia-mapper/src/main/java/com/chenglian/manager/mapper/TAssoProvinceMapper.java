package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TAssoProvince;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 省市陶协省 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-02-14
 */

public interface TAssoProvinceMapper extends BaseMapper<TAssoProvince> {

    void updateAllSort();

}

