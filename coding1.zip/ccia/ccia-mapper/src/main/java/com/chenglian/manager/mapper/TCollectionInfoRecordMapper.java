package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TCollectionInfoRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户收藏快讯文章表(APP) Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-03-13
 */

public interface TCollectionInfoRecordMapper extends BaseMapper<TCollectionInfoRecord> {

}

