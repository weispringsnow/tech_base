package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TProducts;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-29
 */

public interface TProductsMapper extends BaseMapper<TProducts> {

}

