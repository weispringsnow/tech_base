package com.chenglian.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chenglian.manager.entity.TBackManage;

/**
 * <p>
 * 后台部门管理字典表 Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-21
 */

public interface TBackManageMapper extends BaseMapper<TBackManage> {
    int updateAllSort();
}

