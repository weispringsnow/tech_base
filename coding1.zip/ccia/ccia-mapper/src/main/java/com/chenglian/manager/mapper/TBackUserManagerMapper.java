package com.chenglian.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chenglian.manager.entity.TBackUserManager;
import com.chenglian.manager.entity.TBackUserManagerView;

/**
 * <p>
 * 后台用户管理表 Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-21
 */

public interface TBackUserManagerMapper extends BaseMapper<TBackUserManager> {
    TBackUserManagerView getBackUserRightToSaveSession(TBackUserManager tBackUserManager);
}

