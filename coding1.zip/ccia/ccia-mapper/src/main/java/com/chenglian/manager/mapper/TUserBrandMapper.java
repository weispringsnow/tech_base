package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TUserBrand;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-12-04
 */

public interface TUserBrandMapper extends BaseMapper<TUserBrand> {

}

