package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TManagerChannel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-14
 */

public interface TManagerChannelMapper extends BaseMapper<TManagerChannel> {

    int updateAllSort();
}

