package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.ViewTypeRecommendManagement;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-12-12
 */

public interface ViewTypeRecommendManagementMapper extends BaseMapper<ViewTypeRecommendManagement> {

}

