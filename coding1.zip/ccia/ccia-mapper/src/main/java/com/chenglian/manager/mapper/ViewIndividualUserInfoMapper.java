package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.ViewIndividualUserInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */

public interface ViewIndividualUserInfoMapper extends BaseMapper<ViewIndividualUserInfo> {

}

