package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TManagerCatalog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-14
 */

public interface TManagerCatalogMapper extends BaseMapper<TManagerCatalog> {

}

