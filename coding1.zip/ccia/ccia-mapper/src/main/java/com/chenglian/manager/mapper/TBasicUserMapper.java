package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TBasicUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */

public interface TBasicUserMapper extends BaseMapper<TBasicUser> {

	int isHadValidLog(@Param("iBuiIdentifier") Integer iBuiIdentifier, @Param("iRiIdentifier") Integer iRiIdentifier);

}

