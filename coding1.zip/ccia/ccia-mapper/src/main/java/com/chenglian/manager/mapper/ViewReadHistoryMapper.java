package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.ViewReadHistory;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-03-14
 */

public interface ViewReadHistoryMapper extends BaseMapper<ViewReadHistory> {

}

