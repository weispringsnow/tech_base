package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.IBrowseMagazineRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 会刊浏览记录表(官网APP) Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-03-18
 */

public interface IBrowseMagazineRecordMapper extends BaseMapper<IBrowseMagazineRecord> {

}

