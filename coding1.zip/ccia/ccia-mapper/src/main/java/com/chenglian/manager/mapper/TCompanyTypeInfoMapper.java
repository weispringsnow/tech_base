package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TCompanyTypeInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-29
 */

public interface TCompanyTypeInfoMapper extends BaseMapper<TCompanyTypeInfo> {

}

