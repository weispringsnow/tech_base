package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.MarketCase;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 陶瓷营销-营销案例表 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-22
 */

public interface MarketCaseMapper extends BaseMapper<MarketCase> {

}

