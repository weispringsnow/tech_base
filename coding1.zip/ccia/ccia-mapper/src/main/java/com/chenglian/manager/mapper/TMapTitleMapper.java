package com.chenglian.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chenglian.manager.entity.TMapTitle;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author zxq
 * @since 2019-11-27
 */

public interface TMapTitleMapper extends BaseMapper<TMapTitle> {

}

