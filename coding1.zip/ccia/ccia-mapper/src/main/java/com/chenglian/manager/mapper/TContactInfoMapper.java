package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TContactInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-26
 */

public interface TContactInfoMapper extends BaseMapper<TContactInfo> {

}

