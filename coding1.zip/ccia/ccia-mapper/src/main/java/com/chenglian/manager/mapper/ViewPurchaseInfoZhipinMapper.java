package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.ViewPurchaseInfoZhipin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-12-10
 */

public interface ViewPurchaseInfoZhipinMapper extends BaseMapper<ViewPurchaseInfoZhipin> {

}

