package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TBrandInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-15
 */

public interface TBrandInfoMapper extends BaseMapper<TBrandInfo> {

    int countTypeRank(@Param("iGfIdentifier") Integer iGfIdentifier);

    void updateAllSort(@Param("iGfIdentifier") Integer iGfIdentifier);
}

