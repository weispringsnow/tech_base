package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TAskJoin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-12-06
 */

public interface TAskJoinMapper extends BaseMapper<TAskJoin> {

}

