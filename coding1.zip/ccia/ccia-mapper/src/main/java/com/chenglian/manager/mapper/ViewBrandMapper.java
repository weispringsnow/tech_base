package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.ViewBrand;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-12-04
 */

public interface ViewBrandMapper extends BaseMapper<ViewBrand> {

}

