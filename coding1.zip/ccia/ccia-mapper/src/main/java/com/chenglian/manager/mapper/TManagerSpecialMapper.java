package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TManagerSpecial;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-18
 */

public interface TManagerSpecialMapper extends BaseMapper<TManagerSpecial> {

    /**
     * 获取专题文章数目
     *
     * @param iScIdentifier
     * @return
     */
    int getNumberSpecialArticles(@Param("iScIdentifier") Integer iScIdentifier);

    /**
     * 获取专题资讯数目
     * @param iScIdentifier
     * @return
     */
    int getNumberSpecialInfos(@Param("iScIdentifier") Integer iScIdentifier);
}

