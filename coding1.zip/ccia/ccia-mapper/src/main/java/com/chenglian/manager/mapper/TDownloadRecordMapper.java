package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TDownloadRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 下载记录表 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-03-18
 */

public interface TDownloadRecordMapper extends BaseMapper<TDownloadRecord> {

}

