package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TUserInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */

public interface TUserInfoMapper extends BaseMapper<TUserInfo> {
    int timerSetGGZY(@Param(value = "iRiIdentifier") Integer iRiIdentifier);

    int timerSetGGZYForPerson(@Param(value = "iRiIdentifier") Integer iRiIdentifier);

    int countTypeRank(@Param("sortType") String sortType);

    void updateAllSort(String sortType);

    List<TUserInfo> selectWillChange();

}

