package com.chenglian.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chenglian.manager.entity.TAssoNews;

/**
 * <p>
 * 省市陶协新闻 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-02-15
 */

public interface TAssoNewsMapper extends BaseMapper<TAssoNews> {

    void updateAllSort(TAssoNews model);

}

