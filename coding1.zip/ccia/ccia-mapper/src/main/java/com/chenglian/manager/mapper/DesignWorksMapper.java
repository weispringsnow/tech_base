package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.DesignWorks;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 陶瓷设计作品表 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-21
 */

public interface DesignWorksMapper extends BaseMapper<DesignWorks> {

}

