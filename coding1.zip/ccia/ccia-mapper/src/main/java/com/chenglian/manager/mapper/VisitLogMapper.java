package com.chenglian.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chenglian.manager.entity.VisitLog;

/**
 * <p>
 * 访问统计表 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-02-27
 */

public interface VisitLogMapper extends BaseMapper<VisitLog> {

    int countLogs(Integer id);
}

