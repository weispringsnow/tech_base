package com.chenglian.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chenglian.manager.entity.ViewUserInfoManager;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */

public interface ViewUserInfoManagerMapper extends BaseMapper<ViewUserInfoManager> {
    List<ViewUserInfoManager> exportCompanyInfoXls(@Param("ids") List<Integer> ids);
}

