package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.MessageFeedback;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 信息反馈表 message_feedback Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-22
 */

public interface MessageFeedbackMapper extends BaseMapper<MessageFeedback> {

}

