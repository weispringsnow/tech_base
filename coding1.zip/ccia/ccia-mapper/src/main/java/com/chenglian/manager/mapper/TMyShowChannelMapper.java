package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TMyShowChannel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-03-17
 */

public interface TMyShowChannelMapper extends BaseMapper<TMyShowChannel> {

}

