package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.ColumnDescription;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 栏目简介表 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-21
 */

public interface ColumnDescriptionMapper extends BaseMapper<ColumnDescription> {

}

