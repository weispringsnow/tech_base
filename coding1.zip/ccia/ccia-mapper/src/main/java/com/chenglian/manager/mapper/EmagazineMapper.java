package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.Emagazine;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-03-03
 */

public interface EmagazineMapper extends BaseMapper<Emagazine> {

}

