package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TManagerIndexMap;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-01-17
 */

public interface TManagerIndexMapMapper extends BaseMapper<TManagerIndexMap> {

}

