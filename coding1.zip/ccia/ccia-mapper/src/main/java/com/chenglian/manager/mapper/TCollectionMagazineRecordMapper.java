package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.TCollectionMagazineRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 会刊收藏表(官网APP) Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2020-03-18
 */

public interface TCollectionMagazineRecordMapper extends BaseMapper<TCollectionMagazineRecord> {

}

