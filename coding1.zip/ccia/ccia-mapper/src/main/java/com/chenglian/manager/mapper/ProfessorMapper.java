package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.Professor;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 陶瓷问诊-专家表 Mapper 接口
 * </p>
 *
 * @author wla
 * @since 2019-11-22
 */

public interface ProfessorMapper extends BaseMapper<Professor> {

}

