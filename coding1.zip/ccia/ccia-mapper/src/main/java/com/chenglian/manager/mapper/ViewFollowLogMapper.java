package com.chenglian.manager.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.chenglian.manager.entity.TrackingStatistics;
import com.chenglian.manager.entity.ViewFollowLog;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author weicx
 * @since 2019-12-02
 */

public interface ViewFollowLogMapper extends BaseMapper<ViewFollowLog> {
    List<TrackingStatistics> trackingStatistics(@Param(value = "adminId") Integer adminId, @Param(value = "sDate") String sDate, @Param(value = "eDate") String eDate);
    List<TrackingStatistics> trackingStatisticsByType(@Param(value = "adminId") Integer adminId, @Param(value = "sDate") String sDate, @Param(value = "eDate") String eDate);
}

