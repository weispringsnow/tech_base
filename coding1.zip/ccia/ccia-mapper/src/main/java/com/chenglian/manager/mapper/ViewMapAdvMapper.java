package com.chenglian.manager.mapper;

import com.chenglian.manager.entity.ViewMapAdv;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author zxq
 * @since 2019-11-30
 */

public interface ViewMapAdvMapper extends BaseMapper<ViewMapAdv> {

}

