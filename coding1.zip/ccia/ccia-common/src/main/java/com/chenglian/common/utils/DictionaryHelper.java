package com.chenglian.common.utils;

import java.util.Dictionary;
import java.util.Hashtable;

/**
 * @author ：yc
 * @date ：Created in 2019/9/25 10:43
 * @description ：通用调用类
 */
public class DictionaryHelper {

    /// <summary>
    /// 邮寄管理 地图标题分类
    /// </summary>
    /// <returns></returns>
    public static Dictionary<Integer, String> MapType()
    {
        Dictionary<Integer, String> tempList = new Hashtable<>();
        tempList.put(0, "-请选择-");
        tempList.put(1, "中国冶金辅料企业分布地图");
        tempList.put(2, "中国钢铁企业分布地图");
        return tempList;
    }
}
