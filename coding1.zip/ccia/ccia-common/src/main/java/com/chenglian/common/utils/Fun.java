package com.chenglian.common.utils;

import com.alibaba.fastjson.JSONObject;
import com.chenglian.common.constant.SessionKey;
import com.chenglian.manager.entity.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.*;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Fun {
    private static final Logger logger = LoggerFactory.getLogger(Fun.class);

    public static String getIP() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

    public static String getRealIP() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if (attributes == null) {
            logger.info("Fun: getRealIP获取attributes失败...");
            return null;
        }
        HttpServletRequest request = attributes.getRequest();
        String ip = request.getHeader("x-forwarded-for");
        // 多次反向代理后会有多个ip值，第一个ip才是真实ip
        if (StringUtils.isNotBlank(ip)) {
            if (ip.contains(","))
                ip = ip.split(",")[0];
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }

    public static boolean authority(String authValues) {

        try {
            String[] authArray = authValues.trim().split(",");
            int channel = NumberUtils.toInt(authArray[0].trim()), column = NumberUtils
                    .toInt(authArray[1].trim()), handle = NumberUtils.toInt(authArray[2].trim());
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder
                    .getRequestAttributes();
            HttpServletRequest request = attributes.getRequest();
            String qx = (String) request.getSession().getAttribute("role");
            if (StringUtils.isNotBlank(qx)) {
                String[] temp = qx.split("\\|");
                if (temp.length >= channel) {
                    qx = temp[channel - 1];
                    temp = qx.split(",");
                    if (temp.length >= column) {
                        return temp[column - 1].toCharArray()[handle - 1] == '1';
                    }
                }
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean authority(String qx, String channelStr, String handleStr, String columnStr) {

        try {
            int channel = Integer.valueOf(channelStr.trim()), handle = Integer
                    .valueOf(handleStr.trim()), column = Integer.valueOf(columnStr.trim());
            if (StringUtils.isNotBlank(qx)) {
                String[] temp = qx.split("\\|");
                if (temp.length >= channel) {
                    qx = temp[channel - 1];
                    temp = qx.split(",");
                    if (temp.length >= column) {
                        return temp[column - 1].toCharArray()[handle - 1] == '1';
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * 是否是Ajax异步请求
     */
    public static boolean isAjaxRequest(HttpServletRequest request) {

        //判断是否为ajax请求，默认不是
        boolean isAjax = false;

        if (request.getHeader("x-requested-with") != null && request.getHeader("x-requested-with")
                .equalsIgnoreCase("XMLHttpRequest"))
            isAjax = true;
        {
            return isAjax;
        }
    }

    public static void resposeWrite(HttpServletResponse response, String content) {
        try {
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.write(content);
            out.flush();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void resposeWrite(HttpServletResponse response, JsonModel2 jsonModel) {
        try {
            response.setContentType("application/json;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.write(JSONObject.toJSONString(jsonModel));
            out.flush();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void resposeWrite(HttpServletResponse response, JsonModel jsonModel) {
        try {
            response.setContentType("application/json;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.write(JSONObject.toJSONString(jsonModel));
            out.flush();
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 参数拼接传回后台
     */

    public static String getRequestParams() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        Enumeration<String> enu = request.getParameterNames();
        String paramPairs = "";
        while (enu.hasMoreElements()) {
            String name = enu.nextElement();
            String value = request.getParameter(name);
            if (!name.equals("p")) {
                if (enu.hasMoreElements()) {
                    paramPairs = paramPairs + (name + "=" + value) + "&";
                } else {
                    paramPairs = paramPairs + (name + "=" + value);
                }
            }
        }
        return paramPairs;
    }

    /**
     * 将空值设为0
     */
    public static Integer nvl(Integer object) {
        if (object != null) {
            return object;
        } else {
            return 0;
        }
    }

    /**
     * 正则表达式
     *
     * @param mobile
     * @return
     */
    // 校验是手机号
    public static boolean chkMobile(String mobile) {
        if (mobile == null || mobile.length() != 11) {
            return false;
        }
        String regex = "^0?(13[0-9]|14[5-9]|15[012356789]|166|17[0-8]|18[0-9]|19[89])[0-9]{8}$";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(mobile);
        return m.matches();
    }

    // 校验邮箱
    public static boolean chkMail(String email) {
        String regex = "([\\.a-zA-Z0-9_-]){2,}@([a-zA-Z0-9_-]){2,}(\\.([a-zA-Z0-9]){2,}){1,4}$";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(email);
        return m.matches();
    }

    public static String getUserType(Integer frompage) {
        switch (frompage) {
            case 2:
                return "个人用户";
            case 3:
                return "国际用户";
            default:
                return "企业用户";
        }
    }

    public static String removeHTMLAll(String html) {
        if (StringUtils.isBlank(html)) {
            return "";
        }
        return html.replaceAll("<(.|\n)+?>", "");
    }

    public static String removeHTML(String html) {
        if (StringUtils.isBlank(html))
            return "";
        Pattern p = Pattern.compile("<(?!p|/p|br).+?>", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(html);
        return m.replaceAll("");
    }

    /**
     * 去除标签
     */
    public static String removeHtmlTag(String str) {
        if (StringUtils.isBlank(str))
            return "";
        return str.replaceAll("<[^>]+>", "");
    }

    /**
     * 去除文章中的html标签
     *
     * @return String
     */
    public static String TrimHTML(String s) {
        if (s.isEmpty()) {
            return "";
        }
        String html = s;
        String strText = html.replaceAll("<[^>]+>", "");
        strText = strText.replaceAll("&[^;]+;", "");
        return strText;
    }

    public static boolean isNumeric(String string) {
        if (StringUtils.isBlank(string)) {
            return false;
        }
        return string.matches("-?[0-9]+.*[0-9]*");
    }

    public static boolean isDate(String strDate) {
        Pattern pattern = Pattern.compile(
                "^((\\d{2}(([02468][048])|([13579][26]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])))))|(\\d{2}(([02468][1235679])|([13579][01345789]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?((0?[1-9])|(1[0-9])|(2[0-8]))))))(\\s(((0?[0-9])|([1-2][0-3]))\\:([0-5]?[0-9])((\\s)|(\\:([0-5]?[0-9])))))?$");
        Matcher m = pattern.matcher(strDate);
        return m.matches();
    }

    public static String cutString(String str, int length, boolean removeHtml) {
        if (StringUtils.isNotBlank(str)) {
            if (removeHtml)
                str = removeHTMLAll(str);
            int len = 0, strlength = str.length();
            for (int i = 0; i < strlength; i++) {
                byte[] byte_len = str.substring(i, i + 1).getBytes();
                if (byte_len.length > 1)
                    len += 2;
                else
                    len += 1;
                if (len >= length) {
                    str = str.substring(0, i + 1);
                    if (i + 1 < strlength) {
                        if (byte_len.length > 1)
                            str = str.substring(0, i);
                        else
                            str = str.substring(0, i - 1);
                        str += "…";
                    }
                    break;
                }
            }
        }
        return str;
    }

    public static String cutString(String str, int length) {
        if (StringUtils.isNotBlank(str)) {
            if (str.length() <= length)
                return str;
            return str.substring(0, length) + "…";
        }
        return "";
    }

    /**
     * 截短字符串
     * showLen ：显示长度,英文字符占0.5个显示长度，汉字占1个显示长度
     */
    public static String cutString2(String str, int showLen) {
        if (StringUtils.isNotBlank(str)) {
            //去除标签
            str = removeHtmlTag(str);
            //合并空格
            str = str.replaceAll(" +", "");
            //根据显示长度，计算需要截取的实际长度
            Double len = 0.0;
            Integer i = 0;
            String strSpace = ""; //为了对齐，尾部加一个空格
            for (i = 0; i < str.length(); i++) {
                //是汉字
                String item = str.substring(i, i + 1);
                String regex = "[^\\x00-\\xff]";
                if (item.matches(regex)) {
                    len += 1;
                } else { //说明不是汉字
                    len += 0.5;
                }

                if (len > showLen) {
                    if (len == showLen + 0.5) {  //说明是单数
                        strSpace = ""; //尾部加1个空格
                    }
                    break;
                }
            }

            Integer index = i;  //当前需要截取的真正长度
            //截取字符串
            if (str.length() > index) {
                String str2 = str.substring(0, index);  // .substring(0, index);
                if (str2 != str) {
                    str = str2 + strSpace + "...";
                }
            }
        }
        return str;
    }

    /**
     * 获取全部异常信息
     *
     * @param e
     * @return
     */
    public static String getAllExceptionMsg(Exception e) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        e.printStackTrace(new PrintStream(baos));
        String exceptionMsg = baos.toString();
        logger.error(exceptionMsg);
        return exceptionMsg;
    }

    public static String pathAndQuery(HttpServletRequest request) {
        String url = request.getServletPath();
        if (request.getQueryString() != null) {
            url += "?" + request.getQueryString();
        }
        return url;
    }

    /**
     * 请求路径和参数
     *
     * @return
     */
    public static String pathAndQuery() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String uri = request.getRequestURI();
        Enumeration<String> parameters = request.getParameterNames();
        StringBuilder sb = new StringBuilder();
        while (parameters.hasMoreElements()) {
            String key = parameters.nextElement();
            String keyLower = key.toLowerCase();
            sb.append("&" + key + "=" + request.getParameter(key));
        }
        return uri + sb.toString().replaceFirst("&", "?");
    }

    /**
     * 获取session的值
     *
     * @return boolean
     */
    public static boolean getBooleanSesson(HttpSession session, String sessionName) {
        Object sessionNameObj = session.getAttribute(sessionName);
        return sessionNameObj != null && Boolean.valueOf(sessionNameObj.toString()).equals(true);
    }

    public static boolean getBooleanSesson(String sessionName) {
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        Object sessionNameObj = session.getAttribute(sessionName);
        return sessionNameObj != null && Boolean.valueOf(sessionNameObj.toString()).equals(true);
    }

    /**
     * 获取session的值
     *
     * @return int
     */
    public static int getIntSesson(HttpSession session, String sessionName) {
        Object sessionNameObj = session.getAttribute(sessionName);
        return sessionNameObj != null && Integer.valueOf(sessionNameObj.toString()) > 0 ?
                Integer.valueOf(sessionNameObj.toString()) :
                0;
    }

    public static int getIntSesson(String sessionName) {
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        Object sessionNameObj = session.getAttribute(sessionName);
        return sessionNameObj != null && Integer.valueOf(sessionNameObj.toString()) > 0 ? Integer.valueOf(sessionNameObj.toString()) : 0;
    }

    /**
     * 获取session的值
     *
     * @return String
     */
    public static String getStringSesson(HttpSession session, String sessionName) {
        Object sessionNameObj = session.getAttribute(sessionName);
        return sessionNameObj != null ? sessionNameObj.toString() : "";
    }

    /**
     * 设置cookie
     *
     * @param response
     * @param key
     * @param value
     */
    public static void setCookie(String key, String value, HttpServletResponse response) {
        if (response == null || key == null || value == null) return;
        Cookie cookie = new Cookie(key, value);
        cookie.setPath("/");
        response.addCookie(cookie);
    }

    /**
     * 获取cookie中 int值
     */
    public static int getIntCookie(String key) {
        HttpServletRequest request = getHttpServletRequest();
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                Cookie cookie = cookies[i];
                if (cookie.getName().equals(key)) {
                    String value = cookie.getValue();
                    return value != null && Integer.valueOf(value) > 0 ? Integer.valueOf(value) : 0;
                }
            }
        }
        return 0;
    }

    /**
     * 获取cookie中 String值
     */
    public static String getStringCookie(String key) {
        HttpServletRequest request = getHttpServletRequest();
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (int i = 0; i < cookies.length; i++) {
                Cookie cookie = cookies[i];
                if (cookie.getName().equals(key)) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

    public static int[] toIntArray(String[] stringArray) {
        int[] intArray = new int[stringArray.length];
        for (int i = 0; i < stringArray.length; i++) {
            if (!StringUtils.isNumeric(stringArray[i])) {
                return null;
            }
            intArray[i] = Integer.parseInt(stringArray[i]);
        }
        return intArray;
    }

    public static String urlEncode(String url) {
        String result = "";
        if (null == url) {
            return "";
        }
        try {
            result = URLEncoder.encode(url, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return result;
    }

    public static String weekChinese(Date date, String weekString) {
        Calendar c = new GregorianCalendar();
        c.setTime(date);
        switch (c.get(Calendar.DAY_OF_WEEK)) {
            case 1:
                return weekString + "日";
            case 2:
                return weekString + "一";
            case 3:
                return weekString + "二";
            case 4:
                return weekString + "三";
            case 5:
                return weekString + "四";
            case 6:
                return weekString + "五";
            case 7:
                return weekString + "六";
        }
        return "";
    }

    public static String ignoreCaseReplace(String content, String keyWord, String color) {
        String result = "", replacement = "";
        if (StringUtils.isBlank(keyWord)) {
            result = content;
        } else {
            if (StringUtils.isBlank(content)) {
                return result;
            }
            int wordLength = keyWord.length(), index = -1;
            index = content.toLowerCase().indexOf(keyWord.toLowerCase());
            while (index > -1) {
                System.err.println(11);
                replacement =
                        "<font color='#" + color + "'>" + content.substring(index, index + wordLength) + "</font>";
                result += content.substring(0, index) + replacement;
                content = content.substring(index + keyWord.length());
                index = content.toLowerCase().indexOf(keyWord.toLowerCase());
            }
            result += content;
        }
        return result;
    }

    public static String strvalue(String str, int length, boolean removeHtml, boolean rmSymble) {
        if (StringUtils.isNotBlank(str)) {
            if (removeHtml)
                str = removeHTMLAll(str);
            int len = 0, strlength = str.length();
            for (int i = 0; i < strlength; i++) {
                byte[] byte_len = str.substring(i, i + 1).getBytes();
                if (byte_len.length > 1)
                    len += 2;
                else
                    len += 1;
                if (len >= length) {
                    str = str.substring(0, i + 1);
                    if (i + 1 < strlength) {
                        if (byte_len.length > 1)
                            str = str.substring(0, i);
                        else
                            str = str.substring(0, i - 1);
                        str += "…";
                    }
                    break;
                }
            }
            if (rmSymble) {
                return str.replace("“", "").replace("”", "");
            }
        }
        return str;
    }

    /**
     * 将传入的URL地址美化为完整的网址
     *
     * @param sourceurl
     * @return
     */
    public static String toFullUrl(String sourceurl) {
        if (StringUtils.isNotBlank(sourceurl) && !sourceurl.equals("无")) {
            if (sourceurl.toLowerCase().startsWith("http://") || sourceurl.toLowerCase().startsWith("https://")) {
                return sourceurl;
            } else {
                return "http://" + sourceurl;
            }
        }
        return "";
    }

    /**
     * 右补到len结束
     */
    public static String padRight(String src, int len, char ch) {
        int diff = len - src.length();
        if (diff <= 0) {
            return src;
        }

        char[] charr = new char[len];
        System.arraycopy(src.toCharArray(), 0, charr, 0, src.length());
        for (int i = src.length(); i < len; i++) {
            charr[i] = ch;
        }
        return new String(charr);
    }

    /**
     * 左补到len结束
     */
    public static String padLeft(String src, int len, char ch) {
        int diff = len - src.length();
        if (diff <= 0) {
            return src;
        }

        char[] charr = new char[len];
        System.arraycopy(src.toCharArray(), 0, charr, diff, src.length());
        for (int i = 0; i < diff; i++) {
            charr[i] = ch;
        }
        return new String(charr);
    }

    public static HttpServletRequest getHttpServletRequest() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        return request;
    }

    public static HttpServletResponse getHttpServletResponse() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletResponse response = attributes.getResponse();
        return response;
    }

    public static HttpSession getHttpSession() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        return request.getSession();
    }

    /**
     * 实现传统意义上的四舍五入
     */
    public static String mathRound(Double dou, Integer size) {
        if (dou == null || dou == 0) {
            StringBuffer sb = new StringBuffer("0");
            for (int i = 1; i <= size; i++) {
                if (i == 1) {
                    sb.append(".0");
                } else {
                    sb.append("0");
                }
            }
            return sb.toString();
        }
        BigDecimal b = new BigDecimal(dou);
        return b.setScale(size, BigDecimal.ROUND_HALF_UP).toString();
    }

    /**
     * 实现传统意义上的四舍五入
     */
    public static String mathRound(BigDecimal dou, Integer size) {
        if (dou == null || dou.doubleValue() == 0) {
            StringBuffer sb = new StringBuffer("0");
            for (int i = 1; i <= size; i++) {
                if (i == 1) {
                    sb.append(".0");
                } else {
                    sb.append("0");
                }
            }
            return sb.toString();
        }
        return dou.setScale(size, BigDecimal.ROUND_HALF_UP).toString();
    }

    /**
     * 字符串强制转换成int
     *
     * @param str
     * @return
     */
    public static Integer stringToINt(String str) {
        return NumberUtils.toInt(str);
    }

    public static double stringToDouble(String str) {

        return NumberUtils.toDouble(str);
    }

    /**
     * LocalDateTime转换为Date
     *
     * @param localDateTime
     */
    public static Date localDateTime2Date(LocalDateTime localDateTime) {
        ZonedDateTime zdt = localDateTime.atZone(ZoneId.systemDefault());
        Date date = Date.from(zdt.toInstant());
        return date;
    }

    /**
     * LocalDate转换为Date
     *
     * @param localDate
     */
    public static Date localDateTime2Date(LocalDate localDate) {
        if (null == localDate) {
            return null;
        }
        ZonedDateTime zonedDateTime = localDate.atStartOfDay(ZoneId.systemDefault());
        return Date.from(zonedDateTime.toInstant());
    }

    /**
     * Date转换为LocalDateTime
     *
     * @param date
     */
    public static LocalDateTime date2LocalDateTime(Date date) {
        Instant instant = date.toInstant();
        ZoneId zoneId = ZoneId.systemDefault();
        LocalDateTime localDateTime = instant.atZone(zoneId).toLocalDateTime();
        return localDateTime;
    }

    /**
     * Date转LocalDate
     *
     * @param date
     */
    public static LocalDate date2LocalDate(Date date) {
        if (null == date) {
            return null;
        }
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    public static Integer getNewsType(String newsType) {
        switch (newsType) {
            case "统计数据":
                return 1;
            case "行业资讯":
                return 2;
            case "会议动态":
                return 3;
            case "热点":
                return 4;
            case "公告":
                return 5;
            case "精选好文":
                return 6;
            case "企业新闻":
                return 7;
        }
        return 0;
    }

    public static Integer getIdentity(String identity) {
        switch (identity) {
            case "平台":
                return 0;
            case "用户采购商":
                return 1;
            case "用户供货商":
                return 2;
            case "电子仓":
                return 3;
            case "用户两者都有":
                return 4;
            case "平台用户三者都有":
                return 5;
        }
        return null;
    }

    /**
     * 将中信银行接口返回的xml映射成结果对象
     *
     * @param xml
     * @param responseType
     */
    public static <T> T respXmlToBean(String xml, Class<T> responseType) {
        try {
            //反序列化
            JAXBContext context = JAXBContext.newInstance(responseType);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            System.err.println("响应串:  " + xml);
            StringReader reader = new StringReader(xml);
            return (T) unmarshaller.unmarshal(reader);
        } catch (Exception e) {
            getAllExceptionMsg(e);
            return null;
        }
    }

    /**
     * 将对象生产xml字符串作为请求串发送到中信银行接口
     *
     * @param entity
     */
    public static <T> String requestBeanToXml(T entity) {
        try {

            JAXBContext context = JAXBContext.newInstance(entity.getClass());
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "GBK");
            //marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            StringWriter writer = new StringWriter();
            marshaller.marshal(entity, writer);
            String xmlStr = writer.toString().replace("standalone=\"yes\"", "");
            System.err.println("请求串:  " + xmlStr);
            return xmlStr;
        } catch (Exception e) {
            getAllExceptionMsg(e);
            return null;
        }
    }

    /**
     * 利用时间 yyyyMMddHHmmssSSSS 生成订单号
     */
    public static String newOrderNo(String pro, String last) {
        String id = DateFormatUtils.format(new Date(), "yyyyMMddHHmmssSSSS");
        if (StringUtils.isNotBlank(last))
            return pro + id + last;
        return pro + id;
    }

    /**
     * 字符串空用“--”代替
     *
     * @param str
     * @return
     */
    public static String stringChange(String str) {
        if (StringUtils.isBlank(str))
            return "--";
        return str;
    }

    public static String http(String url) {
        if (StringUtils.isNotBlank(url)) {
            return (url.contains("http://") ? "" : "http://") + url;
        } else {
            return "";
        }
    }

    /**
     * 把decimal 分割成整数部分和小数部门连个字符串。 string[0]：整数部分 string[1]小数部分
     *
     * @param value
     * @param point 小数位
     * @return
     */
    public static String[] spliteDecimal(BigDecimal value, int point) {
        String num = mathRound(value, point);
        String numInt = num.substring(0, num.indexOf('.'));
        String numFloat = num.substring(num.indexOf('.'));
        return new String[]{numInt, numFloat};
    }

    public static int doubleToInt(double value) {
        String num = mathRound(value, 3);
        String numInt = num.substring(0, num.indexOf('.'));
        return NumberUtils.toInt(numInt);
    }

    /**
     * 计算两个时间点之间的天数
     */
    public static long getBetweenDay(LocalDate start, LocalDate end) {
        return end.toEpochDay() - start.toEpochDay();
    }

    /**
     * 计算两个时间点之间的天数
     */
    public static long getBetweenDay(Date start, Date end) {
        if (start == null || end == null) {
            return 0;
        }
        return getBetweenDay(date2LocalDate(start), date2LocalDate(end));
    }

    /**
     * 字符串转为日期
     */
    public static Date getDateFormStrYYMMDD(String text) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date date = null;
        if (StringUtils.isBlank(text)) {
            return null;
        }
        try {
            date = format.parse(text);
        } catch (ParseException e) {
            format = new SimpleDateFormat("yyyy/MM/dd");
            try {
                date = format.parse(text);
            } catch (ParseException e1) {
                format = new SimpleDateFormat("yyyyMMdd");
                try {
                    date = format.parse(text);
                } catch (Exception e2) {
                    logger.error("日期数据格式出错", e);
                }
            }
        }
        return date;
    }

    /**
     * 计算两个时间点之间的月数
     */
    public static int getBetweenMonths(Date start, Date end) {
        if (start == null || end == null) {
            return 0;
        }
        Calendar bef = Calendar.getInstance();
        Calendar aft = Calendar.getInstance();
        bef.setTime(start);
        aft.setTime(end);
        int result = aft.get(Calendar.MONTH) - bef.get(Calendar.MONTH);
        int month = (aft.get(Calendar.YEAR) - bef.get(Calendar.YEAR)) * 12;
        return month + result;
    }

    /**
     * 计算两个时间点之间的月数
     */
    public static int getBetweenMonths(String start, String end) {
        if (StringUtils.isBlank(start) || StringUtils.isBlank(end)) {
            return 0;
        }
        Calendar bef = Calendar.getInstance();
        Calendar aft = Calendar.getInstance();
        bef.setTime(getDateFormStrYYMMDD(start));
        aft.setTime(getDateFormStrYYMMDD(end));
        int result = aft.get(Calendar.MONTH) - bef.get(Calendar.MONTH);
        int month = (aft.get(Calendar.YEAR) - bef.get(Calendar.YEAR)) * 12;
        return month + result;
    }

    /**
     * 获取当前日期
     */
    public static Date getNowDate() {
        return new Date();
    }

    /**
     * Java中将inputstream输入流转换成byte[]字节数组
     */
    public static byte[] toByteArray(InputStream input) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024 * 4];
        int n = 0;
        while (-1 != (n = input.read(buffer))) {
            output.write(buffer, 0, n);
        }
        return output.toByteArray();
    }

    /**
     * 转换为下划线
     *
     * @param camelCaseName
     * @return
     */
    public static String underscoreName(String camelCaseName) {
        StringBuilder result = new StringBuilder();
        if (camelCaseName != null && camelCaseName.length() > 0) {
            result.append(camelCaseName.substring(0, 1).toLowerCase());
            for (int i = 1; i < camelCaseName.length(); i++) {
                char ch = camelCaseName.charAt(i);
                if (Character.isUpperCase(ch)) {
                    result.append("_");
                    result.append(Character.toLowerCase(ch));
                } else {
                    result.append(ch);
                }
            }
        }
        return result.toString();
    }

    /**
     * 转换为驼峰
     *
     * @param underscoreName
     * @return
     */
    public static String camelCaseName(String underscoreName) {
        StringBuilder result = new StringBuilder();
        if (underscoreName != null && underscoreName.length() > 0) {
            boolean flag = false;
            for (int i = 0; i < underscoreName.length(); i++) {
                char ch = underscoreName.charAt(i);
                if ("_".charAt(0) == ch) {
                    flag = true;
                } else {
                    if (flag) {
                        result.append(Character.toUpperCase(ch));
                        flag = false;
                    } else {
                        result.append(ch);
                    }
                }
            }
        }
        return result.toString();
    }

    public static String toBase64String(byte[] byData) {
        try {
            String encode = org.apache.ws.commons.util.Base64.encode(byData);
            return encode;
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
        }
        return "";
    }

    public static String getRandomCode() {
        Random rdm = new Random();
        long code = 100000000000000l + rdm.ints(1000, 9999).findFirst().orElse(1000);
        return (Calendar.getInstance().getTimeInMillis() + code + 621355968000000000L) + "";

    }

    /**
     * 清除session
     */
    public static void managerExit(HttpServletRequest request, HttpServletResponse response) {

        request.getSession().removeAttribute("adminid");
        request.getSession().removeAttribute("adminname");
        request.getSession().removeAttribute("manager");
        request.getSession().removeAttribute("role");
        request.getSession().removeAttribute("dept");
        request.getSession().removeAttribute("super");
        request.getSession().removeAttribute("i_rm_identifier");
        Cookie[] cookies = request.getCookies();
        if (cookies != null && cookies.length > 0) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("CCCLManagerId")) {
                    cookie.setPath("/");
                    cookie.setMaxAge(0);
                    response.addCookie(cookie);
                }
            }
        }
    }

    /**
     * 把以,分隔的字符串转换为list
     *
     * @param str
     * @return
     */
    public static List<String> strToArr(String str) {
        if (str == null) {
            return null;
        }
        String[] strings = str.split(",");
        List<String> res = new ArrayList<>();
        for (String string : strings) {
            if (string != null && !string.equals(""))
                res.add(string);
        }
        return res;
    }

    /**
     * 判断以,分隔的字符串转为集合后是否包含某元素
     *
     * @param str
     * @param strArr
     * @return
     */
    public static boolean strInstrArr(String str, String strArr) {
        if (strArr == null || str == null) {
            return false;
        }
        String[] list = strArr.split(",");
        boolean contains = Arrays.asList(list).contains(str);
        return contains;
    }

    /**
     * 判断以,分隔的字符串转为集合后是否包含某元素
     *
     * @param strArr
     * @param strArr
     * @return
     */
    public static List<String> strToArrSix(String strArr) {
        List<String> list = new ArrayList<>();
        if (strArr == null) {
            strArr = "";
        }
        String[] arr = strArr.split(",");
        for (int i = 0; i < 6; i++) {
            if (i < arr.length)
                list.add(arr[i]);
            else
                list.add("");
        }
        return list;
    }

    /**
     * md5加密
     */
    public static String md5Password(String password) {
        if (StringUtils.isBlank(password)) {
            return null;
        }
        return MD5Util.digest(password);
    }

    /**
     * des加密
     */
    public static String desEncrypt(String password) {
        if (StringUtils.isBlank(password)) {
            return null;
        }
        try {
            return DesUtil.encrypt(password);
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return null;
        }
    }

    /**
     * des解密
     */
    public static String desDecrypt(String password) {
        if (StringUtils.isBlank(password)) {
            return null;
        }
        try {
            return DesUtil.decrypt(password);
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return null;
        }
    }

    public static ViewUserInfoManager getOperatorUserForCompany() {
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        Object o = session.getAttribute(SessionKey.OPERATOR_USER);
        if (o != null) {
            return (ViewUserInfoManager) o;
        }
        return null;
    }

    public static ViewIndividualUserInfo getOperatorUserForPerson() {
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        Object o = session.getAttribute(SessionKey.OPERATOR_USER);
        if (o != null) {
            return (ViewIndividualUserInfo) o;
        }
        return null;
    }

    public static TContactInfo getTContactInfo() {
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        Object o = session.getAttribute(SessionKey.T_CONTACT_INFO);
        if (o != null) {
            return (TContactInfo) o;
        }
        return null;
    }

    public static int getIUserType() {
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        Object o = session.getAttribute(SessionKey.I_USER_TYPE);
        if (o != null) {
            return (int) o;
        }
        return 0;
    }

    /**
     * 前台是否登录
     *
     * @return
     */
    public static boolean isFrontLogin() {
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        Object o = session.getAttribute(SessionKey.OPERATOR_USER);
        return o != null;
    }

    public static boolean isAdminUser() {
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        Object adminid = session.getAttribute("adminid");
        if (adminid != null) {
            return adminid.toString().equals("1");
        }
        return false;
    }

    public static String getSessionOperator() {
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        Object name = session.getAttribute("manager");
        if (name != null) {
            return (String) name;
        }
        return "";
    }

    public static Integer getSessionIRiIdentifier() {
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        Object adminid = session.getAttribute("adminid");
        if (adminid != null) {
            return (Integer) adminid;
        }
        return 0;
    }

    //判读是企业用户吗
    public static boolean isErpUserLogin() {
        return getIUserType() == 2;
    }

    public static String[] getNowMonthStr() {
        String[] strings = new String[3];
        // 获取当月第一天和最后一天
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String firstday, lastday;
        // 获取本月的第一天
        Calendar cale = Calendar.getInstance();
        cale.add(Calendar.MONTH, 0);
        cale.set(Calendar.DAY_OF_MONTH, 1);
        firstday = format.format(cale.getTime());
        // 获取本月的最后一天
        cale = Calendar.getInstance();
        cale.add(Calendar.MONTH, 1);
        cale.set(Calendar.DAY_OF_MONTH, 0);
        lastday = format.format(cale.getTime());
        //获取本月的总天数
        java.util.Calendar cal = java.util.Calendar.getInstance();
        int maxDay = cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH);
        strings[0] = firstday;
        strings[1] = lastday;
        strings[2] = maxDay + "";
        return strings;
    }

    /**
     * 计算两个时间的差值
     *
     * @param dateType
     * @param dateTime1
     * @param dateTime2
     * @return
     */
    public static long dateDiff(String dateType, Date dateTime1, Date dateTime2) {
        long dateDiff = 0;
        try {
            LocalDateTime ts1 = Fun.date2LocalDateTime(dateTime1);
            LocalDateTime ts2 = Fun.date2LocalDateTime(dateTime2);
            long days = ChronoUnit.DAYS.between(ts1, ts2);
            long hours = ChronoUnit.HOURS.between(ts1, ts2);
            long minutes = ChronoUnit.MINUTES.between(ts1, ts2);
            long seconds = ChronoUnit.SECONDS.between(ts1, ts2);
            switch (dateType) {
                case "天":
                    dateDiff = Math.abs(days);
                    break;
                case "时":
                    dateDiff = Math.abs((days * 24) + hours);
                    break;
                case "分":
                    dateDiff = Math.abs((days * 24 * 60) + (hours * 60) + minutes);
                    break;
                case "秒":
                    dateDiff = Math.abs((days * 24 * 60 * 60) + (hours * 60 * 60) + (minutes * 60) + seconds);
                    break;

                default:
                    break;
            }

        } catch (Exception e) {
            //报错后不能执行
            dateDiff = 10000;
        }
        return dateDiff;
    }

    /**
     * 资讯时间展示
     *
     * @param dateTime
     * @return
     */
    public static String showDtTime(Date dateTime) {
        long diff = dateDiff("时", dateTime, new Date());
        if (diff > 24) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            return format.format(dateTime);
        } else if (diff > 1) {
            return diff + "小时前";
        } else {
            return dateDiff("分", dateTime, new Date()) + "分钟前";
        }
    }

    /**
     * 资讯时间展示
     *
     * @param dateTime
     * @return
     */
    public static String showDtTime(Date dateTime, String onlyMD) {
        long diff = dateDiff("时", dateTime, new Date());
        if (diff > 24) {
            SimpleDateFormat format = new SimpleDateFormat("MD".equals(onlyMD) ? "MM-dd" : "yyyy-MM-dd");
            return format.format(dateTime);
        } else if (diff > 1) {
            return diff + "小时前";
        } else {
            return dateDiff("分", dateTime, new Date()) + "分钟前";
        }
    }

    // 从资讯内容获取第一张图片路径设置给封面
    public static void setCoverImgFromContent(TManagerInformation model) {
        // 找到第一个img标签
        String imgReg = "<img.*?src.*?/>";
        Pattern pattern = Pattern.compile(imgReg);
        Matcher matcher = pattern.matcher(model.getNvcContent());
        if (matcher.find()) {
            // 提取img标签中的src
            String imgTagStr = matcher.group(0);
//			System.out.println("11111111111111111111");
            System.out.println(imgTagStr);
            String urlReg = "src=\"([^\"]*)\"";
            Pattern pattern1 = Pattern.compile(urlReg);
            Matcher matcher1 = pattern1.matcher(imgTagStr);
            if (matcher1.find()) {
                // 截取src中的图片全路径
                String urlStr = matcher1.group(0);

//				System.out.println("2222222222222222222222222");
                System.out.println(urlStr);
                String realPath = urlStr.substring(5, urlStr.length() - 1);
                // 放到model中
                model.setNvcImagesArray(realPath);

//				System.out.println("33333333333333333333333333333333333");
                System.out.println(realPath);
            }
        }
    }

    // 是否访问的首页  用来提示首页升级的
    public static boolean isVisitIndex() {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        String url = request.getRequestURI();
        if ("/Home/index".equalsIgnoreCase(url) || "/".equals(url)) {
            return true;
        }
        return false;
    }

    // 填充划分客户记录对象
    public static AssignCustomer fillAssignCustomer(TBasicUser tBasicUser, TUserInfo tUserInfo, Integer oldManager, Integer newManager, boolean isSys) {
        AssignCustomer assignCustomer = new AssignCustomer().setAssignTime(new Date()).setAssignType(isSys ? 2 : 1);
        assignCustomer.setUserId(tBasicUser.getIBuIdentifier()).setUserName(tBasicUser.getNvcName());
        assignCustomer.setCompanyId(tUserInfo.getIUiIdentifier()).setCompanyName(tUserInfo.getNvcCompanyName());
        assignCustomer.setOldManagerId(oldManager).setNewManagerId(newManager).setOperator(isSys ? "系统" : getSessionOperator());
        return assignCustomer;
    }


    /**
     * 前台是否会员登录
     *
     * @return
     */
    public static boolean isFrontLoginVip() {
//        return true;
        if (!isFrontLogin()) {
            return false;
        }
        HttpServletRequest request = getHttpServletRequest();
        HttpSession session = request.getSession();
        if ((Integer) session.getAttribute(SessionKey.I_USER_TYPE) == 1) {
            return false;
        }
        if ((Integer) session.getAttribute(SessionKey.I_USER_TYPE) == 2) {
            ViewUserInfoManager user = (ViewUserInfoManager) session.getAttribute(SessionKey.OPERATOR_USER);
            if (user.getIMemberNumber() > 0) {
                return true;
            }
        }
        return false;
    }

    // 获取IP的省市位置
    public static String getLocationOfIp(String ip) {
        URL url = null;
        URLConnection conn = null;
        String location = "未知";
        if (StringUtils.isBlank(ip)) {
            return "本地";
        }
        if ("127.0.0.1".equals(ip)) {
            return location;
        }
        try {
            // 拼接URL并打开
            url = new URL("http://opendata.baidu.com/api.php?query=" + ip.trim() + "&co=&resource_id=6006&t=1433920989928&ie=utf8&oe=utf-8&format=json");
            conn = url.openConnection();
            // 获取is
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
            String line = null;
            StringBuffer result = new StringBuffer();
            // 读
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            // 关
            reader.close();
            // 提取
            // result: {"status":"0","t":"1433920989928","set_cache_time":"","data":[{"location":"本地局域网","titlecont":"IP地址查询","origip":"172.16.2.35","origipquery":"172.16.2.35","showlamp":"1","showLikeShare":1,"shareImage":1,"ExtendedLocation":"","OriginQuery":"172.16.2.35","tplt":"ip","resourceid":"6006","fetchkey":"172.16.2.35","appinfo":"","role_id":0,"disp_type":0}]}
            location = result.substring(result.indexOf("\"location\":\"") + 12, result.indexOf("\",\"titlecont\""));
        } catch (Exception e) {
            logger.warn("ip:" + ip + "获取位置信息失败");
        }
        return location;
    }

    // 校验图片数字验证码是否正确
    public static boolean checkPicCode(String code) {
        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attributes.getRequest();
        HttpSession session = request.getSession();
        String cnum = session.getAttribute(RandomValidateCodeUtil.RANDOMCODEKEY) == null ? "" : (String) session.getAttribute(RandomValidateCodeUtil.RANDOMCODEKEY);
        if (StringUtils.isNotBlank(code) && code.equals(cnum)) {
            return true;
        }
        return false;
    }

//    public static void main(String[] args) {
//        getLocationOfIp("");
//		TManagerInformation mode = new TManagerInformation();
//		mode.setNvcContent("bkit-text-stroke-width:0px;white-space:normal;word-spacing:0px;\">\n"
//				+ "<img style=\"border-bottom-color:currentColor;border-bottom-style:none;border-bottom-width:0px;border-image-outset:0;border-image-repeat:stretch;border-image-slice:100%;border-image-source:none;border-image-width:1;border-left-color:currentColor;border-left-style:none;border-left-width:0px;border-right-color:currentColor;border-right-style:none;border-right-width:0px;border-top-color:currentColor;border-top-style:none;border-top-width:0px;display:block;margin-bottom:0px;margin-left:auto;margin-right:auto;margin-top:0px;max-width:100%;outline-style:none;padding-bottom:10px;padding-left:0px;padding-right:0px;padding-top:10px;vertical-align:middle;\" alt=\"\" src=\"http://ztx.ccia086.com/Upload/images/20200111141020_3401.png\" /> ");
//		setCoverImgFromContent(mode);
//    }
}

