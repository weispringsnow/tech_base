package com.chenglian.common.utils;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class FileItem {
    private String filePath;//文件最终路径/Upload/ServiceIntroduction/d945347aa63a4406b9fef6ed45c0d75d.jpg
    private String oldName;//文件原始名称oldName.jpg
    private String newName;//文件新名称d945347aa63a4406b9fef6ed45c0d75d.jpg
}
