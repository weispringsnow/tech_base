package com.chenglian.common.utils;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.springframework.http.ResponseEntity;
import sun.misc.BASE64Encoder;

import java.io.*;
import java.net.*;
import java.util.List;
import java.util.Map;

public class BaiDuOcr {
    /**
     * 获取权限token
     * @return
     */
    public static String getAuth() {
        // 官网获取的 API Key 更新为你注册的
        String clientId = "0ddYMfgtVSqcE9qMQxHhZ4Yc";
        // 官网获取的 Secret Key 更新为你注册的
        String clientSecret = "XXXNKZlv1gi60a04pzABadI9KgDbfkRM";
        return getAuth(clientId, clientSecret);
    }

    /**
     * 获取API访问token
     * 该token有一定的有效期，需要自行管理，当失效时需重新获取.
     * @param ak - 百度云官网获取的 API Key
     * @param sk - 百度云官网获取的 Securet Key
     * @return assess_token
     */
    private static String getAuth(String ak, String sk) {
        // 获取token地址
        String authHost = "https://aip.baidubce.com/oauth/2.0/token?";
        String getAccessTokenUrl = authHost
                // 1\. grant_type为固定参数
                + "grant_type=client_credentials"
                // 2\. 官网获取的 API Key
                + "&client_id=" + ak
                // 3\. 官网获取的 Secret Key
                + "&client_secret=" + sk;
        try {
            URL realUrl = new URL(getAccessTokenUrl);
            // 打开和URL之间的连接
            HttpURLConnection connection = (HttpURLConnection) realUrl.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            // 获取所有响应头字段
            Map<String, List<String>> map = connection.getHeaderFields();
            // 遍历所有的响应头字段
            for (String key : map.keySet()) {
                System.err.println(key + "--->" + map.get(key));
            }
            // 定义 BufferedReader输入流来读取URL的响应
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder result = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                result.append(line);
            }
            /**
             * 返回结果示例
             */
            JSONObject jsonObject = JSONObject.parseObject(result.toString());
            return jsonObject.getString("access_token") ;
        } catch (Exception e) {
            System.err.printf("获取token失败！");

        }
        return null;
    }
    /**
     * 将一张本地图片转化成Base64字符串
     * @param imgPath 本地图片地址
     * @return 图片转化base64后再UrlEncode结果
     */
    public static String getImageStrFromPath(String imgPath) {
        InputStream in;
        byte[] data = null;
        // 读取图片字节数组
        try {
            in = new FileInputStream(imgPath);
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 对字节数组Base64编码
        BASE64Encoder encoder = new BASE64Encoder();
        // 返回Base64编码过再URLEncode的字节数组字符串
        return URLEncoder.encode(encoder.encode(data));
    }

    /**
     * 将一张本地图片转化成Base64字符串
     * @param bytes
     * @return 图片转化base64后再UrlEncode结果
     */
    private static String getImageStrFromPath(byte[] bytes) {

        // 对字节数组Base64编码
        BASE64Encoder encoder = new BASE64Encoder();
        // 返回Base64编码过再URLEncode的字节数组字符串
        return URLEncoder.encode(encoder.encode(bytes));
    }

    private static final String POST_URL = "https://aip.baidubce.com/rest/2.0/ocr/v1/general_basic?access_token=" + getAuth();

    /**
     * 识别本地图片的文字
     *
     * @param path 本地图片地址
     * @return 识别结果，为json格式
     * @throws URISyntaxException URI打开异常
     * @throws IOException        io流异常
     */
    public static String getTuStrings(String path) throws URISyntaxException, IOException {
        File file = new File(path);
        if (!file.exists()) {
            throw new NullPointerException("图片不存在");
        }
        String image = getImageStrFromPath(path);
        String param = "image=" + image;
        return getWordsString(post(param));
    }
    /**
     * 识别本地图片的文字
     *
     * @param bytes
     * @return 识别结果，为json格式
     * @throws URISyntaxException URI打开异常
     * @throws IOException        io流异常
     */
    public static String getTuStrings( byte[] bytes) throws URISyntaxException, IOException {

        if (bytes==null) {
            throw new NullPointerException("图片不存在");
        }
        String image = getImageStrFromPath(bytes);
        String param = "image=" + image;
        return getWordsString(post(param));
    }
    /**
     * @param url 图片url
     * @return 识别结果，为json格式
     */
    public static String checkUrl(String url) throws IOException, URISyntaxException {
        String param = "url=" + url;
        return post(param);
    }

    /**
     * 通过传递参数：url和image进行文字识别
     *
     * @param param 区分是url还是image识别
     * @return 识别结果
     * @throws URISyntaxException URI打开异常
     * @throws IOException        IO流异常
     */
    private static String post(String param) throws URISyntaxException, IOException {
        //开始搭建post请求
        RequestConfig globalConfig = RequestConfig.custom().setCookieSpec(CookieSpecs.IGNORE_COOKIES).build();
        CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(globalConfig).build();
        HttpPost post = new HttpPost();
        URI url = new URI(POST_URL);
        post.setURI(url);
        //设置请求头，请求头必须为application/x-www-form-urlencoded，因为是传递一个很长的字符串，不能分段发送
        post.setHeader("Content-Type", "application/x-www-form-urlencoded");
        StringEntity entity = new StringEntity(param);
        post.setEntity(entity);
        HttpResponse response = httpClient.execute(post);

        if (response.getStatusLine().getStatusCode() == 200) {
            String str;
            try {
                /*读取服务器返回过来的json字符串数据*/
                str = EntityUtils.toString(response.getEntity());

                return str;
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }
        return null;
    }

    private static String getWordsString(String str){
        StringBuffer stringBuffer=new StringBuffer();
        JSONObject jsonObject= JSON.parseObject(str);
        JSONArray array=JSONArray.parseArray(jsonObject.getString("words_result"));
        if(CollectionUtils.isNotEmpty(array)){
            for (Object o : array) {
                JSONObject object=(JSONObject)o;
                stringBuffer.append(object.get("words")+"\n");
            }
        }
        return stringBuffer.toString();
    }

    public static void main(String[] args) throws Exception{
         ResponseEntity<byte[]> entityStream = RestTemplateUtil.getInstance("UTF-8").getForEntity("http://172.16.2.88:8888/group1/M00/00/01/rBACWF29AiCAHOM6AAAtzKPi_xE055.png", byte[].class);
        byte[] bytes = entityStream.getBody();
        System.err.println("bytes:"+bytes.length);
        System.out.println(getTuStrings(bytes));
        System.out.println(getTuStrings("C:\\Users\\liming\\Desktop\\TIM图片20191102091945.png"));
    }

}
