package com.chenglian.common.utils;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class ExcelReadUtil {
    private static final Logger logger = LoggerFactory.getLogger(ExcelReadUtil.class);
    // 文件允许格式
    private static String[] allowFiles = {".xls", ".xlsx"};


    /**
     * @Author: yc
     * @Date: 2019-09-26 13:10
     * @Description:
     * @param request 请求
     * @param attributeName 文件名
     * @param columnName 列名
     * @param model 类
     */
    public static <T> List<T> readExcel(HttpServletRequest request, String attributeName, String[] columnName, Class<T> model) {

        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        MultipartFile multipartFile = multipartRequest.getFile(attributeName);
        // 获取文件名
        String extName = multipartFile.getOriginalFilename();
        // 验证文件类型
        if (StringUtils.isEmpty(extName) || !checkFileType(extName)) {
            return null;
        }

        Workbook wb = null;
        List<T> infoList = new ArrayList<>();
        try {
            if (extName.toLowerCase().endsWith(ExcelVersion.V2003.getSuffix())) {
                wb = WorkbookFactory.create(multipartFile.getInputStream());
            } else {
                // 无效后缀名称，这里之能保证excel的后缀名称，不能保证文件类型正确，不过没关系，在创建Workbook的时候会校验文件格式
                throw new IllegalArgumentException("Invalid excel version");
            }
            for (int i = 0; i < wb.getNumberOfSheets(); i++) {
                Sheet sheet = wb.getSheetAt(i);
                int readRowCount = sheet.getPhysicalNumberOfRows();


                // 解析sheet 的行
                for (int j = sheet.getFirstRowNum()+1; j < readRowCount; j++) {
                    Row row = sheet.getRow(j);
                    if (row == null) {
                        continue;
                    }
                    if (row.getFirstCellNum() < 0) {
                        continue;
                    }
                    int readColumnCount = (int) row.getLastCellNum();
                    T info = model.newInstance();
                    // 解析sheet 的列
                    for (int k = 0; k < readColumnCount; k++) {
                        Cell cell = row.getCell(k);
                        Object cellValue = getCellValue(wb, cell);
                        Field field = model.getDeclaredField(columnName[k]);
                        setValue(info,field,cellValue);
                    }
                    infoList.add(info);
                }
            }

        } catch (InvalidFormatException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }

        return infoList;
    }




    private static <T> void setValue(T info, Field field, Object cellValue) throws IllegalAccessException {

        String type= field.getType().getSimpleName();//取得数据类型
        field.setAccessible(true);

        if("int".equalsIgnoreCase(type)||"integer".equalsIgnoreCase(type)){
            if(NumberUtils.isDigits(cellValue.toString())) {
                field.set(info,Integer.valueOf(cellValue.toString()));
            }
            else if (NumberUtils.isParsable(cellValue.toString())){
                field.set(info,NumberUtils.createBigDecimal(cellValue.toString()).intValue());
            }
        }else if("double".equalsIgnoreCase(type)){
            field.set(info,Double.valueOf(cellValue.toString()));
        }else if("String".equalsIgnoreCase(type)){
            String value = cellValue.toString();
            if(cellValue.toString().endsWith(".00")){
                value = cellValue.toString().replace(".00","");
            }
            field.set(info,value);
        }else if("date".equalsIgnoreCase(type)){

            try {
                Date parse = new SimpleDateFormat("yyyy-MM-dd").parse(cellValue.toString());
                field.set(info, parse);

            } catch (ParseException e) {
                try {
                    Date parse = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(cellValue.toString());
                    field.set(info, parse);
                } catch (ParseException ex) {
                    ex.printStackTrace();
                }
            }
        }
}


        /**
         * 读取excel文件里面的内容 支持日期，数字，字符，函数公式，布尔类型
         *
         * @param columnCount
         * @return
         * @throws FileNotFoundException
         * @throws IOException
         */
    public List<ExcelSheetPO> readExcel(HttpServletRequest request, String attributeName, Integer rowCount, Integer columnCount)
            throws FileNotFoundException, IOException {
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        MultipartFile multipartFile = multipartRequest.getFile(attributeName);
        // 根据后缀名称判断excel的版本
        String extName = multipartFile.getOriginalFilename();
//        CommonsMultipartFile cFile = (CommonsMultipartFile) multipartFile;
//        DiskFileItem fileItem = (DiskFileItem)cFile.getFileItem();
//        InputStream inputStream = fileItem.getInputStream();
//        File file=new
        if (!checkFileType(extName)) {
            return null;
        }
        Workbook wb = null;
        if (ExcelVersion.V2003.getSuffix().equals(extName)) {
            wb = new HSSFWorkbook(multipartFile.getInputStream());

        } else if (ExcelVersion.V2007.getSuffix().equals(extName)) {
            wb = new XSSFWorkbook(multipartFile.getInputStream());

        } else {
            // 无效后缀名称，这里之能保证excel的后缀名称，不能保证文件类型正确，不过没关系，在创建Workbook的时候会校验文件格式
            throw new IllegalArgumentException("Invalid excel version");
        }
        // 开始读取数据
        List<ExcelSheetPO> sheetPOs = new ArrayList<>();
        // 解析sheet
        for (int i = 0; i < wb.getNumberOfSheets(); i++) {
            Sheet sheet = wb.getSheetAt(i);
            List<List<Object>> dataList = new ArrayList<>();
            ExcelSheetPO sheetPO = new ExcelSheetPO();
            sheetPO.setSheetName(sheet.getSheetName());
            sheetPO.setDataList(dataList);
            int readRowCount = 0;
            if (rowCount == null || rowCount > sheet.getPhysicalNumberOfRows()) {
                readRowCount = sheet.getPhysicalNumberOfRows();
            } else {
                readRowCount = rowCount;
            }
            // 解析sheet 的行
            for (int j = sheet.getFirstRowNum(); j < readRowCount; j++) {
                Row row = sheet.getRow(j);
                if (row == null) {
                    continue;
                }
                if (row.getFirstCellNum() < 0) {
                    continue;
                }
                int readColumnCount = 0;
                if (columnCount == null || columnCount > row.getLastCellNum()) {
                    readColumnCount = (int) row.getLastCellNum();
                } else {
                    readColumnCount = columnCount;
                }
                List<Object> rowValue = new LinkedList<Object>();
                // 解析sheet 的列
                for (int k = 0; k < readColumnCount; k++) {
                    Cell cell = row.getCell(k);
                    rowValue.add(getCellValue(wb, cell));
                }
                dataList.add(rowValue);
            }
            sheetPOs.add(sheetPO);
        }
        return sheetPOs;
    }

    private static Object getCellValue(Workbook wb, Cell cell) {
        Object columnValue = null;
        if (cell != null) {
            DecimalFormat df = new DecimalFormat("0");// 格式化 number
            // String
            // 字符
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");// 格式化日期字符串
            DecimalFormat nf = new DecimalFormat("0.00");// 格式化数字
            switch (cell.getCellType()) {
                case Cell.CELL_TYPE_STRING:
                    columnValue = cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                    if ("@".equals(cell.getCellStyle().getDataFormatString())) {
                        columnValue = df.format(cell.getNumericCellValue());
                    } else if ("General".equals(cell.getCellStyle().getDataFormatString())) {
                        columnValue = nf.format(cell.getNumericCellValue());
                    } else {
                        columnValue = sdf.format(HSSFDateUtil.getJavaDate(cell.getNumericCellValue()));
                    }
                    break;
                case Cell.CELL_TYPE_BOOLEAN:
                    columnValue = cell.getBooleanCellValue();
                    break;
                case Cell.CELL_TYPE_BLANK:
                    columnValue = "";
                    break;
                case Cell.CELL_TYPE_FORMULA:
                    // 格式单元格
                    FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
                    evaluator.evaluateFormulaCell(cell);
                    CellValue cellValue = evaluator.evaluate(cell);
                    columnValue = cellValue.getNumberValue();
                    break;
                default:
                    columnValue = cell.toString();
            }
        }
        return columnValue;
    }

    /**
     * 文件类型判断
     *
     * @param fileName
     * @return
     */
    private static boolean checkFileType(String fileName) {
        Iterator<String> type = Arrays.asList(allowFiles).iterator();
        while (type.hasNext()) {
            String ext = type.next();
            if (fileName.toLowerCase().endsWith(ext)) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param request
     * @param attributeName
     * @param sheetIndex    = 0, int beginIndex = 0, int headerIndex =
     * @return
     * @throws FileNotFoundException
     * @throws IOException
     */
    public ExcelSheetPO getDataTable(HttpServletRequest request, String attributeName, Integer sheetIndex, Integer beginIndex, Integer headerIndex)
            throws FileNotFoundException, IOException {
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        MultipartFile multipartFile = multipartRequest.getFile(attributeName);
        if (multipartFile == null || multipartFile.getSize() == 0) {
            logger.error("excel文件为空");
            return null;
        }
        // 根据后缀名称判断excel的版本
        String fileName = multipartFile.getOriginalFilename();
        String extName = fileName.substring(fileName.lastIndexOf("."));
        if (!checkFileType(extName)) {
            logger.error("不是excel类型的文件");
            return null;
        }
        Workbook wb = null;
        if (ExcelVersion.V2003.getSuffix().equals(extName)) {
            wb = new HSSFWorkbook(multipartFile.getInputStream());

        } else if (ExcelVersion.V2007.getSuffix().equals(extName)) {
            wb = new XSSFWorkbook(multipartFile.getInputStream());

        } else {
            // 无效后缀名称，这里之能保证excel的后缀名称，不能保证文件类型正确，不过没关系，在创建Workbook的时候会校验文件格式
            logger.error("Invalid excel version");
            return null;
        }
        // 开始读取数据
        // 解析sheet
        Sheet sheet = wb.getSheetAt(sheetIndex);
        Row header = sheet.getRow(headerIndex);
        List<List<Object>> dataList = new ArrayList<>();
        ExcelSheetPO sheetPO = new ExcelSheetPO();
        sheetPO.setSheetName(sheet.getSheetName());
        sheetPO.setDataList(dataList);
        //处理表格头部
        String[] HeadsArr = null;
        int count = 0;
        for (int i = beginIndex; i < header.getLastCellNum(); i++) {
            if (i == beginIndex) {
                HeadsArr = new String[header.getLastCellNum() - beginIndex];
            }
            HeadsArr[count] = "Columns" + i;
            count++;
        }
        sheetPO.setHeaders(HeadsArr);
        //数据
        for (int i = headerIndex + 1; i <= sheet.getLastRowNum(); i++) {
            if (sheet.getRow(i) != null) {
                boolean hasValue = false;
                List<Object> rowValue = new LinkedList<Object>();
                // 解析sheet 的列
                for (int j = beginIndex; j < header.getLastCellNum(); j++) {
                    Cell cell = sheet.getRow(i).getCell(j);
                    Object obj = getCellValueNoDate(wb, cell);
                    if (obj != null && StringUtils.isNotBlank(obj.toString())) hasValue = true;
                    rowValue.add(obj);
                }
                if (hasValue) {
                    dataList.add(rowValue);
                }
            }
        }
        return sheetPO;
    }

    private Object getCellValueNoDate(Workbook wb, Cell cell) {
        Object columnValue = null;
        if (cell != null) {
            DecimalFormat df = new DecimalFormat("0.##");// 格式化 number
            // String
            DecimalFormat nf = new DecimalFormat("0.00");// 格式化数字
            switch (cell.getCellType()) {
                case Cell.CELL_TYPE_STRING:
                    columnValue = cell.getStringCellValue();
                    break;
                case Cell.CELL_TYPE_NUMERIC:
                    columnValue = df.format(cell.getNumericCellValue());
                    break;
                case Cell.CELL_TYPE_BOOLEAN:
                    columnValue = cell.getBooleanCellValue();
                    break;
                case Cell.CELL_TYPE_BLANK:
                    columnValue = "";
                    break;
                case Cell.CELL_TYPE_FORMULA:
                    // 格式单元格
                    FormulaEvaluator evaluator = wb.getCreationHelper().createFormulaEvaluator();
                    evaluator.evaluateFormulaCell(cell);
                    CellValue cellValue = evaluator.evaluate(cell);
                    columnValue = cellValue.getNumberValue();
                    break;
                default:
                    columnValue = cell.toString();
            }
        }
        return columnValue;
    }
}
