package com.chenglian.common.utils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CookieUtil {

    public static void set(HttpServletResponse response, String key, String value) {
        set(response, key, value, 0, "/");
    }

    public static void set(HttpServletResponse response, String key, String value, int adddays) {
        set(response, key, value, adddays, "/");
    }

    public static void set(HttpServletResponse response, String key, String value, int adddays, String path) {
        //添加自动登录的cookie
        Cookie cookie = new Cookie(key, value);
        cookie.setMaxAge(60 * 60 * 24 * adddays);
        cookie.setPath(path);
        response.addCookie(cookie);
    }

    public static String get(HttpServletRequest request, String key) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null && cookies.length > 0) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(key)) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

    public static void remove(HttpServletRequest request, HttpServletResponse response, String key) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null && cookies.length > 0) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(key)) {
                    cookie.setPath("/");
                    cookie.setMaxAge(0);
                    response.addCookie(cookie);
                }
            }
        }
    }
}
