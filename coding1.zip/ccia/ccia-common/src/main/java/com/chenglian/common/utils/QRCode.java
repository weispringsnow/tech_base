package com.chenglian.common.utils;

import com.google.zxing.*;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.OutputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Hashtable;

public class QRCode {

	/**
	 * 生成二维码并输出到response
	 * 
	 * @param content
	 * @param width
	 * @param response
	 */
	public static void Create(String content, Integer width, HttpServletResponse response) {
		String format = "png";
		HashMap<EncodeHintType, Object> hints = new HashMap<>();
		// 编码格式
		hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
		// 纠错等级(此处M为中等)
		hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
		// 图片的边距默认是5
		hints.put(EncodeHintType.MARGIN, 2);
		// 生成二维码
		try {
			BitMatrix bitMatrix = new MultiFormatWriter().encode(content, BarcodeFormat.QR_CODE, width, width, hints);
			OutputStream out = response.getOutputStream();
			MatrixToImageWriter.writeToStream(bitMatrix, format, out);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 读取指定路径或URL的二维码内容
	 * 
	 * @param path
	 * @return
	 */
	public static String Read(String path) {
		try {
			MultiFormatReader formatReader = new MultiFormatReader();
			BufferedImage image = null;
			if (path.toLowerCase().startsWith("http://")) {
				image = ImageIO.read(new URL(path));
			} else {
				image = ImageIO.read(new File(path));
			}
			BinaryBitmap binaryBitmap = new BinaryBitmap(new HybridBinarizer(new BufferedImageLuminanceSource(image)));

			HashMap<DecodeHintType, Object> hints = new HashMap<>();
			// 编码格式
			hints.put(DecodeHintType.CHARACTER_SET, "utf-8");

			Result result = formatReader.decode(binaryBitmap, hints);
			System.out.println("解析结果为：" + result.toString());
			System.out.println("二维码的格式：" + result.getBarcodeFormat());
			return result.getText();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}


	// 编码
	public static void encode(OutputStream stream, String content, int width, int height) {
		try {
			Hashtable<EncodeHintType, Object> hints = new Hashtable<EncodeHintType, Object>();
			hints.put(EncodeHintType.CHARACTER_SET, "utf-8"); // 文字编码。
			hints.put(EncodeHintType.MARGIN, 1);
			BitMatrix byteMatrix = new MultiFormatWriter().encode(content ,BarcodeFormat.QR_CODE, width, height, hints);
			MatrixToImageWriter.writeToStream(byteMatrix, "png", stream);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
