package com.chenglian.common.utils;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.safety.Whitelist;

public class JsoupUtil {
	private static final Whitelist whitelist = Whitelist.relaxed();
	private static final Document.OutputSettings outputSettings = new Document.OutputSettings().prettyPrint(false);
	static {
		whitelist.addAttributes(":all", "style","class");
	}

	public static String clean(String content) {
		if(content==null)
			return null;
		return Jsoup.clean(content, "", whitelist, outputSettings);
	}

}
