package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TDownloadRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 * 下载记录表 服务类
 * </p>
 *
 * @author wla
 * @since 2020-03-18
 */

public interface TDownloadRecordService extends IService<TDownloadRecord> {
    IPage<TDownloadRecord> selectPage(Page<TDownloadRecord> page,TDownloadRecord model);
    List<TDownloadRecord> select(TDownloadRecord model);
    TDownloadRecord selectTopRow(TDownloadRecord model);
    int saveReturnInt(TDownloadRecord model);
    TDownloadRecord select(int id);

}

