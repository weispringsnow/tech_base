package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.ColumnDescription;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 * 栏目简介表 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-21
 */

public interface ColumnDescriptionService extends IService<ColumnDescription> {
    IPage<ColumnDescription> selectPage(Page<ColumnDescription> page,ColumnDescription model);
    int saveReturnInt(ColumnDescription model);
    List<ColumnDescription> select(ColumnDescription model);
    ColumnDescription selectTopRow(ColumnDescription model);
    ColumnDescription select(int id);

    ColumnDescription whichColumn(ColumnDescription model);
}

