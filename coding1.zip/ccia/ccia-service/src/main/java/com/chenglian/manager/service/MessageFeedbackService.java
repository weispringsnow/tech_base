package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.MessageFeedback;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 * 信息反馈表 message_feedback 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-22
 */

public interface MessageFeedbackService extends IService<MessageFeedback> {
    IPage<MessageFeedback> selectPage(Page<MessageFeedback> page,MessageFeedback model);
    int saveReturnInt(MessageFeedback model);
    List<MessageFeedback> select(MessageFeedback model);
    MessageFeedback selectTopRow(MessageFeedback model);
    MessageFeedback select(int id);

}

