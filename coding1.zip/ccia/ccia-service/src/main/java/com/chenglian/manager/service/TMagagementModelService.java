package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TMagagementModel;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */

public interface TMagagementModelService extends IService<TMagagementModel> {
    IPage<TMagagementModel> selectPage(Page<TMagagementModel> page,TMagagementModel model);
    List<TMagagementModel> select(TMagagementModel model);
    TMagagementModel selectTopRow(TMagagementModel model);
    int saveReturnInt(TMagagementModel model);
    TMagagementModel select(int iMmIdentifier);

}

