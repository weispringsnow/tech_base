package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TCompanyAdManage;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-12-09
 */

public interface TCompanyAdManageService extends IService<TCompanyAdManage> {
    IPage<TCompanyAdManage> selectPage(Page<TCompanyAdManage> page,TCompanyAdManage model);
    List<TCompanyAdManage> select(TCompanyAdManage model);
    TCompanyAdManage selectTopRow(TCompanyAdManage model);
    int saveReturnInt(TCompanyAdManage model);
    TCompanyAdManage select(int iAdIdentifier);

}

