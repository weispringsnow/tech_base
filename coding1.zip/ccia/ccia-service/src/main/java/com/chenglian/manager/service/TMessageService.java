package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TMessage;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-12-03
 */

public interface TMessageService extends IService<TMessage> {
    IPage<TMessage> selectPage(Page<TMessage> page,TMessage model);
    List<TMessage> select(TMessage model);
    TMessage selectTopRow(TMessage model);
    int saveReturnInt(TMessage model);
    TMessage select(int iMIdentifier);

}

