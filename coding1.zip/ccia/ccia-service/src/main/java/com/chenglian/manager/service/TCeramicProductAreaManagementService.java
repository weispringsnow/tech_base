package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TCeramicProductAreaManagement;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-12-12
 */

public interface TCeramicProductAreaManagementService extends IService<TCeramicProductAreaManagement> {
    IPage<TCeramicProductAreaManagement> selectPage(Page<TCeramicProductAreaManagement> page,TCeramicProductAreaManagement model);
    List<TCeramicProductAreaManagement> select(TCeramicProductAreaManagement model);
    TCeramicProductAreaManagement selectTopRow(TCeramicProductAreaManagement model);
    int saveReturnInt(TCeramicProductAreaManagement model);
    TCeramicProductAreaManagement select(int iCpamIdentifier);

}

