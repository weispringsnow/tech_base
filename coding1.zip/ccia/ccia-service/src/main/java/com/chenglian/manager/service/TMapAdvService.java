package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TMapAdv;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zxq
 * @since 2019-11-30
 */

public interface TMapAdvService extends IService<TMapAdv> {
    IPage<TMapAdv> selectPage(Page<TMapAdv> page,TMapAdv model);
    int saveReturnInt(TMapAdv model);
    List<TMapAdv> select(TMapAdv model);
    TMapAdv selectTopRow(TMapAdv model);
    TMapAdv select(int iMaIdentifier);

}

