package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TFeedbackType;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2019-12-07
 */

public interface TFeedbackTypeService extends IService<TFeedbackType> {
    IPage<TFeedbackType> selectPage(Page<TFeedbackType> page,TFeedbackType model);
    List<TFeedbackType> select(TFeedbackType model);
    TFeedbackType selectTopRow(TFeedbackType model);
    int saveReturnInt(TFeedbackType model);
    TFeedbackType select(int iFtIdentifier);

}

