package com.chenglian.common.service;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.chenglian.common.entity.FastDfsConfigs;
import com.chenglian.common.utils.FileItem;
import com.chenglian.common.utils.Fun;
import org.apache.commons.lang3.StringUtils;
import org.csource.common.MyException;
import org.csource.fastdfs.ClientGlobal;
import org.csource.fastdfs.StorageClient;
import org.csource.fastdfs.StorageServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;

@Service
public class UploadUtils {
    private static final Logger logger = LoggerFactory.getLogger(UploadUtils.class);

    // 文件允许格式
    private String[] allowFiles = {".rar", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".zip", ".pdf", ".txt", ".mp4", ".rmvb", ".swf", ".wmv", ".gif", ".png", ".jpg", ".jpeg", ".bmp"};
    private String[] allowImages = {".gif", ".jpeg", ".jpg", ".png", ".bmp"};
    @Autowired
    private FastDfsConfigs fastDfsConfigs;

    /**
     * 单个文件上传
     *
     * @param attributeName 页面属性名字
     * @param request
     */
    public String uploadSingleFile(HttpServletRequest request, String attributeName) {
        try {
            if (!(request instanceof MultipartHttpServletRequest)) {
                return null;
            }
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile multipartFile = multipartRequest.getFile(attributeName);
            if (multipartFile != null && multipartFile.getSize() > 0) {
                String fileName = multipartFile.getOriginalFilename();
                String ext = fileName.substring(fileName.lastIndexOf("."));
                //判断是不是文件格式
                if (!checkFileType(fileName)) {
                    return null;
                }
                return uploadFileFastDFS(multipartFile.getBytes(), ext);
            }
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return null;
        }
        return null;
    }

    /**
     * 单个文件上传
     */
    public FileItem uploadSingleFile2(HttpServletRequest request, String attributeName) {
        FileItem fileItem = new FileItem();
        try {
            if (!(request instanceof MultipartHttpServletRequest)) {
                return null;
            }
            List<MultipartFile> filesList = ((MultipartHttpServletRequest) request).getFiles(attributeName);
            if (filesList != null && filesList.size() > 0) {
                MultipartFile multipartFile = filesList.get(0);
                String fileName = multipartFile.getOriginalFilename();
                fileItem.setOldName(fileName);
                String ext = fileName.substring(fileName.lastIndexOf("."));
                //判断是不是文件格式
                if (!checkFileType(fileName)) {
                    return null;
                }
                fileItem.setFilePath(uploadFileFastDFS(multipartFile.getBytes(), ext));
                fileItem.setNewName(fileItem.getFilePath().substring(fileItem.getFilePath().lastIndexOf("/")));
                return fileItem;
            }
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return null;
        }
        return null;
    }

    /**
     * 多个文件上传
     */
    public List<String> uploadSingleFile3(HttpServletRequest request, String attributeName) {
        List<String> fileNameList = new ArrayList<>();
        try {
            List<MultipartFile> filesList = ((MultipartHttpServletRequest) request).getFiles(attributeName);
            for (MultipartFile fileItem : filesList) {
                if (fileItem != null && fileItem.getSize() > 0) {
                    String fileName = fileItem.getOriginalFilename();
                    String ext = fileName.substring(fileName.lastIndexOf("."));
                    //判断是不是文件格式
                    if (!checkFileType(fileName)) {
                        return null;
                    }
                    fileNameList.add(uploadFileFastDFS(fileItem.getBytes(), ext));
                }
            }
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return null;
        }
        return fileNameList;
    }


    /**
     * 单个个图片上传
     */
    public String uploadSingleImg(HttpServletRequest request) {
        List<String> strings = uploadMultiImg(request);
        if (CollectionUtils.isNotEmpty(strings)) {
            return strings.get(0);
        }
        return null;
    }

    /**
     * 多个图片上传
     */
    public List<String> uploadMultiImg(HttpServletRequest request) {
        List<String> fileNameList = new ArrayList<>();
        try {
            if (!(request instanceof MultipartHttpServletRequest)) {
                return null;
            }
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultiValueMap<String, MultipartFile> multiFileMap = multipartRequest.getMultiFileMap();
            if (CollectionUtils.isNotEmpty(multiFileMap)) {
                for (String key : multiFileMap.keySet()) {
                    List<MultipartFile> filesList = multiFileMap.get(key);
                    if (CollectionUtils.isNotEmpty(filesList)) {
                        for (MultipartFile fileItem : filesList) {
                            String fileName = fileItem.getOriginalFilename();
                            String ext = fileName.substring(fileName.lastIndexOf("."));
                            //判断是不是图片格式
                            if (!checkImgType(fileName)) {
                                logger.error("上传文件格式错误");
                                return null;
                            }
                            fileNameList.add(uploadFileFastDFS(fileItem.getBytes(), ext));
                        }
                    }

                }
            }

        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return null;
        }
        return fileNameList;
    }

    /**
     * 多个图片上传
     */
    public List<String> uploadMultiImgNoRequest() {
        HttpServletRequest request = Fun.getHttpServletRequest();
        List<String> fileNameList = new ArrayList<>();
        try {
            if (!(request instanceof MultipartHttpServletRequest)) {
                return null;
            }
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultiValueMap<String, MultipartFile> multiFileMap = multipartRequest.getMultiFileMap();
            if (CollectionUtils.isNotEmpty(multiFileMap)) {
                for (String key : multiFileMap.keySet()) {
                    List<MultipartFile> filesList = multiFileMap.get(key);
                    if (CollectionUtils.isNotEmpty(filesList)) {
                        for (MultipartFile fileItem : filesList) {
                            String fileName = fileItem.getOriginalFilename();
                            String ext = fileName.substring(fileName.lastIndexOf("."));
                            //判断是不是图片格式
                            if (!checkImgType(fileName)) {
                                logger.error("上传文件格式错误");
                                return null;
                            }
                            fileNameList.add(uploadFileFastDFS(fileItem.getBytes(), ext));
                        }
                    }

                }
            }

        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return null;
        }
        return fileNameList;
    }

    /**
     * 文件类型判断
     *
     * @param fileName
     * @return
     */
    private boolean checkFileType(String fileName) {
        Iterator<String> type = Arrays.asList(this.allowFiles).iterator();
        while (type.hasNext()) {
            String ext = type.next();
            if (fileName.toLowerCase().endsWith(ext)) {
                return true;
            }
        }
        return false;
    }

    private boolean checkImgType(String fileName) {
        Iterator<String> type = Arrays.asList(this.allowImages).iterator();
        while (type.hasNext()) {
            String ext = type.next();
            if (fileName.toLowerCase().endsWith(ext)) {
                return true;
            }
        }
        return false;
    }

    public void Download(String path, String baseUploadPath, String name, HttpServletResponse response) throws Exception {
        if (StringUtils.isNotBlank(path)) {
            StorageClient storageClient = new StorageClient(null, new StorageServer(fastDfsConfigs.getStorageServiceIp(), fastDfsConfigs.getStorageServicePort(), fastDfsConfigs.getStorageServicePathIndex()));
            InputStream in = null;
            if (path.startsWith(fastDfsConfigs.getFastdfsUrl())) {
                path = path.substring(fastDfsConfigs.getFastdfsUrl().length() + 1);
                String groupName = path.substring(0, path.indexOf("/")), remoteFileName = path.substring(path.indexOf("/") + 1);
                byte[] fileByte = storageClient.download_file(groupName, remoteFileName);
                in = new ByteArrayInputStream(fileByte);
            } else {
                in = new FileInputStream(new File(baseUploadPath + path));
            }
            String fileName = new String(name.getBytes(), "ISO-8859-1");
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
            OutputStream out = response.getOutputStream();
            byte[] content = new byte[1024];
            int length = 0;
            while ((length = in.read(content)) != -1) {
                out.write(content, 0, length);
            }
            out.flush();
            out.close();
            in.close();
        }
    }

    public String uploadFileFastDFS(byte[] byteFile, String ext_file) {
        try {
            StorageClient storageClient = new StorageClient(null, new StorageServer(fastDfsConfigs.getStorageServiceIp(), fastDfsConfigs.getStorageServicePort(), fastDfsConfigs.getStorageServicePathIndex()));
            logger.info("文件服务器客户端连接服务器成功！！！");
            String[] strings = storageClient.upload_file(byteFile, ext_file.replace(".", ""), null);
            StringBuffer sbPath = new StringBuffer();
            sbPath.append(fastDfsConfigs.getFastdfsUrl());
            sbPath.append("/");
            sbPath.append(StringUtils.join(strings, "/"));
            logger.info(sbPath.toString());
            return sbPath.toString();
        } catch (IOException | MyException e) {
            try {
                StorageClient storageClient = new StorageClient(null, new StorageServer(fastDfsConfigs.getStorageServiceIp(), fastDfsConfigs.getStorageServicePort(), fastDfsConfigs.getStorageServicePathIndex()));
                logger.info("文件服务器客户端连接服务器成功！！！");
                String[] strings = storageClient.upload_file(byteFile, ext_file.replace(".", ""), null);
                StringBuffer sbPath = new StringBuffer();
                sbPath.append(fastDfsConfigs.getFastdfsUrl());
                sbPath.append("/");
                sbPath.append(StringUtils.join(strings, "/"));
                logger.info(sbPath.toString());
                return sbPath.toString();
            } catch (Exception e1) {
                logger.info("文件服务器客户端连接服务器失败！！！");
                Fun.getAllExceptionMsg(e1);
                return null;
            }
        }
    }

    /**
     * 文件服务器客户端初始化
     */
    @PostConstruct
    public void initMethod() {
        try {
            Properties properties = new Properties();
            properties.setProperty("fastdfs.connect_timeout_in_seconds", fastDfsConfigs.getConnect_timeout_in_second());
            properties.setProperty("fastdfs.network_timeout_in_seconds", fastDfsConfigs.getNetwork_timeout_in_seconds());
            properties.setProperty("fastdfs.charset", fastDfsConfigs.getCharset());
            properties.setProperty("fastdfs.http_tracker_http_port", fastDfsConfigs.getHttp_tracker_http_port());
            properties.setProperty("fastdfs.http_anti_steal_token", fastDfsConfigs.getHttp_anti_steal_token());
            properties.setProperty("fastdfs.tracker_servers", fastDfsConfigs.getTracker_servers());
            ClientGlobal.initByProperties(properties);
            logger.info("文件服务器客户端初始化成功！！！");
        } catch (Exception e) {
            logger.info("文件服务器客户端初始化失败！！！");
            Fun.getAllExceptionMsg(e);
        }
    }
}
