package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.CeramicDictionary;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 * 陶瓷词典表 服务类
 * </p>
 *
 * @author wla
 * @since 2019-12-04
 */

public interface CeramicDictionaryService extends IService<CeramicDictionary> {
    IPage<CeramicDictionary> selectPage(Page<CeramicDictionary> page,CeramicDictionary model);
    List<CeramicDictionary> select(CeramicDictionary model);
    CeramicDictionary selectTopRow(CeramicDictionary model);
    int saveReturnInt(CeramicDictionary model);
    CeramicDictionary select(int id);
}

