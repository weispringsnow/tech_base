package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TAskJoin;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2019-12-06
 */

public interface TAskJoinService extends IService<TAskJoin> {
    IPage<TAskJoin> selectPage(Page<TAskJoin> page,TAskJoin model);
    List<TAskJoin> select(TAskJoin model);
    TAskJoin selectTopRow(TAskJoin model);
    int saveReturnInt(TAskJoin model);
    TAskJoin select(int iAjIdentifier);

}

