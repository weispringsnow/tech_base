package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.CCIAInfo;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author weicx
 * @since 2019-12-13
 */

public interface CCIAInfoService extends IService<CCIAInfo> {
    IPage<CCIAInfo> selectPage(Page<CCIAInfo> page, CCIAInfo model);

    List<CCIAInfo> select(CCIAInfo model);

    CCIAInfo selectTopRow(CCIAInfo model);

    int saveReturnInt(CCIAInfo model);

    CCIAInfo select(int Identifier);

    List<CCIAInfo> getTopNum(Integer num);

    List<CCIAInfo> getTopPic(Integer num);

}

