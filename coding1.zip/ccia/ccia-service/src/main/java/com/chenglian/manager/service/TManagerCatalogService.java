package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TManagerCatalog;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-11-14
 */

public interface TManagerCatalogService extends IService<TManagerCatalog> {
    IPage<TManagerCatalog> selectPage(Page<TManagerCatalog> page,TManagerCatalog model);
    int saveReturnInt(TManagerCatalog model);
    List<TManagerCatalog> select(TManagerCatalog model);
    TManagerCatalog selectTopRow(TManagerCatalog model);
    TManagerCatalog select(int iMcIdentifier);

}

