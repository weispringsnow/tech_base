package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TFollowLog;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-12-02
 */

public interface TFollowLogService extends IService<TFollowLog> {
    IPage<TFollowLog> selectPage(Page<TFollowLog> page,TFollowLog model);
    List<TFollowLog> select(TFollowLog model);
    TFollowLog selectTopRow(TFollowLog model);
    int saveReturnInt(TFollowLog model);
    TFollowLog select(int iFlIdentifier);

}

