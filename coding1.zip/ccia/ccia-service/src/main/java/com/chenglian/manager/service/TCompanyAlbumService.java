package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TCompanyAlbum;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-12-07
 */

public interface TCompanyAlbumService extends IService<TCompanyAlbum> {
    IPage<TCompanyAlbum> selectPage(Page<TCompanyAlbum> page,TCompanyAlbum model);
    List<TCompanyAlbum> select(TCompanyAlbum model);
    TCompanyAlbum selectTopRow(TCompanyAlbum model);
    int saveReturnInt(TCompanyAlbum model);
    TCompanyAlbum select(int iCaIdentifier);

}

