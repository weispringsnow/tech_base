package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TCollectionInfoRecord;

import java.util.List;

/**
 * <p>
 * 用户收藏快讯文章表(APP) 服务类
 * </p>
 *
 * @author wla
 * @since 2020-03-13
 */

public interface TCollectionInfoRecordService extends IService<TCollectionInfoRecord> {
    IPage<TCollectionInfoRecord> selectPage(Page<TCollectionInfoRecord> page, TCollectionInfoRecord model);

    List<TCollectionInfoRecord> select(TCollectionInfoRecord model);

    TCollectionInfoRecord selectTopRow(TCollectionInfoRecord model);

    int saveReturnInt(TCollectionInfoRecord model);

    TCollectionInfoRecord select(int id);

    // 用户是否收藏
    Boolean isUserCollect(Integer userId, Integer informationId);
}

