package com.chenglian.manager.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TMapTitle;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author zxq
 * @since 2019-11-27
 */
public interface TMapTitleService extends IService<TMapTitle> {
    IPage<TMapTitle> selectPage(Page<TMapTitle> page, TMapTitle model);

    int saveReturnInt(TMapTitle model);

    List<TMapTitle> select(TMapTitle model);

    TMapTitle selectTopRow(TMapTitle model);

    TMapTitle select(int iMtIdentifier);
}

