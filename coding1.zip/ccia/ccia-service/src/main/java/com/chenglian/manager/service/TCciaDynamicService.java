package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TCciaDynamic;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2020-03-21
 */

public interface TCciaDynamicService extends IService<TCciaDynamic> {
    IPage<TCciaDynamic> selectPage(Page<TCciaDynamic> page,TCciaDynamic model);
    List<TCciaDynamic> select(TCciaDynamic model);
    TCciaDynamic selectTopRow(TCciaDynamic model);
    int saveReturnInt(TCciaDynamic model);
    TCciaDynamic select(int id);

}

