package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TFeedBackFast;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2020-03-21
 */

public interface TFeedBackFastService extends IService<TFeedBackFast> {
    IPage<TFeedBackFast> selectPage(Page<TFeedBackFast> page,TFeedBackFast model);
    List<TFeedBackFast> select(TFeedBackFast model);
    TFeedBackFast selectTopRow(TFeedBackFast model);
    int saveReturnInt(TFeedBackFast model);
    TFeedBackFast select(int id);

    IPage<TFeedBackFast> selectPageBack(Page<TFeedBackFast> objectPage, TFeedBackFast model);
}

