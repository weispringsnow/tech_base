package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TCollectionMagazineRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 * 会刊收藏表(官网APP) 服务类
 * </p>
 *
 * @author wla
 * @since 2020-03-18
 */

public interface TCollectionMagazineRecordService extends IService<TCollectionMagazineRecord> {
    IPage<TCollectionMagazineRecord> selectPage(Page<TCollectionMagazineRecord> page,TCollectionMagazineRecord model);
    List<TCollectionMagazineRecord> select(TCollectionMagazineRecord model);
    TCollectionMagazineRecord selectTopRow(TCollectionMagazineRecord model);
    int saveReturnInt(TCollectionMagazineRecord model);
    TCollectionMagazineRecord select(int id);

}

