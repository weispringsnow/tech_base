package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TCollectData;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-12-09
 */

public interface TCollectDataService extends IService<TCollectData> {
    IPage<TCollectData> selectPage(Page<TCollectData> page,TCollectData model);
    List<TCollectData> select(TCollectData model);
    TCollectData selectTopRow(TCollectData model);
    int saveReturnInt(TCollectData model);
    TCollectData select(int iCdIdentifier);

}

