package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TAdvertisementManager;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-25
 */

public interface TAdvertisementManagerService extends IService<TAdvertisementManager> {
    IPage<TAdvertisementManager> selectPage(Page<TAdvertisementManager> page, TAdvertisementManager model);

    int saveReturnInt(TAdvertisementManager model);

    List<TAdvertisementManager> select(TAdvertisementManager model);

    TAdvertisementManager selectTopRow(TAdvertisementManager model);

    TAdvertisementManager select(int iAmIdentifier);

    IPage<TAdvertisementManager> selectAppPage(Page<TAdvertisementManager> page);

    List<TAdvertisementManager> selectPcAds(TAdvertisementManager tAdvertisementManager);
}

