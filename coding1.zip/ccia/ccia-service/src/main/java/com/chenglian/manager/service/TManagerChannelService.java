package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TManagerChannel;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-14
 */

public interface TManagerChannelService extends IService<TManagerChannel> {
    IPage<TManagerChannel> selectPage(Page<TManagerChannel> page, TManagerChannel model);

    int saveReturnInt(TManagerChannel model);

    List<TManagerChannel> select(TManagerChannel model);

    TManagerChannel selectTopRow(TManagerChannel model);

    TManagerChannel select(int iMcIdentifier);

    void saveSortForAdd(TManagerChannel model);

    void saveSortForEdit(TManagerChannel model, TManagerChannel model1);

    void updateAllSort();
}

