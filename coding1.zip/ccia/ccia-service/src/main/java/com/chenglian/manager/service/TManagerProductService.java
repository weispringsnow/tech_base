package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TManagerProduct;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-14
 */

public interface TManagerProductService extends IService<TManagerProduct> {
    IPage<TManagerProduct> selectPage(Page<TManagerProduct> page, TManagerProduct model);

    int saveReturnInt(TManagerProduct model);

    List<TManagerProduct> select(TManagerProduct model);

    TManagerProduct selectTopRow(TManagerProduct model);

    TManagerProduct select(int iMpIdentifier);

    void saveSortForAdd(TManagerProduct model);

    void saveSortForEdit(TManagerProduct model, TManagerProduct model1);

    void updateAllSort();
}

