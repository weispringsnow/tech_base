package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TCity;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */

public interface TCityService extends IService<TCity> {
    IPage<TCity> selectPage(Page<TCity> page,TCity model);
    List<TCity> select(TCity model);
    TCity selectTopRow(TCity model);
    int saveReturnInt(TCity model);
    TCity select(int iCIdentifier);

}

