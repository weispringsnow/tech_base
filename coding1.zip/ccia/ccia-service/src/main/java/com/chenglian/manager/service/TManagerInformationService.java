package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TManagerInformation;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-15
 */

public interface TManagerInformationService extends IService<TManagerInformation> {
    IPage<TManagerInformation> selectPage(Page<TManagerInformation> page, TManagerInformation model);

    int saveReturnInt(TManagerInformation model);

    List<TManagerInformation> select(TManagerInformation model);

    TManagerInformation selectTopRow(TManagerInformation model);

    TManagerInformation select(int iMiIdentifier);

    void clearSpecialByScId(List<String> idList);

    void clearSpecialByInfoIds(List<String> idList);

    void clearBindCom(Integer infoId);

    void saveSortForEdit(TManagerInformation model, TManagerInformation model1);

    void updateAllSort(String comSortType);

    void clearEndVip();
}

