package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TLatestActivity;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 * 最新活动表(官网APP) 服务类
 * </p>
 *
 * @author wla
 * @since 2020-04-01
 */

public interface TLatestActivityService extends IService<TLatestActivity> {
    IPage<TLatestActivity> selectPage(Page<TLatestActivity> page,TLatestActivity model);
    List<TLatestActivity> select(TLatestActivity model);
    TLatestActivity selectTopRow(TLatestActivity model);
    int saveReturnInt(TLatestActivity model);
    TLatestActivity select(int id);

}

