package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TFeedBackExpress;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-12-17
 */

public interface TFeedBackExpressService extends IService<TFeedBackExpress> {
    IPage<TFeedBackExpress> selectPage(Page<TFeedBackExpress> page,TFeedBackExpress model);
    List<TFeedBackExpress> select(TFeedBackExpress model);
    TFeedBackExpress selectTopRow(TFeedBackExpress model);
    int saveReturnInt(TFeedBackExpress model);
    TFeedBackExpress select(int iFIdentifier);

}

