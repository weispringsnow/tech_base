package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TManagerSpecial;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-18
 */

public interface TManagerSpecialService extends IService<TManagerSpecial> {
    IPage<TManagerSpecial> selectPage(Page<TManagerSpecial> page, TManagerSpecial model);

    int saveReturnInt(TManagerSpecial model);

    List<TManagerSpecial> select(TManagerSpecial model);

    TManagerSpecial selectTopRow(TManagerSpecial model);

    TManagerSpecial select(int iScIdentifier);

    int getNumberSpecialArticles(Integer iScIdentifier);

    List<TManagerSpecial> selectByNum(Integer num, TManagerSpecial model);
}

