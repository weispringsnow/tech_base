package com.chenglian.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

@Service
public class CreateImage {
    @Autowired
    private UploadUtils uploadUtils;
    /**
     * @param name
     * @param width
     * @param height
     * @return
     */
    public String generateImages(String name, int width, int height,int BgType) throws Exception {
        InputStream aixing = CreateImage.class.getResourceAsStream("/font/msyh.TTF");
        Font dynamicFont = Font.createFont(Font.PLAIN, aixing);
        Font font = dynamicFont.deriveFont(50f);
        aixing.close();
//        Font font = new Font("微软雅黑", Font.PLAIN, 50);
        BufferedImage bi = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = (Graphics2D) bi.getGraphics();
        String title1 = ""; //第一行
        String title2 = ""; //第二行
        switch (BgType) {
            case 1:
                g2.setBackground(new Color(118, 184, 122));
                break;
            case 2:
                g2.setBackground(new Color(248, 135, 107));
                break;
            case 3:
                g2.setBackground(new Color(146, 189, 226));
                break;
            case 0:
                g2.setBackground(new Color(224, 164, 70));
                break;

        }
        g2.clearRect(0, 0, width, height);
        g2.setPaint(new Color(255, 255, 255, 255));
        g2.setFont(font);
        FontRenderContext context = g2.getFontRenderContext();
        Rectangle2D bounds = font.getStringBounds(name, context);
        double x = (width - bounds.getWidth()) / 2;
        double y = (height - bounds.getHeight()) / 2;
        double ascent = -bounds.getY();
        double baseY = y + ascent;

        switch (name.length()){
            case 2:
                title1=name;
                g2.drawString(title1, (int) x, (int) baseY);
                break;
            case 3:
                title1=name.substring(0,2);title2=name.substring(2);
                bounds = font.getStringBounds(title1, context);
                x = (width - bounds.getWidth()) / 2;
                y = (height - bounds.getHeight()) /2;
                ascent = -bounds.getY();
                baseY = y + ascent-ascent/2;
                g2.drawString(title1, (int) x, (int) baseY);
                bounds = font.getStringBounds(title2, context);
                x = (width - bounds.getWidth()) / 2;
                y = (height - bounds.getHeight()) ;
                g2.drawString(title2,(int) x, (int) (100-bounds.getY()));
                break;
            case 4:
                title1=name.substring(0,2);title2=name.substring(2);
                bounds = font.getStringBounds(title1, context);
                x = (width - bounds.getWidth()) / 2;
                y = (height - bounds.getHeight()) /2;
                ascent = -bounds.getY();
                baseY = y + ascent-ascent/2;
                g2.drawString(title1, (int) x, (int) baseY);

                bounds = font.getStringBounds(title2, context);
                x = (width - bounds.getWidth()) / 2;
                g2.drawString(title2,(int) x, (int)(100-bounds.getY()));
                break;
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ImageIO.write(bi, "jpg", out);
        String url = uploadUtils.uploadFileFastDFS(out.toByteArray(), "jpg");
        out.close();
        return url;

    }
}
