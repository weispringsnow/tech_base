package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TAssoProvince;

import java.util.List;

/**
 * <p>
 * 省市陶协省 服务类
 * </p>
 *
 * @author wla
 * @since 2020-02-14
 */

public interface TAssoProvinceService extends IService<TAssoProvince> {
    IPage<TAssoProvince> selectPage(Page<TAssoProvince> page,TAssoProvince model);
    List<TAssoProvince> select(TAssoProvince model);
    TAssoProvince selectTopRow(TAssoProvince model);
    int saveReturnInt(TAssoProvince model);
    TAssoProvince select(int id);

    void saveSortForAdd(TAssoProvince model);

    void saveSortForEdit(TAssoProvince model, TAssoProvince model1);

    void updateAllSort();
}

