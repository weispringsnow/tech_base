package com.chenglian.common.service;

import com.chenglian.common.utils.RestTemplateUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@Service
public class ApiHelper {
    private static final Logger logger = LoggerFactory.getLogger(ApiHelper.class);

    public boolean mobileSMS(String number, String sms) {
        MultiValueMap<String, String> paramMap = new LinkedMultiValueMap<>();
        paramMap.add("CorpID", "chenglian3");
        paramMap.add("Pwd", "taoci1");
        paramMap.add("Mobile", number);
        paramMap.add("Content", "【中国陶瓷官网】" + sms);
        String resultStr = RestTemplateUtil.getInstance().postForObject("http://101.200.29.88:8082/SendMT/SendMessage", paramMap, String.class);
        if (StringUtils.isBlank(resultStr)) {
            logger.error("string.IsNullOrWhiteSpace(resultStr)>>>>>&Mobile=" + number + "&Content=【中国陶瓷官网】" + sms);
            return false;
        } else {
            String[] arry = resultStr.split(",");
            if (arry[0].equals("00") || arry[0].equals("03")) return true;
            else if (arry[0] == "02") logger.error("IP限制>>>>>&Mobile=" + number + "&Content=【钢源保】" + sms);
            else if (arry[0] == "04") logger.error("用户名错误>>>>>&Mobile=" + number + "&Content=【钢源保】" + sms);
            else if (arry[0] == "05") logger.error("密码错误>>>>>&Mobile=" + number + "&Content=【钢源保】" + sms);
            else if (arry[0] == "07") logger.error("发送时间有误>>>>>&Mobile=" + number + "&Content=【钢源保】" + sms);
            else if (arry[0] == "08") logger.error("内容有误>>>>>&Mobile=" + number + "&Content=【钢源保】" + sms);
            else if (arry[0] == "09") logger.error("手机号码有误>>>>>&Mobile=" + number + "&Content=【钢源保】" + sms);
            else if (arry[0] == "10") logger.error("扩展号码有误>>>>>&Mobile=" + number + "&Content=【钢源保】" + sms);
            else if (arry[0] == "11") logger.error("余额不足>>>>>&Mobile=" + number + "&Content=【钢源保】" + sms);
            else if (arry[0] == "-1") logger.error("服务器内部异常>>>>>&Mobile=" + number + "&Content=【钢源保】" + sms);
            return false;
        }
    }
}