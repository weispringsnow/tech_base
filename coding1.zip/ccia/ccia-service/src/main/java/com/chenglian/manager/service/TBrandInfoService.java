package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TBrandInfo;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-15
 */

public interface TBrandInfoService extends IService<TBrandInfo> {
    IPage<TBrandInfo> selectPage(Page<TBrandInfo> page, TBrandInfo model);

    IPage<TBrandInfo> selectPageJudgePerfect(Page<TBrandInfo> page, TBrandInfo model, Integer isPerfect);

    int saveReturnInt(TBrandInfo model);

    List<TBrandInfo> select(TBrandInfo model);

    TBrandInfo selectTopRow(TBrandInfo model);

    TBrandInfo select(int iBiIdentifier);

    IPage<TBrandInfo> selectRankPage(Page<TBrandInfo> page, TBrandInfo model);

    IPage<TBrandInfo> selectAddRankPage(Page<TBrandInfo> page, TBrandInfo model);

    // 统计类型排名数量
    int countTypeRank(Integer iGfIdentifier);

    void saveSortForEdit(TBrandInfo model, TBrandInfo model1);

    boolean removeSortByIds(Collection<? extends Serializable> idList);

    void updateAllSort(int iGfIdentifier);

    List<TBrandInfo> getTopNum(int limit, TBrandInfo model);

    List<TBrandInfo> getTopNumRank(int limit, TBrandInfo model);
}

