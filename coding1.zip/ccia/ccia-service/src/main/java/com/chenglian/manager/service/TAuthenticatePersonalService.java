package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TAuthenticatePersonal;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2020-03-20
 */

public interface TAuthenticatePersonalService extends IService<TAuthenticatePersonal> {
    IPage<TAuthenticatePersonal> selectPage(Page<TAuthenticatePersonal> page,TAuthenticatePersonal model);
    List<TAuthenticatePersonal> select(TAuthenticatePersonal model);
    TAuthenticatePersonal selectTopRow(TAuthenticatePersonal model);
    int saveReturnInt(TAuthenticatePersonal model);
    TAuthenticatePersonal select(int id);

}

