package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.JsonModel2;
import com.chenglian.manager.entity.TBasicUser;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */

public interface TBasicUserService extends IService<TBasicUser> {
    IPage<TBasicUser> selectPage(Page<TBasicUser> page, TBasicUser model);

    List<TBasicUser> select(TBasicUser model);

    TBasicUser selectTopRow(TBasicUser model);

    int saveReturnInt(TBasicUser model);

    TBasicUser select(int iBuIdentifier);

    JsonModel2 setCode(String session_key, int code, int minutenumber);

    boolean isExistNvcName(String nvcName, Integer iBuIdentifier,Boolean isBack);

    boolean isHadValidLog(Integer iUiIdentifier, Integer iRiIdentifier);
}

