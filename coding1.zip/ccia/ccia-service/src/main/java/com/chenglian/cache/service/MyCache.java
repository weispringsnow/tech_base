package com.chenglian.cache.service;


import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.chenglian.manager.entity.*;
import com.chenglian.manager.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class MyCache {
    @Autowired
    private MyCache myCache;
    @Autowired
    private ViewBackUserService viewBackUserService;
    @Autowired
    private TCityService tCityService;
    @Autowired
    private TCountyService tCountyService;
    @Autowired
    private TProvinceService tProvinceService;
    @Autowired
    private TMagagementModelService tMagagementModelService;
    @Autowired
    private TServiceChoiceService tServiceChoiceService;
    @Autowired
    private TManagerProductService tManagerProductService;
    @Autowired
    private TManagerChannelService tManagerChannelService;
    @Autowired
    private TManagerSpecialService tManagerSpecialService;
    @Autowired
    private TGoodsFirstService tGoodsFirstService;
    @Autowired
    private TGoodsSecondService tGoodsSecondService;
    @Autowired
    private TCompanyTypeInfoService tCompanyTypeInfoService;
    @Autowired
    private TPurchaseTypeService tPurchaseTypeService;
    @Autowired
    private TFeedbackTypeService tFeedbackTypeService;
    @Autowired
    private TBrandInfoService tBrandInfoService;
    @Autowired
    private TAssoProvinceService tAssoProvinceService;
    @Autowired
    private TAssoCityService tAssoCityService;

    @CacheEvict(value = "CCia", allEntries = true)
    public boolean cleanCache() {
        return true;
    }

    /**
     * 获取所有反馈类型
     */
    @Cacheable("CCia")
    public List<TFeedbackType> getFeedbackType() {
        TFeedbackType model = new TFeedbackType();
        List<TFeedbackType> list = tFeedbackTypeService.select(model);
        return list;
    }

    /**
     * 获取所有产区
     */
    @Cacheable("CCia")
    public List<TManagerProduct> getProductArea() {
        TManagerProduct model = new TManagerProduct();
        model.setIsDelete(false);
        List<TManagerProduct> list = tManagerProductService.select(model);
        return list;
    }

    /**
     * 获取所有频道
     */
    @Cacheable("CCia")
    public List<TManagerChannel> getChannel() {
        return tManagerChannelService.select(new TManagerChannel().setIsDelete(false));
    }

    /**
     * 获取所有省市陶协的省
     */
    @Cacheable("CCia")
    public List<TAssoProvince> getAssoProvivce() {
        return tAssoProvinceService.select(new TAssoProvince());
    }

    /**
     * 获取ccia各大部门map(联系方式用)
     */
    @Cacheable("CCia")
    public Map<Integer, String> getCciaContactDeptMap() {
        return new TCciaContactInfo().getDepartmentMap();
    }

    /**
     * 获取ccia联系方式种类map(联系方式用)
     */
    @Cacheable("CCia")
    public Map<Integer, String>  getCciaContactTypeMap() {
        return new TCciaContactInfo().getTypeMap();
    }

    /**
     * 获取所有省市陶协的市
     */
    @Cacheable("CCia")
    public List<TAssoCity> getAssoCity() {
        return tAssoCityService.select(new TAssoCity());
    }

    /**
     * 获取所有专题
     */
    @Cacheable("CCia")
    public List<TManagerSpecial> getSpecial() {
        return tManagerSpecialService.select(new TManagerSpecial());
    }

    /**
     * 获取所有产品一级
     */
    @Cacheable("CCia")
    public List<TGoodsFirst> getGoodsFirst() {
        return tGoodsFirstService.select(new TGoodsFirst().setIsDelete(false));
    }

    /**
     * 获取所有产品二级
     */
    @Cacheable("CCia")
    public List<TGoodsSecond> getGoodsSecond() {
        return tGoodsSecondService.select(new TGoodsSecond().setIsDelete(false));
    }

    /**
     * 某一级产品下的二级产品/或全部
     */
    public List<TGoodsSecond> getGoodsSecond(Integer iGfIdentifier) {
        List<TGoodsSecond> list = myCache.getGoodsSecond();
        if (CollectionUtils.isNotEmpty(list) && iGfIdentifier != null) {
            return list.stream().filter(p -> p.getIGfIdentifier() == iGfIdentifier.intValue()).collect(Collectors.toList());
        }
        return list;
    }

    /**
     * 某一级产品下的二级产品/或全部
     */
    public String getGoodsSecondNameById(Integer iGsIdentifier) {
        List<TGoodsSecond> list = myCache.getGoodsSecond();
        if (CollectionUtils.isNotEmpty(list) && iGsIdentifier != null) {
            TGoodsSecond tGoodsSecond = list.stream().filter(p -> p.getIGsIdentifier() == iGsIdentifier.intValue()).findFirst().orElse(null);
            if (tGoodsSecond != null) {
                return tGoodsSecond.getNvcGoodsSecondName();
            }
        }
        return "";
    }

    /**
     * 获取所有责任人放入缓存
     */
    @Cacheable("CCia")
    public List<ViewBackUser> getResponsibleInfoList() {
        ViewBackUser viewBackuser = new ViewBackUser();
        viewBackuser.setIsDelete(false);
        List<ViewBackUser> list = viewBackUserService.select(viewBackuser);
        return list;
    }

    /**
     * 获取所有省放入缓存
     */
    @Cacheable("CCia")
    public List<TProvince> getAllTProvince() {
        return tProvinceService.select(null);
    }

    /**
     * 获取所有城市放入缓存
     */
    @Cacheable("CCia")
    public List<TCity> getAllTCity() {
        return tCityService.select(null);
    }

    /**
     * 获取所有区县放入缓存
     */
    @Cacheable("CCia")
    public List<TCounty> getAllTCountry() {
        return tCountyService.select(null);
    }

    /**
     * 获取所有经营模式放入缓存
     */
    @Cacheable("CCia")
    public List<TMagagementModel> getAllTMagagementModel() {
        TMagagementModel model = new TMagagementModel().setIsDelete(false);
        return tMagagementModelService.select(model);
    }


    /**
     * 获取所有所选服务放入缓存
     */
    @Cacheable("CCia")
    public List<TServiceChoice> getAllTServiceChoice() {
        TServiceChoice model = new TServiceChoice().setIsDelete(false);
        return tServiceChoiceService.select(model);
    }

    /**
     * 获取所有选企业类型放入缓存
     */
    @Cacheable("CCia")
    public List<TCompanyTypeInfo> getAllTCompanyTypeInfo() {
        TCompanyTypeInfo model = new TCompanyTypeInfo().setIsDelete(false);
        return tCompanyTypeInfoService.select(model);
    }

    /**
     * 获取所有采购类型放入缓存
     */
    @Cacheable("CCia")
    public List<TPurchaseType> getAllTPurchaseType() {
        return tPurchaseTypeService.select(new TPurchaseType().setIsDelete(false));
    }

    /**
     * 获取所有品牌放入缓存
     */
    @Cacheable("CCia")
    public List<TBrandInfo> getAllTBrandInfo() {
        return tBrandInfoService.select(new TBrandInfo().setIsDelete(false));
    }

    /**
     * 根据省id获取省市陶协的市
     */
    public List<TAssoCity> getAssoCity(Integer proId) {
        List<TAssoCity> list = myCache.getAssoCity();
        if (proId != null && proId > 0) {
            list = list.stream().filter(city -> city.getProId() == proId.intValue()).collect(Collectors.toList());
        }
        return list;
    }

    /**
     * 市
     */
    public List<TCity> getCity(Integer i_c_identifier, Integer i_p_identifier) {
        List<TCity> list = myCache.getAllTCity();
        if (i_c_identifier != null && i_c_identifier > 0) {
            list = list.stream().filter(m -> m.getICIdentifier() == i_c_identifier.intValue()).collect(Collectors.toList());
        } else if (i_p_identifier != null && i_p_identifier > 0) {
            list = list.stream().filter(m -> m.getIPIdentifier() == i_p_identifier.intValue()).collect(Collectors.toList());
        }
        return list;
    }

    /**
     * 省
     */
    public List<TProvince> getProvince(Integer i_p_identifier) {
        List<TProvince> list = myCache.getAllTProvince();
        if (i_p_identifier != null && i_p_identifier > 0) {
            list = list.stream().filter(m -> m.getIPIdentifier() == i_p_identifier.intValue()).collect(Collectors.toList());
        }
        return list;
    }

    /**
     * 区县
     */
    public List<TCounty> getCounty(Integer i_co_identifier, Integer i_c_identifier) {
        List<TCounty> list = myCache.getAllTCountry();
        if (i_c_identifier != null && i_c_identifier > 0) {
            list = list.stream().filter(m -> m.getICIdentifier() == i_c_identifier.intValue()).collect(Collectors.toList());
        } else if (i_co_identifier != null && i_co_identifier > 0) {
            list = list.stream().filter(m -> m.getICoIdentifier() == i_co_identifier.intValue()).collect(Collectors.toList());

        }
        return list;
    }

    public Map<Integer, String> getResponsibleInfo() {
        Map<Integer, String> map = new LinkedHashMap<>();
        List<ViewBackUser> list = myCache.getResponsibleInfoList();
        if (CollectionUtils.isNotEmpty(list)) {
            list.forEach(t -> map.put(t.getIBumIdentifier(), t.getNvcName()));
        }
        return map;
    }

    public Integer getGGZYId() {
        List<ViewBackUser> list = myCache.getResponsibleInfoList();
        if (CollectionUtils.isNotEmpty(list)) {
            for (ViewBackUser item : list) {
                if ("公共资源".equals(item.getNvcName())) {
                    return item.getIBumIdentifier();
                }
            }
        }
        return 1;
    }

    public String getNvcManagementType(Integer iMmIdentifier) {
        List<TMagagementModel> list = myCache.getAllTMagagementModel();
        if (CollectionUtils.isNotEmpty(list) && iMmIdentifier != null) {
            TMagagementModel model = list.stream().filter(p -> p.getIMmIdentifier() == iMmIdentifier.intValue()).findFirst().orElse(null);
            if (model != null) {
                return model.getNvcManagementType();
            }
        }
        return "";
    }

    public String getResponsibleInfo(Integer iRiIdentifier) {
        List<ViewBackUser> list = myCache.getResponsibleInfoList();
        if (CollectionUtils.isNotEmpty(list) && iRiIdentifier != null) {
            ViewBackUser backUser = list.stream().filter(p -> p.getIBumIdentifier() == iRiIdentifier.intValue()).findFirst().orElse(null);
            if (backUser != null) {
                return backUser.getNvcName();
            }
        }
        return "";
    }

    /**
     * 品牌类型名称
     */
    public String getGoodsFirstNameById(Integer iGfIdentifier) {
        List<TGoodsFirst> list = myCache.getGoodsFirst();
        if (CollectionUtils.isNotEmpty(list) && iGfIdentifier != null) {
            TGoodsFirst goodsFirst = list.stream().filter(p -> p.getIGfIdentifier() == iGfIdentifier.intValue()).findFirst().orElse(null);
            if (goodsFirst != null) {
                return goodsFirst.getNvcGoodsFirstName();
            }
        }
        return "";
    }

    public Map<Integer, String> goodsFirst2() {
        Map<Integer, String> map = new LinkedHashMap<>();
        map.put(6, "陶瓷原料");
        map.put(7, "陶瓷辅料");
        return map;
    }

    public Map<Integer, String> goodsFirst1() {
        Map<Integer, String> map = new LinkedHashMap<>();
        map.put(8, "陶瓷设备");
        map.put(9, "陶瓷炉材");
        return map;
    }

    public List<TPurchaseType> purchaseType() {
        return myCache.getAllTPurchaseType();
    }

    public String getTMagagementModelStr(Integer iMmIdentifier) {
        List<TMagagementModel> list = myCache.getAllTMagagementModel();
        if (CollectionUtils.isNotEmpty(list) && iMmIdentifier != null) {
            TMagagementModel orElse = list.stream().filter(p -> p.getIMmIdentifier() == iMmIdentifier.intValue()).findFirst().orElse(null);
            if (orElse != null) {
                return orElse.getNvcManagementType();
            }
        }
        return "";
    }

    public String getProductBrandName(List<ViewBrand> list, Integer iBiIdentifier) {
        if (CollectionUtils.isNotEmpty(list) && iBiIdentifier != null) {
            ViewBrand viewBrand = list.stream().filter(p -> p.getIBiIdentifier() == iBiIdentifier.intValue()).findFirst().orElse(null);
            if (viewBrand != null) {
                return viewBrand.getNvcBrandName();
            }
        }
        return "";
    }

    public String getAddressStr(Integer iPIdentifier, Integer iCIdentifier, Integer iCoIdentifier) {
        StringBuffer sb = new StringBuffer();
        List<TProvince> allTProvince = myCache.getAllTProvince();
        List<TCity> allTCity = myCache.getAllTCity();
        List<TCounty> allTCountry = myCache.getAllTCountry();
        if (CollectionUtils.isNotEmpty(allTProvince) && iPIdentifier != null && iPIdentifier > 0) {
            TProvince province = allTProvince.stream().filter(p -> p.getIPIdentifier() == iPIdentifier.intValue()).findFirst().orElse(null);
            if (province != null) {
                sb.append(province.getNvcProvince());
            }
        }
        if (CollectionUtils.isNotEmpty(allTCity) && iCIdentifier != null && iCIdentifier > 0) {
            TCity tCity = allTCity.stream().filter(p -> p.getICIdentifier() == iCIdentifier.intValue()).findFirst().orElse(null);
            if (tCity != null) {
                sb.append(tCity.getNvcCity());
            }
        }
        if (CollectionUtils.isNotEmpty(allTCountry) && iCoIdentifier != null && iCoIdentifier > 0) {
            TCounty tCounty = allTCountry.stream().filter(p -> p.getICoIdentifier() == iCoIdentifier.intValue()).findFirst().orElse(null);
            if (tCounty != null) {
                sb.append(tCounty.getNvcCounty());
            }
        }
        return sb.toString();
    }

    public String getPurchaseTypeStr(Integer iPtIdentifier) {
        List<TPurchaseType> list = myCache.getAllTPurchaseType();
        if (CollectionUtils.isNotEmpty(list) && iPtIdentifier != null) {
            TPurchaseType tPurchaseType = list.stream().filter(p -> p.getIPtIdentifier() == iPtIdentifier.intValue()).findFirst().orElse(null);
            if (tPurchaseType != null) {
                return tPurchaseType.getNvcPurchaseType();
            }
        }
        return "";
    }

    public String getMonthUsedName(Integer iGfIdentifier) {
        String name = "";
        switch (iGfIdentifier) {
            case 6:
            case 7:
                name = "月用量";
                break;
            case 10:
            case 0:
                name = "";
                break;
            case 1:
            case 2:
            case 3:
            case 4:
                name = "采购量";
                break;
            default:
                name = "采购量";
                break;
        }
        return name;
    }

    public String getMonthUsedNameC1(Integer iGfIdentifier) {
        String name = "";
        switch (iGfIdentifier) {
            case 6:
            case 7:
                name = "物理指标";
                break;
            case 10:
            case 0:
                name = "";
                break;
            case 1:
            case 2:
            case 3:
            case 4:
                name = "参数";
                break;
            default:
                name = "规格型号";
                break;
        }
        return name;
    }

    public String getTdictErpCategoryOne(String dictErpCategory) {
        if (StringUtils.isNotEmpty(dictErpCategory)) {
            String[] split = dictErpCategory.split(",");
            if (split != null && split.length > 0) {
                return split[0];
            }
        }
        return dictErpCategory;
    }

    public String getTdictErpCategoryOne(String dictErpCategory, String erpCategory) {
        if (StringUtils.isEmpty(erpCategory) || erpCategory.equals("全部")) {
            return getTdictErpCategoryOne(dictErpCategory);
        }
        if (StringUtils.isNotEmpty(dictErpCategory)) {
            String[] split = dictErpCategory.split(",");
            if (split != null && split.length > 0) {
                for (String str : split) {
                    if (str.equals(erpCategory)) {
                        return erpCategory;
                    }
                }
            }
        }
        return getTdictErpCategoryOne(dictErpCategory);
    }


}
