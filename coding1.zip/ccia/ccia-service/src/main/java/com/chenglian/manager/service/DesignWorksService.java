package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.DesignWorks;

import java.util.List;

/**
 * <p>
 * 陶瓷设计作品表 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-21
 */

public interface DesignWorksService extends IService<DesignWorks> {
    IPage<DesignWorks> selectPage(Page<DesignWorks> page, DesignWorks model);

    int saveReturnInt(DesignWorks model);

    List<DesignWorks> select(DesignWorks model);

    DesignWorks selectTopRow(DesignWorks model);

    DesignWorks select(int id);

    List<DesignWorks> getTopNum(int limit, DesignWorks model);
}

