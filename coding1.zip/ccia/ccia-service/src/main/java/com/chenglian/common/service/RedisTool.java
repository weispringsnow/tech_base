package com.chenglian.common.service;

import com.chenglian.common.enums.RedisDBEnum;
import com.chenglian.common.enums.RedisFolderEnum;
import com.chenglian.common.utils.Fun;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.concurrent.TimeUnit;

@Service
public class RedisTool {
    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    /**
     * 是否存在
     *
     * @param key    键
     * @param folder 目录
     * @param db     库
     * @return
     */
    public boolean keyExists(String key, RedisFolderEnum folder, RedisDBEnum db) {
        try {
            switchDb(db);
            String fd = folder.getValue();
            return redisTemplate.hasKey(StringUtils.isBlank(fd) ? key : (fd + ":" + key));
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return false;
        }
    }

    public boolean keyExists(String key) {
        return keyExists(key, RedisFolderEnum.Root, RedisDBEnum.One);
    }

    /**
     * 删除
     */
    public boolean keyDelete(String key, RedisFolderEnum folder, RedisDBEnum db) {
        try {
            switchDb(db);
            String fd = folder.getValue();
            return redisTemplate.delete(StringUtils.isBlank(fd) ? key : (fd + ":" + key));
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return false;
        }
    }

    public boolean keyDelete(String key) {
        return keyDelete(key, RedisFolderEnum.Root, RedisDBEnum.One);
    }


    /**
     * 添加单个
     *
     * @param key           键
     * @param value         值
     * @param expireMinutes 过期时间，单位：分钟
     * @param folder        目录
     * @param db            库
     * @return
     */
    public boolean stringSet(String key, Object value, int expireMinutes, RedisFolderEnum folder, RedisDBEnum db) {
        try {
            switchDb(db);
            String fd = folder.getValue();
            redisTemplate.opsForValue().set(StringUtils.isBlank(fd) ? key : (fd + ":" + key), value, 600, TimeUnit.MINUTES);
            return true;
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return false;
        }

    }

    public boolean stringSet(String key, Object value) {
        return stringSet(key, value, 600, RedisFolderEnum.Root, RedisDBEnum.One);
    }

    /**
     * 添加单个
     *
     * @param key    键
     * @param min    过期时间，单位：分钟
     * @param folder 目录
     * @param db     库
     * @return
     */
    public boolean keyExpire(String key, int min, RedisFolderEnum folder, RedisDBEnum db) {
        try {
            switchDb(db);
            String fd = folder.getValue();
            redisTemplate.expire(StringUtils.isBlank(fd) ? key : (fd + ":" + key), min, TimeUnit.MINUTES);
            return true;
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
            return false;
        }
    }

    public boolean keyExpire(String key, int min) {
        return keyExpire(key, min, RedisFolderEnum.Root, RedisDBEnum.One);
    }

    /**
     * 切换库
     *
     * @param db
     */
    public void switchDb(RedisDBEnum db) {
        if (db != null && db.getValue() > 0) {

//            JedisConnectionFactory connectionFactory = (JedisConnectionFactory) redisTemplate.getConnectionFactory();
//            connectionFactory.setDatabase(db.getValue());
        } else {
//            JedisConnectionFactory connectionFactory = (JedisConnectionFactory) redisTemplate.getConnectionFactory();
//            connectionFactory.setDatabase(0);
        }
    }

    /**
     * 获取单个
     *
     * @param key
     * @param folder
     * @param db
     * @return
     */
    public Object stringGet(String key, RedisFolderEnum folder, RedisDBEnum db) {
        switchDb(db);
        String fd = folder.getValue();
        return redisTemplate.opsForValue().get(StringUtils.isBlank(fd) ? key : (fd + ":" + key));
    }

    public Object stringGet(String key) {
        return stringGet(key, RedisFolderEnum.Root, RedisDBEnum.One);
    }
}
