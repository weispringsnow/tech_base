package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TContactInfo;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author weicx
 * @since 2019-11-26
 */

public interface TContactInfoService extends IService<TContactInfo> {
    IPage<TContactInfo> selectPage(Page<TContactInfo> page, TContactInfo model);

    List<TContactInfo> select(TContactInfo model);

    TContactInfo selectTopRow(TContactInfo model);

    int saveReturnInt(TContactInfo model);

    TContactInfo select(int iCiIdentifier);

    QueryWrapper<TContactInfo> onSelectWhere(TContactInfo model);

    List<TContactInfo> userContact(Integer iUserIdentifier);

    List<TContactInfo> userContactName(Integer iUserIdentifier);

    void saveFistContact(Integer iUserIdentifier, Integer iCiIdentifier);

    boolean noExistsFistContact(Integer iUserIdentifier, Integer iCiIdentifier);

    boolean deleteById(Integer iCiIdentifier);
}

