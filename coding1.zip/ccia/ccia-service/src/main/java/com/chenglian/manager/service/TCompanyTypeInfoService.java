package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TCompanyTypeInfo;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-11-29
 */

public interface TCompanyTypeInfoService extends IService<TCompanyTypeInfo> {
    IPage<TCompanyTypeInfo> selectPage(Page<TCompanyTypeInfo> page,TCompanyTypeInfo model);
    List<TCompanyTypeInfo> select(TCompanyTypeInfo model);
    TCompanyTypeInfo selectTopRow(TCompanyTypeInfo model);
    int saveReturnInt(TCompanyTypeInfo model);
    TCompanyTypeInfo select(int iCtiIdentifier);

}

