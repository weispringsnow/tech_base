package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.Bookstore;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 * 陶瓷书店表 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-23
 */

public interface BookstoreService extends IService<Bookstore> {
    IPage<Bookstore> selectPage(Page<Bookstore> page,Bookstore model);
    int saveReturnInt(Bookstore model);
    List<Bookstore> select(Bookstore model);
    Bookstore selectTopRow(Bookstore model);
    Bookstore select(int id);

    List<Bookstore> getTopNum(int limit, Bookstore model);
}

