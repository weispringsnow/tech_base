package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TAssoNews;

import java.util.List;

/**
 * <p>
 * 省市陶协新闻 服务类
 * </p>
 *
 * @author wla
 * @since 2020-02-15
 */

public interface TAssoNewsService extends IService<TAssoNews> {
    IPage<TAssoNews> selectPage(Page<TAssoNews> page, TAssoNews model);

    List<TAssoNews> select(TAssoNews model);

    TAssoNews selectTopRow(TAssoNews model);

    int saveReturnInt(TAssoNews model);

    TAssoNews select(int id);

    List<TAssoNews> getTopNum(int limit, TAssoNews model);


    void saveSortForAdd(TAssoNews model);

    void saveSortForEdit(TAssoNews model, TAssoNews model1);

    void updateAllSort(TAssoNews model);
}

