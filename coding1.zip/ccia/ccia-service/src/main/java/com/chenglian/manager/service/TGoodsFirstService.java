package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TGoodsFirst;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-15
 */

public interface TGoodsFirstService extends IService<TGoodsFirst> {
    IPage<TGoodsFirst> selectPage(Page<TGoodsFirst> page,TGoodsFirst model);
    int saveReturnInt(TGoodsFirst model);
    List<TGoodsFirst> select(TGoodsFirst model);
    TGoodsFirst selectTopRow(TGoodsFirst model);
    TGoodsFirst select(int iGfIdentifier);

}

