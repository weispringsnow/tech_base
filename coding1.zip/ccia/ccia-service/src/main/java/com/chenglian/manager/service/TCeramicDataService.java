package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TCeramicData;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2019-12-05
 */

public interface TCeramicDataService extends IService<TCeramicData> {
    IPage<TCeramicData> selectPage(Page<TCeramicData> page,TCeramicData model);
    List<TCeramicData> select(TCeramicData model);
    TCeramicData selectTopRow(TCeramicData model);
    int saveReturnInt(TCeramicData model);
    TCeramicData select(int id);

    List<TCeramicData> getTopNum(int limit, TCeramicData model);
}

