package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.JsonModel2;
import com.chenglian.manager.entity.TCollectInfo;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author weicx
 * @since 2019-12-07
 */

public interface TCollectInfoService extends IService<TCollectInfo> {
    IPage<TCollectInfo> selectPage(Page<TCollectInfo> page, TCollectInfo model);

    List<TCollectInfo> select(TCollectInfo model);

    TCollectInfo selectTopRow(TCollectInfo model);

    int saveReturnInt(TCollectInfo model);

    TCollectInfo select(int iCiIdentifier);

    boolean deleteTCollectInfo(Integer iUiIdentifier, Integer iColectCompany);

    JsonModel2 addCollectAndroid(Integer iUiIdentifier, Integer iColectCompany);

    JsonModel2 addCollectIOS(Integer iUiIdentifier, Integer iColectCompany);

    JsonModel2 addCollectPC(Integer iUiIdentifier, Integer iColectCompany);

    Boolean isCollected(Integer iUiIdentifier, Integer iColectCompany);
}

