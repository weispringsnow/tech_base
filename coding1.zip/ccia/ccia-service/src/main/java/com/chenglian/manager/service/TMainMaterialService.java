package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TMainMaterial;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-19
 */

public interface TMainMaterialService extends IService<TMainMaterial> {
    IPage<TMainMaterial> selectPage(Page<TMainMaterial> page,TMainMaterial model);
    int saveReturnInt(TMainMaterial model);
    List<TMainMaterial> select(TMainMaterial model);
    TMainMaterial selectTopRow(TMainMaterial model);
    TMainMaterial select(int iMmIdentifier);

}

