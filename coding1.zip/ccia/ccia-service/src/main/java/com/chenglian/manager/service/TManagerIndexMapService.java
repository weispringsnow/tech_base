package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TManagerIndexMap;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2020-01-17
 */

public interface TManagerIndexMapService extends IService<TManagerIndexMap> {
    IPage<TManagerIndexMap> selectPage(Page<TManagerIndexMap> page,TManagerIndexMap model);
    List<TManagerIndexMap> select(TManagerIndexMap model);
    TManagerIndexMap selectTopRow(TManagerIndexMap model);
    int saveReturnInt(TManagerIndexMap model);
    TManagerIndexMap select(int id);

    List<TManagerIndexMap> getTopNum(TManagerIndexMap model, int limit);
}

