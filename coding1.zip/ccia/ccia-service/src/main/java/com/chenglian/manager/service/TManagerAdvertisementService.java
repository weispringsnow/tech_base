package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TManagerAdvertisement;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-16
 */

public interface TManagerAdvertisementService extends IService<TManagerAdvertisement> {
    IPage<TManagerAdvertisement> selectPage(Page<TManagerAdvertisement> page, TManagerAdvertisement model);

    int saveReturnInt(TManagerAdvertisement model);

    List<TManagerAdvertisement> select(TManagerAdvertisement model);

    TManagerAdvertisement selectTopRow(TManagerAdvertisement model);

    TManagerAdvertisement select(int iMaIdentifier);

    List<TManagerAdvertisement> selectIndexImgs(TManagerAdvertisement tManagerAdvertisement);

}

