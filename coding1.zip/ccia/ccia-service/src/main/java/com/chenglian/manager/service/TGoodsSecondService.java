package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TGoodsSecond;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-15
 */

public interface TGoodsSecondService extends IService<TGoodsSecond> {
    IPage<TGoodsSecond> selectPage(Page<TGoodsSecond> page,TGoodsSecond model);
    int saveReturnInt(TGoodsSecond model);
    List<TGoodsSecond> select(TGoodsSecond model);
    TGoodsSecond selectTopRow(TGoodsSecond model);
    TGoodsSecond select(int iGsIdentifier);
}

