package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TManagerJournal;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-20
 */

public interface TManagerJournalService extends IService<TManagerJournal> {
    IPage<TManagerJournal> selectPage(Page<TManagerJournal> page,TManagerJournal model);
    int saveReturnInt(TManagerJournal model);
    List<TManagerJournal> select(TManagerJournal model);
    TManagerJournal selectTopRow(TManagerJournal model);
    TManagerJournal select(int iMjIdentifier);

    List<TManagerJournal> selectYearAndMonth();
}

