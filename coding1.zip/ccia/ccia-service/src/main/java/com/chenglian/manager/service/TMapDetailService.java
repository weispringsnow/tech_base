package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TMapDetail;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zxq
 * @since 2019-11-29
 */

public interface TMapDetailService extends IService<TMapDetail> {
    IPage<TMapDetail> selectPage(Page<TMapDetail> page,TMapDetail model);
    int saveReturnInt(TMapDetail model);
    List<TMapDetail> select(TMapDetail model);
    TMapDetail selectTopRow(TMapDetail model);
    TMapDetail select(int iMdIdentifier);

}

