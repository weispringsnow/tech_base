package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TEditionRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-19
 */

public interface TEditionRecordService extends IService<TEditionRecord> {
    IPage<TEditionRecord> selectPage(Page<TEditionRecord> page,TEditionRecord model);
    int saveReturnInt(TEditionRecord model);
    List<TEditionRecord> select(TEditionRecord model);
    TEditionRecord selectTopRow(TEditionRecord model);
    TEditionRecord select(int iErIdentifier);

}

