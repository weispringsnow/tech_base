package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TIndividualUserInfo;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */

public interface TIndividualUserInfoService extends IService<TIndividualUserInfo> {
    IPage<TIndividualUserInfo> selectPage(Page<TIndividualUserInfo> page, TIndividualUserInfo model);

    List<TIndividualUserInfo> select(TIndividualUserInfo model);

    TIndividualUserInfo selectTopRow(TIndividualUserInfo model);

    int saveReturnInt(TIndividualUserInfo model);

    void updateResposiblePeople(TIndividualUserInfo setIRiIdentifier);

    Boolean isSameResposiblePeople(Integer iBuIdentifier, Integer iRiIdentifier);

    boolean isGGZY(Integer iBuIdentifier);
}

