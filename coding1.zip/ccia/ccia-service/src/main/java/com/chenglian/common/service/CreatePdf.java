package com.chenglian.common.service;


import com.aspose.words.License;
import com.aspose.words.SaveFormat;
import com.chenglian.common.utils.AsianFontProvider;
import com.chenglian.common.utils.Fun;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.charset.Charset;

/**
 * 文件格式转换工具类
 *
 * @author lbj
 * <p>
 * 2015-10-8 上午10:52:22
 */
@Service
public class CreatePdf {
    @Autowired
    private UploadUtils uploadUtils;
    public  String creataPDFByHTMLText(Integer userId, String html) {
        try {
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            Document document = new Document();
            PdfWriter pdfWriter = PdfWriter.getInstance(document, os);
            document.open();
            XMLWorkerHelper worker = XMLWorkerHelper.getInstance();
            worker.parseXHtml(pdfWriter, document, new ByteArrayInputStream(html.getBytes()), null, Charset.forName("utf-8"), new AsianFontProvider());
            document.close();
            os.close();
            byte[] bytes = os.toByteArray();
            String dfsPath = uploadUtils.uploadFileFastDFS(bytes, ".pdf");
            System.err.println(dfsPath);
            return dfsPath;
        } catch (Exception e) {
            Fun.getAllExceptionMsg(e);
        }
        return "";
    }

    /**
     * 读取配置文件
     * @return
     */
    public static boolean getLicense() {
        boolean result = false;
        try {
            InputStream is = UploadUtils.class.getResourceAsStream("/license.xml");
            License aposeLic = new License();
            aposeLic.setLicense(is);
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * .doc文件转pdf格式
     * @param address .doc文件地址
     * @return 转换pdf后的地址
     */
    public String word2pdf(InputStream address) {
        String filePath = null;
        if (!getLicense()) { // 验证License 若不验证则转化出的pdf文档会有水印产生
            return null;
        }
        try {
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            com.aspose.words.Document doc = new com.aspose.words.Document(address); // Address是将要被转化的word文档
            doc.save(os, SaveFormat.PDF);// 全面支持DOC, DOCX, OOXML, RTF HTML,
            // OpenDocument, PDF, EPUB, XPS, SWF
            // 相互转换
            byte[] bytes = os.toByteArray();
            String dfsPath = uploadUtils.uploadFileFastDFS(bytes, ".pdf");
            return dfsPath;
        } catch (Exception e) {
            e.printStackTrace();
            return e.getMessage();
        }

    }

    public static void main(String[] args) throws Exception {
//        try {
//            String str = "<html><head></head><body><h2 style='text-align: center;'>购销协议&nbsp;&nbsp;</h2><p style='text-align: right;'>合同编号：637081465859106156</p><p>甲方（供应商）：高星辰供货公司</p><p> 乙方（采购商）：高星辰科技有限公司</p><p><span>签定地点：</span><span><label>天津市天津市和平区123</label></span></p><p><span>签订时间：</span><span><label>2019年10月31日</label></span></p><p> 根据《中华人民共和国合同法》等相关法律、法规及规范性文件，以及《钢源保交易规则》，甲乙双方本着平等自愿、诚实信用的原则，经协商一致，达成本合同，并保证共同遵守执行。</p><h3>一、产品标的</h3><p>产品名称：煅烧煤增碳剂111111</p><p>物理指标：灰分 ＝1%；挥发分 ＝2%</p><p>化学指标：C ≥3%；N ＞4ppm</p><p>产地：北京市北京市</p><p>电子仓所在地：河北省唐山市路南区</p><p>包装：10kg/桶</p><p>单价：1.00元/吨，不含运费</p><p>数量：1.000吨（毛重，含包装）</p><p>其他要求：</p><h3>二、交货及验收</h3><p>1、本协议经双方签订后，甲方需在3天内发货，否则乙方有权取消订单，由此产生的损失由甲方承担，由于不可抗力造成的发货延迟，供方应在约定发货前及时通知采购商需要延迟到货的具体时间。</p><p>2、甲方需保证在发货后7天内到货，如延时到货超过3天，乙方有权要求甲方每天按照未到货货值的1.00%赔偿损失。</p><p><span>3、运输方式：</span><span><label>汽运</label></span></p><p><span>4、交货地点：</span><span>天津市和平区123123</span></p><p>5、如到货数量少于订单数量，乙方有权要求甲方补足数量或按实际到货数量付款。如到货数量超过订单数量，若双方协商一致，可按照双方协商的方式处理，否则乙方有权对超出其所下订单的部分货物不予结算。</p> <p> 6、如出现外观有破损、雨淋及货物丢失等情况，且供求双方不能协商达成一致，乙方有权要求退货，且发货、退货的运费由甲方承担。</p > <h3>三、质量标准及处理</h3><p>1、如到货产品物理、化学指标及其它要求不符合协议要求，乙方有权要求退货。</p><table width='100%' cellspacing='0' cellpadding='0' style='border-top: 1px solid #000;border-left: 1px solid #000;margin: 10px auto;'><tbody><tr><td width='20%' style='border-bottom: 1px solid #000;border-right: 1px solid #000;text-align: center;padding: 5px;'>产品名称</td><td width='40%' style='border-bottom: 1px solid #000;border-right: 1px solid #000;text-align: center;padding: 5px;'>理化指标</td><td width='40%' style='border-bottom: 1px solid #000;border-right: 1px solid #000;text-align: center;padding: 5px;'>处理标准</td></tr></tbody></table><p>2、如到货产品物理、化学指标及其它要求不符合协议要求，但未达到乙方退货的条件，双方可协商解决，如双方不能协商一致，申请钢源保平台介入，钢源保将按以下标准处理:</p><table width='100%' cellspacing='0' cellpadding='0' style='border-top: 1px solid #000;border-left: 1px solid #000;margin: 10px auto;'><tbody><tr><td width='20%' style='border-bottom: 1px solid #000;border-right: 1px solid #000;text-align: center;padding: 5px;'>产品名称</td><td width='30%' style='border-bottom: 1px solid #000;border-right: 1px solid #000;text-align: center;padding: 5px;'>理化指标</td><td width='50%' style='border-bottom: 1px solid #000;border-right: 1px solid #000;text-align: center;padding: 5px;'>处理标准</td></tr><tr><td style='border-bottom: 1px solid #000;border-right: 1px solid #000;text-align: center;padding: 5px;'>煅烧煤增碳剂</td><td style='border-bottom: 1px solid #000;border-right: 1px solid #000;text-align: center;padding: 5px;'>9909</td><td style='border-bottom: 1px solid #000;border-right: 1px solid #000;text-align: center;padding: 5px;'>每高于基准值8.0%，单价下调9.0%</td></tr></tbody></table><p>3、乙方需在15个自然日内对产品进行检测并提出异议处理，否则视为采购商对到货产品无质量异议，系统将默认确认付款，由此产生的损失由乙方自行承担。</p><p>4、在未确认到货产品无质量问题之前，乙方不应对到货产品进行加工和使用，否则供货商有权认为采购商对到货产品无质量异议，由此产生的损失由采购商自行承担。</p> <p> 5、如乙方对到货产品检测后有质量异议，且不能与供货商协商一致，可申请钢源保介入：</p > <p>（1）双方均需出具委托函，委托平台通过具备相关资质的第三方检测机构进行检测，以其出具的检测报告正本为准。</p> <p>（2）交易双方依照全国耐火材料标准化技术委员会最新制定的《耐火原料抽样检验规则》、《定形耐火制品验收抽样检验规则》和《不定形耐火材料 第2部分：取样》共同取样后，将样品交由平台送第三方检测机构进行检测。</p > <p>（3）钢源保平台指定第三方检测机构为“国家耐火材料质量监督检验中心”。</p > <h3> 四、货款的结算及发票</h3><p>1、乙方对货物验收合格后，通过钢源保的“确认付款”功能将货款支付给甲方，如乙方未进行“确认付款”操作，且在乙方收货之日起 15日内未对货物提出质量异议，货款将自动付给甲方。如乙方未足量收货，差额部分的货款可通过钢源保平台“修正金额”功能退回。</p><p>2、乙方通过钢源保交易账户以现金方式向甲方支付货款。</p><p>3、乙方付款账户为，账户：3110710041254128102  开户行：中信银行唐山北新道支行；甲方收款账户为，账户：3110710041254128906，开户行：中信银行唐山北新道支行。</p><p> 4、乙方确认付款后，供方须在7日内将发票邮寄给需方。因甲方擅自作废、冲红字等原因导致的发票无法使用或进项税无法抵扣的，其损失由甲方承担，乙方保留永久追溯权。</p><h3>五、退货及费用处理</h3> <p> 1、如货物不符合协议约定，乙方退货，甲方负责运输并承担退货往返运费，按照甲方实际收货数量为准核算退货金额。</p> <p> 2、若甲方发货时不含运费，甲方一并承担退货的发货运费，甲方须将发货运费转入甲方在钢源保开具的保证金账户，并同意钢源保平台在甲方收到退货后自动支付给乙方。</p> <p> 3、双方已经确定货物需要退货处理后，甲方须在退货约定达成之日（不包含）起15日内负责将货物自行运离卸货地点，超过15日时乙方有权每日按货款的千分之三收取管理费。</p> <p> 4、如货物符合协议约定，乙方退货的，乙方负责运输并承担退货往返运费。</p><h3> 六、通知与送达</h3><p> 1、甲、乙双方因履行本合同而相互发出或者提供的所有通知、文件、资料，均以落款地址以传真、邮寄或电子邮件方式送达，一方如果迁址或者变更传真、地址、电子信箱信息的，应当书面通知对方。</p ><p> 2、通过传真方式发送的，在发出传真时视为送达；以邮寄方式发送的，挂号寄出或者投邮当日视为送达；以电子邮件方式发送的，自发出时起24小时内视为送达。</p ><h3> 七、争议的解决</h3><p> 1、本协议的未尽事宜，遵循《钢源保交易规则》处理；如遇到《钢源保交易规则》未涉及的条款，双方协商解决，如协商不成，当事人双方同意在合同签订地点所在地人民法院以诉讼方式解决。</p ><p> 2、违约责任：如甲乙双方中一方单方面解除合同，违约方向守约方赔付违约金，违约金按合同金额的20 % 计算。</p> <p>3、免责条款：任何一方由于不可抗力原因不能履行合同时，应在不可抗力事件结束后3日内向对方通报，在取得不可抗力证明后，可免除相应的违约责任。</p> <h3>八、合同有效期</h3><p>自合同签订之日开始，合同有效期为34天</p>" +
//                    "<p>&nbsp;</p>" +
//                    "<p>&nbsp;</p>" +
//                    "<p>&nbsp;</p>" +
//                    "<p>&nbsp;</p>" +
//                    "<p>" +
//                    "<table order='0' width='100%'><tbody><tr><td width='60%'>甲方单位：高星辰供货公司</td><td width='40%'>乙方单位：高星辰科技有限公司</td></tr><tr><td width='60%'>甲方签章</td><td width='40%'>乙方签章</td></tr></tbody></table></p></body></html>";
//            // worker.parseXHtml(pdfWriter, document, new FileInputStream("C:\\tmp\\a.htm"), null, new AsianFontProvider());
//            creataPDFByHTMLText(1, str);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
        //word2pdf("C:\\Users\\Administrator\\Desktop\\合同.docx");

//
//        ResponseEntity<byte[]> entityStream = RestTemplateUtil.getInstance("UTF-8").getForEntity("http://172.16.2.88:8888/group1/M00/00/01/rBACWF3AEQGAB6B7AAAySSx0Pp4633.doc", byte[].class);
//        byte[] bytes = entityStream.getBody();
//        InputStream inputStream = new ByteArrayInputStream(bytes);
//        System.err.println(word2pdf(inputStream));
    }


}