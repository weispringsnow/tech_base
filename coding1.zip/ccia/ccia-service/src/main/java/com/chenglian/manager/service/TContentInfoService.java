package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TContentInfo;

import java.util.List;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-18
 */

public interface TContentInfoService extends IService<TContentInfo> {
    IPage<TContentInfo> selectPage(Page<TContentInfo> page, TContentInfo model);

    int saveReturnInt(TContentInfo model);

    List<TContentInfo> select(TContentInfo model);

    TContentInfo selectTopRow(TContentInfo model);

    TContentInfo select(int iTitileIdentifier);

    List<TContentInfo> selectByNum(Integer num, TContentInfo model);
}

