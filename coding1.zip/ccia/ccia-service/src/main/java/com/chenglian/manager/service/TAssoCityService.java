package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TAssoCity;

import java.util.List;

/**
 * <p>
 * 省市陶协_市 服务类
 * </p>
 *
 * @author wla
 * @since 2020-02-14
 */

public interface TAssoCityService extends IService<TAssoCity> {
    IPage<TAssoCity> selectPage(Page<TAssoCity> page, TAssoCity model);

    List<TAssoCity> select(TAssoCity model);

    TAssoCity selectTopRow(TAssoCity model);

    int saveReturnInt(TAssoCity model);

    TAssoCity select(int id);

    void saveSortForAdd(TAssoCity model);

    void saveSortForEdit(TAssoCity model, TAssoCity model1);

    void updateAllSort(Integer proId);

}

