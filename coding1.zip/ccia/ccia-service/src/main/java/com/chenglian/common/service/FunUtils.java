package com.chenglian.common.service;

import com.chenglian.common.entity.AppSettingConfigs;
import com.chenglian.common.utils.Fun;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FunUtils {

    @Autowired
    private AppSettingConfigs appSettingConfigs;

    public boolean getIsLocal() {
        return appSettingConfigs.isLocal();
    }

    public boolean isManagerIPAddress() {
        String managerIPAddress = appSettingConfigs.getManagerIPAddress();
        if (StringUtils.isBlank(managerIPAddress)) {
            return true;
        } else {
            String vip = Fun.getIP();
            if (getIsLocal() && vip.startsWith("172.16.")) {
                return true;
            }
            String[] managerIPAddressArray = managerIPAddress.split(",");
            for (String ip : managerIPAddressArray) {
                if (vip.equals(ip)) {
                    return true;
                }
            }
        }
        return false;
    }

    public String chineseSite() {
        return appSettingConfigs.getFrontDomain();
    }
}
