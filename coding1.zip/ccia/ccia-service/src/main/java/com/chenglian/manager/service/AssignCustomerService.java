package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.AssignCustomer;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 * 划分客户记录表 服务类
 * </p>
 *
 * @author wla
 * @since 2020-02-26
 */

public interface AssignCustomerService extends IService<AssignCustomer> {
    IPage<AssignCustomer> selectPage(Page<AssignCustomer> page,AssignCustomer model);
    List<AssignCustomer> select(AssignCustomer model);
    AssignCustomer selectTopRow(AssignCustomer model);
    int saveReturnInt(AssignCustomer model);
    AssignCustomer select(int id);

}

