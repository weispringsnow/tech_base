package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TAssessRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 * 资讯评论表(官网APP) 服务类
 * </p>
 *
 * @author wla
 * @since 2020-03-16
 */

public interface TAssessRecordService extends IService<TAssessRecord> {
    IPage<TAssessRecord> selectPage(Page<TAssessRecord> page,TAssessRecord model);
    List<TAssessRecord> select(TAssessRecord model);
    TAssessRecord selectTopRow(TAssessRecord model);
    int saveReturnInt(TAssessRecord model);
    TAssessRecord select(int id);
// 文章评论量
    Integer countInfoPinglunNum(Integer informationId);
}

