package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.Emagazine;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wla
 * @since 2020-03-03
 */

public interface EmagazineService extends IService<Emagazine> {
    IPage<Emagazine> selectPage(Page<Emagazine> page,Emagazine model);
    List<Emagazine> select(Emagazine model);
    Emagazine selectTopRow(Emagazine model);
    int saveReturnInt(Emagazine model);
    Emagazine select(int Identifier);

}

