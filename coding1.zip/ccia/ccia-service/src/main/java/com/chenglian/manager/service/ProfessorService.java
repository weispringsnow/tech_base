package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.Professor;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 * 陶瓷问诊-专家表 服务类
 * </p>
 *
 * @author wla
 * @since 2019-11-22
 */

public interface ProfessorService extends IService<Professor> {
    IPage<Professor> selectPage(Page<Professor> page,Professor model);
    int saveReturnInt(Professor model);
    List<Professor> select(Professor model);
    Professor selectTopRow(Professor model);
    Professor select(int id);

    List<Professor> getTopNum(int limit, Professor model);
}

