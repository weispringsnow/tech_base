package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.SelectOption;
import com.chenglian.manager.entity.TBackManage;

import java.util.List;

/**
 * <p>
 * 后台部门管理字典表 服务类
 * </p>
 *
 * @author weicx
 * @since 2019-11-21
 */

public interface TBackManageService extends IService<TBackManage> {
    IPage<TBackManage> selectPage(Page<TBackManage> page, TBackManage model);

    int saveReturnInt(TBackManage model);

    List<TBackManage> select(TBackManage model);

    TBackManage selectTopRow(TBackManage model);

    TBackManage select(int iBmIdentifier);

    List<SelectOption> getBackDepartment(boolean showDefault);

    void updateAllSort();

    void saveSortForAdd(TBackManage model);

    void saveSortForEdit(TBackManage model, TBackManage model1);

    boolean existNvcName(TBackManage model);
}

