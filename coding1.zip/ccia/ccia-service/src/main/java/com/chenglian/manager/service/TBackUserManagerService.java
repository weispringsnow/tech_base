package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.chenglian.manager.entity.TBackUserManager;
import com.chenglian.manager.entity.TBackUserManagerView;

import java.util.List;

/**
 * <p>
 * 后台用户管理表 服务类
 * </p>
 *
 * @author weicx
 * @since 2019-11-21
 */

public interface TBackUserManagerService extends IService<TBackUserManager> {
    IPage<TBackUserManager> selectPage(Page<TBackUserManager> page,TBackUserManager model);
    int saveReturnInt(TBackUserManager model);
    List<TBackUserManager> select(TBackUserManager model);
    TBackUserManager selectTopRow(TBackUserManager model);
    TBackUserManager select(int iBumIdentifier);
    TBackUserManagerView getBackUserRightToSaveSession(TBackUserManager tBackUserManager);
    TBackUserManager getBackUserByName(String name);

    boolean existUserName(TBackUserManager model);

    boolean existDepts(String ids);

    boolean existRoles(String ids);

}

