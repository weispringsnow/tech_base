package com.chenglian.manager.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.chenglian.manager.entity.TCounty;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */

public interface TCountyService extends IService<TCounty> {
    IPage<TCounty> selectPage(Page<TCounty> page,TCounty model);
    List<TCounty> select(TCounty model);
    TCounty selectTopRow(TCounty model);
    int saveReturnInt(TCounty model);
    TCounty select(int iCoIdentifier);

}

