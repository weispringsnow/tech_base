package com.chenglian.core.utils;


import com.chenglian.common.utils.Fun;
import com.chenglian.core.utils.propertyEditor.SpecialDateEditor;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;
import org.springframework.boot.web.server.ErrorPage;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;

@ControllerAdvice
public class GlobalExceptionAndInitBinderHandler {

    /**
     * 全局异常捕捉处理
     *
     * @param
     * @return
     */
    @ExceptionHandler(value = RuntimeException.class)
    @ResponseBody
    public Object defaultErrorHandler(Exception e) {
        return "服务器繁忙，请稍后重试！错误信息：" + Fun.getAllExceptionMsg(e);
    }

    /*
     * 表单提交日期绑定
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(String.class, new StringTrimmerEditor(true));
        binder.registerCustomEditor(Date.class, new SpecialDateEditor());
    }

    @Bean
    public WebServerFactoryCustomizer<ConfigurableWebServerFactory> webServerFactoryCustomizer() {
        return (factory -> {
            ErrorPage error404Page = new ErrorPage(HttpStatus.NOT_FOUND, "/error/page");
            factory.addErrorPages(error404Page);
        });

        /*
         * WebServerFactoryCustomizer<ConfigurableWebServerFactory> result = new
         * WebServerFactoryCustomizer<ConfigurableWebServerFactory>() {
         *
         * @Override public void customize(ConfigurableWebServerFactory factory) {
         * ErrorPage error404Page = new ErrorPage(HttpStatus.NOT_FOUND, "/404.do");
         * factory.addErrorPages( error404Page); } };
         *
         * //jdk 1.8 lambda return result;
         */
    }
}