package com.chenglian.core.utils.propertyEditor;


import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SpecialDateEditor extends PropertyEditorSupport {
    private static final Logger logger = LoggerFactory.getLogger(SpecialDateEditor.class);

    @Override
    public void setAsText(String text) throws IllegalArgumentException {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        if (StringUtils.isBlank(text)) {
            setValue(null);
            return;
        }
        try {
            date = format.parse(text);
        } catch (ParseException e) {
            format = new SimpleDateFormat("yyyy-MM-dd");
            try {
                date = format.parse(text);
            } catch (ParseException e1) {
                format = new SimpleDateFormat("yyyy/MM/dd");
                try {
                    date = format.parse(text);
                } catch (ParseException e2) {
                    format = new SimpleDateFormat("yyyy年MM月dd日");
                    try{
                        date = format.parse(text);
                    }catch (Exception e3){
                        logger.error("自动绑定日期数据出错", e);
                    }

                }
            }
        }
        setValue(date);
    }
}