package com.chenglian.core.config;

import com.alibaba.fastjson.JSON;
import com.chenglian.common.utils.JsoupUtil;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.*;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

public class XssHttpServletRequestWrapper extends HttpServletRequestWrapper {

	public XssHttpServletRequestWrapper(HttpServletRequest request) {
		super(request);
	}

//	@Override
//	public String getHeader(String name) {
//		return JsoupUtil.clean(super.getHeader(name));
//	}

	@Override
	public String getQueryString() {
		return JsoupUtil.clean(super.getQueryString());
	}

	@Override
	public String getParameter(String name) {
		return JsoupUtil.clean(super.getParameter(name));
	}

	@Override
	public String[] getParameterValues(String name) {
		String[] values = super.getParameterValues(name);
		if (values != null) {
			int length = values.length;
			String[] escapseValues = new String[length];
			for (int i = 0; i < length; i++) {
				escapseValues[i] = JsoupUtil.clean(values[i]);
			}
			return escapseValues;
		}
		return values;
	}

	@Override
	public ServletInputStream getInputStream() throws IOException {
		String str = getRequestBody(super.getInputStream());
		Map<String, Object> map = JSON.<Map<String, Object>>parseObject(str, HashMap.class);
		Map<String, Object> resultMap = new HashMap<>(map.size());
		for (String key : map.keySet()) {
			Object val = map.get(key);
			if (map.get(key) instanceof String) {
				resultMap.put(key, JsoupUtil.clean(val.toString()));
			} else {
				resultMap.put(key, val);
			}
		}
		str = JSON.toJSONString(resultMap);
		final ByteArrayInputStream bais = new ByteArrayInputStream(str.getBytes());
		return new ServletInputStream() {
			@Override
			public int read() throws IOException {
				return bais.read();
			}

			@Override
			public boolean isFinished() {
				return false;
			}

			@Override
			public boolean isReady() {
				return false;
			}

			@Override
			public void setReadListener(ReadListener listener) {
			}
		};
	}

	private String getRequestBody(InputStream stream) {
		String line = "";
		StringBuilder body = new StringBuilder();
		int counter = 0;

		// 读取POST提交的数据内容
		BufferedReader reader = new BufferedReader(new InputStreamReader(stream, Charset.forName("UTF-8")));
		try {
			while ((line = reader.readLine()) != null) {
				body.append(line);
				counter++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return body.toString();
	}

}
