package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-12-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TMessage implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键标识
     */
    @TableId(value = "i_m_identifier", type = IdType.AUTO)
    private Integer iMIdentifier;

    /**
     * 登录id
     */
    private Integer iUserId;

    /**
     * 短信内容
     */
    private String nvcMessageContent;

    /**
     * 发送时间
     */
    private Date dtAddTime;

    /**
     * 手机号
     */
    private String nvcPhone;

}
