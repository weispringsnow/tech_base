package com.chenglian.manager.entity;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-11-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewBackUser implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    private Integer iBumIdentifier;

    /**
     * 后台用户管理 账号
     */
    private String nvcManagerName;

    /**
     * 姓名
     */
    private String nvcName;

    private Integer isSuper;

    private Boolean isDelete;

    /**
     * 业务员所在部门
     */
    private String nvcDepartmentName;

    /**
     * 名称
     */
    private String nvcRoleName;

    private String nvcPermission;

}
