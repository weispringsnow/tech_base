package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-12-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewBrand implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 审核状态(1不通过)
     */
    private Integer iState;

    /**
     * 标识
     */
    private Integer iUbIdentifier;

    /**
     * 标识
     */
    private Integer iBiIdentifier;

    /**
     * 品牌名称
     */
    private String nvcBrandName;

    /**
     * 首写字母
     */
    private String cFirstLetter;

    /**
     * 品牌logo
     */
    private String nvcBrandLogo;
    /**
     * 品牌简介
     */
    private String nvcBrandAbstract;

    /**
     * 发布时间
     */
    private Date dtReleaseTime;

    /**
     * 发布时间
     */
    private Boolean isDelete;

    /**
     * 品牌类型
     */
    private Integer iGfIdentifier;
    /**
     * 品牌类型
     */
    private Integer iSort;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    @TableField(exist = false)
    private String orderByStr;

}
