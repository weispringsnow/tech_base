package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 后台角色管理表
 * </p>
 *
 * @author weicx
 * @since 2019-11-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TRoleManage implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_rm_identifier", type = IdType.AUTO)
    private Integer iRmIdentifier;

    /**
     * 名称
     */
    private String nvcName;

    /**
     * 栏目菜单ID(后台菜单字典表主键)
     */
    private Integer iBmIdentifier;

    private String nvcPermission;

    /**
     * 添加时间
     */
    private Date dtAddTime;

}
