package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;

/**
 * <p>
 *
 * </p>
 *
 * @author zxq
 * @since 2019-12-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TWantMap implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "i_wp_identifier", type = IdType.AUTO)
    private Integer iWpIdentifier;

    @NotBlank(message = "企业名称不能为空")
    private String nvcCompanyName;

    @NotBlank(message = "联系人不能为空")
    private String nvcContactPerson;

    @NotBlank(message = "联系电话不能为空")
    private String nvcContactPhone;

    private String nvcMapName;

    private Date dtAddTime;

    /**
     * 联系状态（-1未联系 1已联系）
     */
    private Integer iState;

}
