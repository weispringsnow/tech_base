package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author zxq
 * @since 2019-11-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TMapDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识（地图明细）
     */
    private Integer iMdIdentifier;

    /**
     * 地图标题id
     */
    private Integer iMtIdentifier;

    /**
     * 是否删除
     */
    private Boolean isDelete;

    /**
     * 用户id
     */
    private Integer iUiIdentifier;

    /**
     * 添加时间
     */
    private Date dtAddTime;

    /**
     * 修改时间
     */
    private Date dtUpdateTime;

}
