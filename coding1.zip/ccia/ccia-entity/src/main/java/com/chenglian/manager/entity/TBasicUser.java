package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-11-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TBasicUser implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_bu_identifier", type = IdType.AUTO)
    private Integer iBuIdentifier;

    /**
     * 用户名
     */
    private String nvcName;

    /**
     * 密码(MD5)
     */
    private String nvcPasswordMd5;

    /**
     * 密码(DES)
     */
    private String nvcPasswordDes;

    /**
     * 用户类型
     */
    private Integer iUserType;

    /**
     * 注册时间
     */
    private Date dtResignTime;

    /**
     * 最近登录时间
     */
    private Date dtLatestLoginTime;

    /**
     * 登录来源(1Android/2iOS)
     */
    private Integer iLoginResourse;

    /**
     * 最近跟踪记录时间
     */
    private Date dtLatestFollowTime;

    /**
     * 来源平台（1：名录；2：礼购；） 表示在哪儿登陆过，多个来源用 逗号隔开
     */
    private String nvcLoginResourse;

    /**
     * 注册来源（1陶瓷大师、2陶瓷名录、3陶瓷快讯、4陶瓷礼购、5陶瓷会刊、6银兴陶）
     */
    private Integer iRegisterSource;

    /**
     * 协会会员0否1是
     */
    private Boolean isAssociateMember;

    /**
     * 是否挂图0否1是
     */
    private Boolean isWallMap;

    /**
     * 协会会员编码
     */
    private String associateCode;

    /**
     * 地图坐标X
     */
    private String amapX;

    /**
     * 地图坐标Y
     */
    private String amapY;

    /**
     * 协会会员对应的名字
     */
    private String associateName;

    /**
     * 协会会员对应的地区
     */
    @TableField(exist = false)
    private String associateArea;

}
