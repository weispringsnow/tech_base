package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TCeramicData implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 标题
     */
    private String title;

    /**
     * 审核状态(1待审核 2审核通过 3审核未通过)
     */
    private Integer state;

    /**
     * 来源(原创:中国陶瓷官网)
     */
    private String source;

    /**
     * 发布时间
     */
    private Date uploadTime;

    /**
     * 图片
     */
    private String image;

    /**
     * 导读
     */
    private String intro;

    /**
     * 详情内容
     */
    private String content;

}
