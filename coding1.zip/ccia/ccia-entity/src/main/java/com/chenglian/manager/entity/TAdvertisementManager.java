package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-11-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TAdvertisementManager implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_am_identifier", type = IdType.AUTO)
    private Integer iAmIdentifier;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 广告名称
     */
    private String nvcName;

    /**
     * 广告类型：1启动页 2APP首页 3PC首页
     */
    private Integer iType;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    /**
     * 开始时间
     */
    private Date dtBeginTime;

    /**
     * 结束时间
     */
    private Date dtEndTime;

    /**
     * 添加时间
     */
    private Date dtAddTime;

    /**
     * 广告排序：1：位置1；2：位置2；3：位置3
     */
    private Integer iSort;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

    /**
     * 广告图片
     */
    private String nvcImage;

    private String nvcUiUrl;

    /**
     * 广告关联：1：企业用户；2：外部链接；3：无链接
     */
    private Integer iAdRelation;

}
