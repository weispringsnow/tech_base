package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.chenglian.common.constant.VipLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author wla
 * @since 2019-11-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("view_manager_information")
public class ViewManagerInformation extends AppOtherData implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    private Integer iMiIdentifier;

    /**
     * 标题
     */
    private String nvcTitle;

    /**
     * 来源
     */
    private String nvcSource;

    /**
     * 1、资讯    2、视频
     */
    private Integer iType;

    /**
     * 内容
     */
    private String nvcContent;

    /**
     * 从 内容里 提取的 图片 集合  保存一条或者三条 图片地址
     */
    private String nvcImagesArray;

    /**
     * 上传文件 视频地址
     */
    private String nvcUploadFile;

    /**
     * 关键字
     */
    private String nvcKeyword;

    /**
     * 产区
     */
    private String nvcProductArea;

    /**
     * 频道ID 可以有多个频道id 中间用，分割，首尾也要加，
     */
    private String nvcMcIdentifiers;

    /**
     * 是否推荐(1是 / 0否)
     */
    private Boolean isRecommend;

    /**
     * 发布时间
     */
    private Date dtPublicTime;

    /**
     * 审核状态(0未审、1通过、2未通过)
     */
    private Integer iState;

    /**
     * 是否删除(1是 / 0否)
     */
    private Boolean isDelete;

    /**
     * 视频时长
     */
    private String nvcFileLength;

    private Integer clickAmount;

    private Integer recommendType;

    private String titleCustom;

    private Integer titleCustomFontsize;

    private String recommendedChannel;

    /**
     * 所属专题ID
     */
    private Integer iScIdentifier;

    /**
     * 所属专题显示产品编号
     */
    private String nvcProjectNum;

    /**
     * 是否置顶
     */
    private Integer isSetTop;

    /**
     * 是否原创   0  否   1是
     */
    private Boolean isOriginal;

    /**
     * 作者ID
     */
    private Integer iUiIdentifier;

    /**
     * 是否置顶（是否）（作者展示）
     */
    private Boolean isSetTopAuthor;

    private Integer iScType;

    /**
     * 责任人
     */
    private Integer iResponsibleId;

    /**
     * 轮播图片
     */
    private String nvcImagesUpload;

    /**
     * 广告类型（PC：1 APP：2）
     */
    private Integer iAdType;
    /**
     * 频道名称
     */
    private String scName;

    // 查询时间用
    @TableField(exist = false)
    private Date bgTime;
    @TableField(exist = false)
    private Date edTime;
    @TableField(exist = false)
    private String orderStr;

    /**
     * like or 标题
     */
    @TableField(exist = false)
    private String[] keywords;

    //    4.0 添加
    /**
     * 关联的企业ID
     */
    private Integer comId;
    /**
     * 关联的企业名称
     */
    private String comName;
    /**
     * 企业文章排序服务等级(9VIP>8GOLD>1NO)
     */
    private String comSortType;

    // 编辑显示用的
    public String getComType() {
        if (VipLevel.VIP.equals(comSortType)) return "VIP会员";
        if (VipLevel.GOLD.equals(comSortType)) return "黄金会员";
        return "无推举特权或本文推举已过期";
    }

    // 编辑显示用的
    public Boolean isBindVip() {
        if (comId == null || comId <= 0) return false;
        if (VipLevel.VIP.equals(comSortType)) return true;
        if (VipLevel.GOLD.equals(comSortType)) return true;
        return false;
    }

    /**
     * 企业文章排序
     */
    private Integer comSort;
    /**
     * 推举截至时间
     */
    private Date endVipTime;
    // 4.0 ↑

}
