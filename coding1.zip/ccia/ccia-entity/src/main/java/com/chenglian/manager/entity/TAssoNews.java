package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 省市陶协新闻
 * </p>
 *
 * @author wla
 * @since 2020-02-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TAssoNews implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 所属省ID
     */
    private Integer proId;

    /**
     * 所属市ID
     */
    private Integer cityId;

    /**
     * 责任人ID
     */
    private Integer responsibleId;

    /**
     * 新闻标题
     */
    private String title;

    /**
     * 封面图片
     */
    private String picture;

    /**
     * 新闻内容
     */
    private String content;

    /**
     * 发布时间
     */
    private Date upTime;

    /**
     * 原文链接(若文章来自其他协会)
     */
    private String targetUrl;

    /**
     * 排序
     */
    private Integer sort;

    // 仅展示省级文章
    @TableField(exist = false)
    private Boolean pNewsOnly;
    @TableField(exist = false)
    private Date bgTime;
    @TableField(exist = false)
    private Date edTime;

}
