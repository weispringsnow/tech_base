package com.chenglian.manager.entity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2020-03-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TMyShowChannel implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 我的频道表ID(官网APP)
     */
    private Integer id;

    /**
     * 用户基础表ID
     */
    private Integer userId;

    /**
     * 频道ID(,拼接)
     */
    private String channelIds;

    /**
     * 频道名称
     */
    private String channelNames;

    /**
     * 类型1为我的频道，2其余频道
     */
    private Integer type;

}
