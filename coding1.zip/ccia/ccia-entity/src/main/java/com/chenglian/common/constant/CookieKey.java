package com.chenglian.common.constant;

public class CookieKey {

    // 陶瓷官网app
    public static final String APP_CHINACERAMICS_USER_ID = "UserID";
    public static final String APP_CHINACERAMICS_PASSWORD = "Pw";

}
