package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-11-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TGoodsFirst implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_gf_identifier", type = IdType.AUTO)
    private Integer iGfIdentifier;

    /**
     * 产品一级
     */
    private String nvcGoodsFirstName;

    /**
     * 是否删除(1是/-1否)
   
     */
    private Boolean isDelete;

}
