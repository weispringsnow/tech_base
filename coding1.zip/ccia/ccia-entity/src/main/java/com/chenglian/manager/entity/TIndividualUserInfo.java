package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;

/**
 * <p>
 *
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TIndividualUserInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_iui_identifier", type = IdType.AUTO)
    private Integer iIuiIdentifier;

    /**
     * 用户ID
     */
    private Integer iBuIdentifier;

    /**
     * 姓名
     */
    private String nvcName;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 所属企业
     */
    private String nvcBelongCompany;

    /**
     * 责任人ID
     */
    private Integer iRiIdentifier;

    /**
     * 绑定企业ID
     */
    private Integer iUiIdentifierBind;

    /**
     * 是否删除(1是/-1否)
     */
    private Boolean isDelete;

    /**
     * 头像
     */
    private String nvcHeadImage;

    // 获取头像,为空则使用默认头像
    public String getShowHeadImage() {
        if (StringUtils.isBlank(nvcHeadImage)) {
            return "";
        }
        return nvcHeadImage;
    }

}
