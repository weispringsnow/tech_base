package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-12-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TAskJoin implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_aj_identifier", type = IdType.AUTO)
    private Integer iAjIdentifier;

    /**
     * 用户ID
     */
    private Integer iBuIdentifier;

    /**
     * 用户
     */
    private String nvcName;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    /**
     * 时间
     */
    private Date dtAskJoinTime;

    /**
     * 来源(1Andriod / 2IOS/3 pc端)
     */
    private Integer iLoginSource;

    /**
     * 回复状态(1是/0否)
     */
    private Boolean isReply;

    /**
     * 责任人
     */
    private String nvcResponsible;

    /**
     * 回复内容
     */
    private String nvcFeedContent;

}
