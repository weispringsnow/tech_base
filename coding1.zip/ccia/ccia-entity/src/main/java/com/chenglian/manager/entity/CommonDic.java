package com.chenglian.manager.entity;

import java.util.*;

/**
 * @author ：yc
 * @date ：Created in 2019/11/16 14:27
 * @description ：
 */
public class CommonDic {
    public static List<String> getLetter() {
        return Arrays.asList("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
    }

    public static List<Integer> getYear() {
        return Arrays.asList(2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035, 2036, 2037, 2038, 2039, 2040, 2041, 2042, 2043, 2044, 2045, 2046, 2047, 2048, 2049, 2050, 2051, 2052, 2053, 2054, 2055, 2056, 2057, 2058, 2059, 2060, 2061, 2062, 2063, 2064, 2065, 2066, 2067, 2068, 2069, 2070, 2071, 2072, 2073, 2074, 2075, 2076, 2077, 2078, 2079, 2080, 2081, 2082, 2083, 2084, 2085, 2086, 2087, 2088, 2089, 2090, 2091, 2092, 2093, 2094, 2095, 2096, 2097, 2098, 2099);
    }

    public static List<Integer> getMonth() {
        return Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
    }

    public static Map<String, Integer> getLetterMap() {
        Map<String, Integer> map = new LinkedHashMap<>();
        map.put("key", 1);
        return map;
    }

    /**
     * 跟踪记录类型（1 调研信息 2 会员服务 3 网站广告 4 地图广告 5 杂志广告）
     */
    public static Map<Integer, String> tracksType() {
        Map<Integer, String> tempList = new LinkedHashMap<>();
        tempList.put(1, "调研信息");
        tempList.put(2, "会员服务");
        tempList.put(3, "网站广告");
        tempList.put(4, "地图广告");
        tempList.put(5, "杂志广告");
        return tempList;
    }

    public static Map<String, String> yuanliaounits(boolean hasDefault) {
        Map<String, String> map = new LinkedHashMap<>();
        if (hasDefault) {
            map.put("请选择", "");
        }
        map.put("元/公斤", "元/公斤");
        map.put("元/吨", "元/吨");
        return map;
    }

    public static Map<String, String> yuanliaounit(boolean hasDefault) {
        Map<String, String> map = new LinkedHashMap<>();
        if (hasDefault) {
            map.put("请选择", "");
        }
        map.put("元/吨", "元/吨");
        map.put("元/公斤", "元/公斤");
        return map;
    }

    public static String sexStr(Integer iSex) {
        if (iSex == null) {
            return "";
        }
        switch (iSex) {
            case 1:
                return "男";
            case 2:
                return "女";
            case 3:
                return "不限";
        }
        return "";
    }

    public static String educationStr(Integer nvcEducationRequirements) {
        if (nvcEducationRequirements == null) {
            return "";
        }
        switch (nvcEducationRequirements) {
            case 1:
                return "本科";
            case 2:
                return "专科";
            case 3:
                return "不限";
        }
        return "";
    }

    public static Map<Integer, String> sex() {
        Map<Integer, String> map = new LinkedHashMap<>();
        map.put(3, "不限");
        map.put(1, "男");
        map.put(2, "女");
        return map;
    }

    public static Map<Integer, String> education() {
        Map<Integer, String> map = new LinkedHashMap<>();
        map.put(3, "不限");
        map.put(1, "本科");
        map.put(2, "专科");
        return map;
    }

    public static Map<String, String> department(boolean hasDefault) {
        Map<String, String> map = new LinkedHashMap<>();
        if (hasDefault) {
            map.put("请选择", "");
        }
        map.put("销售部门", "销售部门");
        map.put("市场部门", "市场部门");
        map.put("采购部门", "采购部门");
        map.put("技术部门", "技术部门");
        map.put("生产部门", "生产部门");
        map.put("综合部门", "综合部门");
        map.put("信息部门", "信息部门");
        map.put("品牌部门", "品牌部门");
        map.put("推广部门", "推广部门");
        map.put("招商部门", "招商部门");
        map.put("企管部门", "企管部门");
        map.put("外贸部门", "外贸部门");
        map.put("设备部门", "设备部门");
        map.put("其他", "其他");
        return map;
    }

    public static Map<Object, String> noYes() {
        Map<Object, String> map = new LinkedHashMap<>();
        map.put(false, "否");
        map.put(true, "是");
        return map;
    }

    public static Map<Object, String> yesNo() {
        Map<Object, String> map = new LinkedHashMap<>();
        map.put(true, "是");
        map.put(false, "否");
        return map;
    }

    public static List<Integer> position() {
        List<Integer> list = new ArrayList<>();
        for (int i = 1; i <= 9; i++) {
            list.add(i);
        }
        return list;
    }

    // 协会栏目
    public static List<Map<String, String>> websiteColumns() {
        List<Map<String, String>> list = new ArrayList<>();
        List<String> values = Arrays.asList("1-1", "2-1", "3-1", "4-1", "0-3", "0-4", "0-6", "0-7", "0-8", "0-10", "8-12", "9-12");
        List<String> texts = Arrays.asList("工作报告", "协会动态", "统计分析", "通知公告", "行业动态", "综合新闻", "海外动态", "行业标准", "专利技术", "展会信息", "陶瓷之都", "陶瓷名城");
        for (int i = 0; i < values.size(); i++) {
            Map<String, String> map = new HashMap<>();
            map.put("value", values.get(i));
            map.put("text", texts.get(i));
            list.add(map);
        }
        return list;
    }

}
