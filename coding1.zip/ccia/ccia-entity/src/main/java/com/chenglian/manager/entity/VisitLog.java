package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 访问统计表
 * </p>
 *
 * @author wla
 * @since 2020-02-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class VisitLog implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 访问者IP
     */
    private String ip;

    /**
     * 访问时间
     */
    private Date logTime;

    /**
     * 访问地址
     */
    private String targetUrl;

    /**
     * 访问者IP所在位置
     */
    private String location;

    /**
     * basic账号ID
     */
    private Integer basicUserId;

    /**
     * 账号用户名
     */
    private String basicUserName;

    /**
     * 访问者登录账号ID
     */
    private Integer userInfoId;

    /**
     * 公司名称
     */
    private String companyName;

    /**
     * 责任人(客户经理)ID
     */
    private Integer managerId;

    /**
     * 所选服务(会员状态)
     */
    private String service;

    // 同一ip有多少条记录
    @TableField(exist = false)
    private Integer countLog;
    @TableField(exist = false)
    private Date bgTime;
    @TableField(exist = false)
    private Date edTime;
    @TableField(exist = false)
    private String proName;
    @TableField(exist = false)
    private String cityName;


}
