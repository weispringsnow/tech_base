package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.chenglian.common.entity.OutParams;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-12-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewFollowLog implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    private Integer iFlIdentifier;

    /**
     * 用户ID
     */
    private Integer iUserIdentifier;

    /**
     * 联系方式ID
     */
    private Integer iCiIdentifier;

    /**
     * 跟踪记录
     */
    private String nvcFollowLog;

    /**
     * 是否有效(1是/-1否)
     */
    private Boolean isEnable;

    /**
     * 通话时长
     */
    private String nvcCallTime;

    /**
     * 跟踪人
     */
    private String nvcFollowPersion;

    /**
     * 跟踪时间
     */
    private Date dtFollowTime;

    /**
     * 跟踪记录图片
     */
    private String nvcPicUrl;

    /**
     * 跟踪类别
     */
    private Integer iTrackType;

    /**
     * 跟踪人id
     */
    private Integer iBumIdentifier;

    /**
     * 联系人
     */
    private String nvcContact;

    /**
     * 手机
     */
    private String nvcMobile;
    /**
     * 用户类型
     */
    private Integer iUserType;
    /**
     * 用户名
     */
    private String nvcName;


    /**
     * 跟踪类别
     */
    @TableField(exist = false)
    private String trackTypeCondition;

    @TableField(exist = false)
    private OutParams outParams;

}
