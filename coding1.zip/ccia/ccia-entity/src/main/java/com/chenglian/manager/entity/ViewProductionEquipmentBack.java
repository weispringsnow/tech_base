package com.chenglian.manager.entity;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author wla
 * @since 2019-12-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewProductionEquipmentBack implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    private Integer iPeIdentifier;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 产品一级ID
     */
    private Integer iGfIdentifier;

    /**
     * 产品二级ID
     */
    private Integer iGsIdentifier;

    /**
     * 发布时间
     */
    private Date dtReleaseTime;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

    /**
     * 审核状态(1待审/2通过)
     */
    private Integer iState;

    /**
     * 产品二级
     */
    private String nvcEquipmentName;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

}
