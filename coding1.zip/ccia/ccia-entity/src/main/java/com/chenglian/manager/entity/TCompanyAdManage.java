package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-12-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TCompanyAdManage implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     *  主键
     */
    @TableId(value = "i_ad_identifier", type = IdType.AUTO)
    private Integer iAdIdentifier;

    /**
     * 企业编码
     */
    private Integer iUiIdentifier;

    /**
     * 图片地址
     */
    @TableField("pictureUrl")
    private String pictureUrl;

    /**
     * 图片标题
     */
    @TableField("pictureTitle")
    private String pictureTitle;

    /**
     * 图片位置
     */
    private Integer position;

    /**
     * 位置说明
     */
    @TableField("positionExplain")
    private String positionExplain;

    /**
     * 是否删除
     */
    private Boolean isDelete;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 是否显示
     */
    private Boolean isShow;

}
