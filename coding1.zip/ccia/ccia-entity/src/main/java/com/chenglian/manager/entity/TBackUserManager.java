package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 后台用户管理表
 * </p>
 *
 * @author weicx
 * @since 2019-11-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TBackUserManager implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_bum_identifier", type = IdType.AUTO)
    private Integer iBumIdentifier;

    /**
     * 后台用户管理 账号
     */
    private String nvcManagerName;

    /**
     * 密码
     */
    private String nvcManagerPassword;

    /**
     * 姓名
     */
    private String nvcName;

    /**
     * 所属部门
     */
    private Integer iDIdentifier;

    /**
     * 角色
     */
    private Integer iRmIdentifier;

    private Integer isSuper;

    private Boolean isDelete;

    private Integer iProtected;

    private Integer iProtectedCount;

    private Integer iHasprotectedCount;

}
