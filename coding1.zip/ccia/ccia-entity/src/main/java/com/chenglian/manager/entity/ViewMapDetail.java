package com.chenglian.manager.entity;
import java.util.Date;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author zxq
 * @since 2019-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewMapDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识（地图明细）
     */
    private Integer iMdIdentifier;

    /**
     * 地图标题id
     */
    private Integer iMtIdentifier;

    /**
     * 是否删除
     */
    private Boolean isDelete;

    /**
     * 用户id
     */
    private Integer iUiIdentifier;

    /**
     * 添加时间
     */
    private Date dtAddTime;

    /**
     * 修改时间
     */
    private Date dtUpdateTime;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    /**
     * 产品类型数组
     */
    private String dictErpCategory;

    /**
     * 法人
     */
    private String nvcLegalPerson;

    /**
     * 地图坐标X
     */
    private String amapX;

    /**
     * 地图坐标Y
     */
    private String amapY;

    /**
     * 地址
     */
    private String nvcAddress;

    /**
     * 联系人
     */
    @TableField(exist = false)
    private String nvcContact;

    /**
     * 手机
     */
    @TableField(exist = false)
    private String nvcMobile;

    /**
     * 企业类型ID
     */
    private Integer iCtiIdentifier;

}
