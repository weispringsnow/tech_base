package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2020-03-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TFeedBackFast implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 官网快捷通道反馈表ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 反馈者姓名
     */
    private String name;

    /**
     * 电话
     */
    private String phoneNum;

    /**
     * 反馈内容
     */
    private String content;

    /**
     * 反馈时间
     */
    private Date time;

    /**
     * 是否回复
     */
    private Boolean isReply;

    /**
     * 回复内容
     */
    private String replyContent;

    /**
     * 回复时间
     */
    private Date replyTime;

    /**
     * 回复者IDI(责任人)
     */
    private Integer replierId;

    // 查询时间用
    @TableField(exist = false)
    private Date bgTime;
    @TableField(exist = false)
    private Date edTime;

}
