package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 陶瓷营销-营销案例表
 * </p>
 *
 * @author wla
 * @since 2019-11-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class MarketCase implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 案例名称
     */
    private String name;

    /**
     * 案例图片
     */
    private String picture;

    /**
     * 上传时间
     */
    private Date uploadTime;

    /**
     * 案例内容
     */
    private String content;

}
