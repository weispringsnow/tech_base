package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 陶瓷设计作品表
 * </p>
 *
 * @author wla
 * @since 2019-11-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class DesignWorks implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 作品名称
     */
    private String name;

    /**
     * 设计者
     */
    private String author;

    /**
     * 作品分类(1建筑陶瓷-2卫生陶瓷-3日用陶瓷-4艺术陶瓷)
     */
    private String category;

    /**
     * 创作时间
     */
    private Date creationTime;

    /**
     * 上传时间
     */
    private Date uploadTime;

    /**
     * 作品图片
     */
    private String picture;

    /**
     * 作品简介
     */
    private String introduction;

}
