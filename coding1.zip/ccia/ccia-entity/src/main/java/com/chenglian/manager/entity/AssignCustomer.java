package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 划分客户记录表
 * </p>
 *
 * @author wla
 * @since 2020-02-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class AssignCustomer implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 账户(basic_user)id
     */
    private Integer userId;

    /**
     * 账户名
     */
    private String userName;

    /**
     * 企业(t_user_info)id
     */
    private Integer companyId;

    /**
     * 企业名称
     */
    private String companyName;

    /**
     * 原客户经理id
     */
    private Integer oldManagerId;

    /**
     * 新客户经理ID
     */
    private Integer newManagerId;

    /**
     * 操作人名称
     */
    private String operator;

    /**
     * 划分方式(1手动/2系统)
     */
    private Integer assignType;

    /**
     * 划分时间
     */
    private Date assignTime;

    @TableField(exist = false)
    private Date bgTime;
    @TableField(exist = false)
    private Date edTime;

}
