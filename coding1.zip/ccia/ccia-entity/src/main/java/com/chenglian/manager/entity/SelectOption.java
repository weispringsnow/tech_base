package com.chenglian.manager.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class SelectOption implements Serializable {
    private static final long serialVersionUID = 1L;

    public SelectOption() {
    }

    public SelectOption(Object name, Object value) {
        this.name = name;
        this.value = value;
    }

    private Object name;
    private Object value;
}

