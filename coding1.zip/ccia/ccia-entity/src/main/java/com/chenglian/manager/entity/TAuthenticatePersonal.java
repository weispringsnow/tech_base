package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2020-03-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TAuthenticatePersonal implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 个人用户认证信息表ID(官网APP)
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户基础表ID
     */
    private Integer userId;

    /**
     * 认证手机
     */
    private String mobile;

    /**
     * 姓名
     */
    private String name;

    /**
     * 身份证正面图片
     */
    private String idCardFront;

    /**
     * 身份证反面图片
     */
    private String idCardBack;

    /**
     * 是否认证
     */
    private Boolean isAuthenticate;

    /**
     * 认证说明（简介）
     */
    private String description;

}
