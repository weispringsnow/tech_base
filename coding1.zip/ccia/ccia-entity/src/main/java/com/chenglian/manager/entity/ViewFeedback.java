package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author wla
 * @since 2019-12-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewFeedback implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 用户名
     */
    private String nvcName;

    /**
     * 标识
     */
    private Integer iFbIdentifier;

    /**
     * 用户ID
     */
    private Integer iUserIdentifier;

    /**
     * 来源(1Andriod / 2IOS)
     */
    private Integer nvcSource;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 意见内容/音频路径
     */
    private String nvcOpinionContent;

    /**
     * 提交时间
     */
    private Date dtUploadTime;

    /**
     * 回复内容
     */
    private String nvcFeedContent;

    /**
     * 回复时间
     */
    private Date dtFeedTime;

    /**
     * 回复状态(1是/-1否)
     */
    private Boolean isReply;

    /**
     * 是否是语音(1是/-1否)
     */
    private Boolean isVoice;

    /**
     * 通话时长
     */
    private Integer iCallDuration;

    /**
     * 是否删除(1是/-1否)
     */
    private Boolean isDelete;

    /**
     * 标识
     */
    private Integer iIuiIdentifier;

    /**
     * 标识
     */
    private Integer iUiIdentifier;

    /**
     * 反馈类型标识
     */
    private Integer iFtIdentifier;

    /**
     * 反馈者姓名
     */
    private String nvcResponderName;

    /**
     * 责任人标识
     */
    private Integer iRiIdentifier;

    /**
     * 反馈图片(,分隔)
     */
    private String pics;

    // 获取图片数组
    public String[] getPicArray() {
        String[] pic = {};
        if (StringUtils.isBlank(pics)) {
            return pic;
        }
        return pics.split(",");
    }

    public String getPicFirst() {
        if (StringUtils.isBlank(pics)) {
            return "";
        }
        String[] strings = pics.split(",");
        if (strings.length <= 0) {
            return "";
        }
        return strings[0];
    }


    // 查询时间用
    @TableField(exist = false)
    private Date bgTime;
    @TableField(exist = false)
    private Date edTime;
}
