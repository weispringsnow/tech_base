package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2020-03-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TTipoffRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 爆料表ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户基础表id
     */
    private Integer userId;

    /**
     * 标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 回复内容
     */
    private String replyContent;

    /**
     * 是否回复(1回复/0未回复)
     */
    private Boolean isReply;

    /**
     * 爆料时间
     */
    private Date time;

    /**
     * 图片(以,分隔)
     */
    private String images;
    /**
     * 图片(以,分隔)
     */
    private List<String> imageList;

}
