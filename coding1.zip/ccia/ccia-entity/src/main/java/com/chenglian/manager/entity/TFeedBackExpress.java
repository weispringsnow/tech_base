package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-12-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TFeedBackExpress implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_f_identifier", type = IdType.AUTO)
    private Integer iFIdentifier;

    /**
     * 用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 手机
     */
    private String nvcMobilePhone;

    /**
     * 反馈内容
     */
    private String nvcContent;

    /**
     * 通话时长
     */
    private Integer iCallDuration;

    /**
     * 提交时间
     */
    private Date dtTime;

    /**
     * 回复内容
     */
    private String nvcReplyContent;

    /**
     * 回复时间
     */
    private Date dtReplyTime;

    /**
     * 回复状态(0未回复、1已回复)
     */
    private Integer iState;

    /**
     * 是否语音(1是 / 0否)
     */
    private Boolean isVoice;

    /**
     * 是否删除(1是 / 0否)
     */
    private Boolean isDelete;

    /**
     * 责任人
     */
    private Integer iResponsibleIdentifier;

    /**
     * 所属产品编号
     */
    private String nvcProjectNum;

}
