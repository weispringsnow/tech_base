package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 信息反馈表 message_feedback
 * </p>
 *
 * @author wla
 * @since 2019-11-22
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class MessageFeedback implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 反馈栏目(a陶瓷设计-b陶瓷问诊-c陶瓷营销)
     */
    private String type;

    /**
     * 反馈内容/问题
     */
    private String content;

    /**
     * 反馈者姓名
     */
    private String questioner;

    /**
     * 反馈者电话
     */
    private String questionerPhone;

    /**
     * 反馈时间
     */
    private Date time;

    /**
     * 回复内容
     */
    private String replyContent;

    /**
     * 回复者ID
     */
    private Integer replierId;

    /**
     * 回复时间
     */
    private Date replyTime;

    // 查询提问时间用
    @TableField(exist = false)
    private Date bgtime;
    @TableField(exist = false)
    private Date edtime;
}
