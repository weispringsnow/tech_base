package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
/**
 * <p>
 * 省市陶协_市
 * </p>
 *
 * @author wla
 * @since 2020-02-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TAssoCity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 市名
     */
    private String cityName;

    /**
     * 所属省份ID
     */
    private Integer proId;

    /**
     * 关联的市陶协链接
     */
    private String targetUrl;

    /**
     * 排序
     */
    private Integer sort;

}
