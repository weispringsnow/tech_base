package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-12-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TRecommendAdd implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_ra_identifier", type = IdType.AUTO)
    private Integer iRaIdentifier;

    /**
     * 用户ID
     */
    private Integer iBuIdentifier;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    /**
     * 姓名
     */
    private String nvcName;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 建议内容
     */
    private String nvcSuggest;

    /**
     * 回复状态(1是/-1否)
     */
    private Boolean isReply;

    /**
     * 回复内容
     */
    private String nvcFeedContent;

    /**
     * 责任人
     */
    private String nvcResponsible;

    /**
     * 提交时间
     */
    private Date dtUploadTime;

    /**
     * 登录来源(1Android/2iOS)
     */
    private Integer iLoginResourse;

}
