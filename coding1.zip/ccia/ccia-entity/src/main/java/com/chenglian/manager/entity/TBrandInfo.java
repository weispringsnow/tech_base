package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-11-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TBrandInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_bi_identifier", type = IdType.AUTO)
    private Integer iBiIdentifier;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 品牌名称
     */
    private String nvcBrandName;

    /**
     * 首写字母
     */
    private String cFirstLetter;

    /**
     * 品牌logo
     */
    private String nvcBrandLogo;

    /**
     * 品牌简介
     */
    private String nvcBrandAbstract;

    /**
     * 发布时间
     */
    private Date dtReleaseTime;

    /**
     * 是否删除(1是/0否)
   
     */
    private Boolean isDelete;

    /**
     * 品牌类型
     */
    private Integer iGfIdentifier;

    /**
     * 品牌排名
     */
    private Integer iSort;


    @TableField(exist = false)
    private String orderByStr;

}
