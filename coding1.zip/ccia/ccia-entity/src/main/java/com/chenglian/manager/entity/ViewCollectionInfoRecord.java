package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author wla
 * @since 2020-03-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewCollectionInfoRecord extends AppOtherData implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    private Integer id;

    /**
     * 用户ID(基础表)
     */
    private Integer userId;

    /**
     * 快讯文章ID
     */
    private Integer informationId;

    /**
     * 收藏时间
     */
    private Date cTime;

    /**
     * 收藏来源(123)
     */
    private Integer cSource;

    /**
     * 标题
     */
    private String nvcTitle;

    /**
     * 来源(1Android/2iOS 3/微官网)
     */
    private String nvcSource;

    /**
     * 1、资讯    2、视频
     */
    private Integer iType;

    /**
     * 从 内容里 提取的 图片 集合  保存一条或者三条 图片地址
     */
    private String nvcImagesArray;

    /**
     * 上传文件 视频地址
     */
    private String nvcUploadFile;

    /**
     * 视频时长
     */
    private String nvcFileLength;

    /**
     * 频道ID 可以有多个频道id 中间用，分割，首尾也要加，
     */
    private String nvcMcIdentifiers;
    /**
     * 频道名称
     */
    @TableField(exist = false)
    private String channelName;

}
