package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 最新活动表(官网APP)
 * </p>
 *
 * @author wla
 * @since 2020-04-01
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TLatestActivity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 最新活动表ID(官网APP)
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 活动标题
     */
    private String title;

    /**
     * 开始时间
     */
    private Date startTime;

    /**
     * 结束时间
     */
    private Date endTime;

    /**
     * 图片地址
     */
    private String image;

    /**
     * 说明
     */
    private String instruction;

    /**
     * 链接
     */
    private String link;

    /**
     * 提交时间
     */
    private Date submitTime;

    /**
     * 责任人ID
     */
    private Integer responsibleId;

    private String projectNum;

}
