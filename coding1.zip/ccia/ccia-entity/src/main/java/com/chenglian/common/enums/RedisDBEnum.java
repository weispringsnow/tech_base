package com.chenglian.common.enums;

import lombok.Getter;

@Getter
public enum RedisDBEnum {
    One(0),
    Two(1),
    Three(2),
    Four(3),
    Five(4),
    Six(5),
    Seven(6),
    Eight(7),
    Nine(8),
    Ten(9),
    Eleven(10),
    Twelve(11),
    Thirteen(12),
    Fourteen(13),
    Fifteen(14),
    Sixteen(15),
    Default(0);

    private Integer value;

    RedisDBEnum(Integer value) {
        this.value = value;
    }

    public static RedisDBEnum getEnumByValue(int value) {
        for (RedisDBEnum item : values()) {
            if (item.getValue().equals(value)) {
                return item;
            }
        }
        return null;
    }
}
