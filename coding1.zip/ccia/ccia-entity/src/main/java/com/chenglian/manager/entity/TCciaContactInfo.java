package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * <p>
 * 公司各大部门联系方式表
 * </p>
 *
 * @author wla
 * @since 2020-03-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TCciaContactInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final String dept1 = "大数据服务热线", dept2 = "大营销服务热线", dept3 = "大交易服务热线", dept4 = "大国际服务热线";
    public static final String type1 = "座机", type2 = "手机(微)", type3 = "钉钉";

    /**
     * 公司各大部门联系方式表ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 部门编码(1数据2营销3交易4国际)
     */
    private Integer department;

    /**
     * 联系方式编码(1座机2手机3钉钉)
     */
    private Integer type;

    /**
     * 联系号码
     */
    private String number;

    /**
     * 联系人姓名
     */
    private String name;

    public Map<Integer, String> getDepartmentMap() {
        Map<Integer, String> map = new LinkedHashMap<>();
        map.put(1, dept1);
        map.put(2, dept2);
        map.put(3, dept3);
        map.put(4, dept4);
        return map;
    }

    public Map<Integer, String> getTypeMap() {
        Map<Integer, String> map = new LinkedHashMap<>();
        map.put(1, type1);
        map.put(2, type2);
        map.put(3, type3);
        return map;
    }

    public String getDeptShow() {
        switch (department) {
            case 1:
                return dept1;
            case 2:
                return dept2;
            case 3:
                return dept3;
            case 4:
                return dept4;
            default:
                return "";
        }
    }

    public String getTypeShow() {
        switch (type) {
            case 1:
                return type1;
            case 2:
                return type2;
            case 3:
                return type3;
            default:
                return "";
        }
    }
}
