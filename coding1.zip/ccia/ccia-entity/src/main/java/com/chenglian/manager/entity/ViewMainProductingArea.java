package com.chenglian.manager.entity;
import java.math.BigDecimal;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author wla
 * @since 2019-12-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewMainProductingArea implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    private Integer iUiIdentifier;

    /**
     * 用户ID
     */
    private Integer iBuIdentifier;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    /**
     * 企业logo
     */
    private String nvcCompanyLogo;

    /**
     * 企业类型ID
     */
    private Integer iCtiIdentifier;

    /**
     * 经营模式ID
     */
    private Integer iMmIdentifier;

    /**
     * 省ID
     */
    private Integer iPIdentifier;

    /**
     * 市ID
     */
    private Integer iCIdentifier;

    /**
     * 区县ID
     */
    private Integer iCoIdentifier;

    /**
     * 地址
     */
    private String nvcAddress;

    /**
     * 邮编
     */
    private String nvcPostcode;

    /**
     * pc网址
     */
    private String nvcWebsite;

    /**
     * 手机版网址
     */
    private String nvcPhoneWebsite;

    /**
     * 微官网二维码
     */
    private String nvcWechat;

    /**
     * 简介
     */
    private String nvcAbstract;

    /**
     * 产值
     */
    private Double fOutput;

    /**
     * 销量
     */
    private String nvcSalesVolume;

    /**
     * 年收入额
     */
    private Double fYearIncome;

    /**
     * 所选服务
     */
    private String nvcServise;

    /**
     * 会员编号
     */
    private Integer iMemberNumber;

    /**
     * 责任人ID
     */
    private Integer iRiIdentifier;

    /**
     * 推荐序号，>0表示是推荐
     */
    private Integer iRecomendSort;

    /**
     * 是否推广
     */
    private String nvcExtension;

    /**
     * 更新时间
     */
    private Date dtUpdateTime;

    /**
     * 浏览量
     */
    private Integer iViewNumber;

    /**
     * 收藏量
     */
    private Integer iCollectNumber;

    /**
     * 产量
     */
    private BigDecimal dYield;

    /**
     * 生产线
     */
    private Integer iProductLine;

    /**
     * 单位
     */
    private String nvcUnit;

    /**
     * 注册资本
     */
    private String fRegisterMoney;

    /**
     * 法人
     */
    private String nvcLegalPerson;

    /**
     * 注册时间
     */
    private String nvcRegisterTime;

    /**
     * 潜在客户等级
     */
    private String nvcLevel;

    /**
     * 产品类型数组
     */
    private String dictErpCategory;

    /**
     * 是否后台注册
     */
    private Boolean isRegisteredBack;

    /**
     * 是否不在前台显示（1不显示  0显示   null显示）
     */
    private Boolean isNotShowFront;

    /**
     * 区县名称
     */
    private String nvcCounty;

    /**
     * 省名称
     */
    private String nvcProvince;

    /**
     * 市名称
     */
    private String nvcCity;

}
