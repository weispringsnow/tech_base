package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2020-03-03
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("Emagazine")
public class Emagazine implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "Identifier", type = IdType.AUTO)
    private Integer Identifier;

    @TableField("TheState")
    private Integer TheState;

    @TableField("UpdateTime")
    private Date UpdateTime;

    @TableField("Title")
    private String Title;

    @TableField("CoverImage")
    private String CoverImage;

    @TableField("Description")
    private String Description;

    @TableField("ShowAddress")
    private String ShowAddress;

    @TableField("Address")
    private String Address;

    @TableField("CoverImageSmall")
    private String CoverImageSmall;

}
