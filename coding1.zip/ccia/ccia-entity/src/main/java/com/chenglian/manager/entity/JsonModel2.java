package com.chenglian.manager.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class JsonModel2 {

    public JsonModel2() {
    }

    public JsonModel2(boolean success, String msg) {
        this.success = success;
        this.msg = msg;
    }

    public JsonModel2(boolean success, String msg, Object data) {
        this.success = success;
        this.msg = msg;
        this.data = data;
    }
    public Object otherData;
    public Boolean success;
    public String msg;
    public Object data;
    public Object nvcMobile;
}