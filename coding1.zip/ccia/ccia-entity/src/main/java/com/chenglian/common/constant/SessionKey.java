package com.chenglian.common.constant;

public class SessionKey {
    public static final String OPERATOR_USER = "operatorUser";
    public static final String T_CONTACT_INFO = "tContactInfo";
    public static final String I_USER_TYPE = "iUserType";

    // 陶瓷官网app
    public static final String APP_CHINACERAMICS_CHECK_LOGIN = "appChinaCeramicsCheckLogin";
    public static final String APP_CHINACERAMICS_USER_ID = "appChinaCeramicsUserId";

}
