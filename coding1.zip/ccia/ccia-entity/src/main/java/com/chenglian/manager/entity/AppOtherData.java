package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author ：yc
 * @date ：Created in 2020/3/19 14:55
 * @description ：app中包含的点赞评论播放量等
 */
@Data
@Accessors(chain = true)
public class AppOtherData {
    // 是否收藏
    @TableField(exist = false)
    private Boolean isCollect;
    // 是否点赞
    @TableField(exist = false)
    private Boolean isPraise;
    // 播放量
    @TableField(exist = false)
    private Integer bofangNum;
    // 点赞数
    @TableField(exist = false)
    private Integer dianzanNum;
    // 评论数
    @TableField(exist = false)
    private Integer pinglunNum;
}
