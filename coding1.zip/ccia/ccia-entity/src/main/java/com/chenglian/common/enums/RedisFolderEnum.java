package com.chenglian.common.enums;

import lombok.Getter;

@Getter
public enum RedisFolderEnum {

    Root("CCia"), Folder1("fd1"), Folder2("fd2"), Folder3("fd3"), Folder4("fd4"), Folder5("fd5"), Folder6("fd6");

    private String value;

    RedisFolderEnum(String value) {
        this.value = value;
    }

    public static RedisFolderEnum getEnumByValue(String value) {
        for (RedisFolderEnum item : values()) {
            if (item.getValue().equals(value)) {
                return item;
            }
        }
        return null;
    }

}
