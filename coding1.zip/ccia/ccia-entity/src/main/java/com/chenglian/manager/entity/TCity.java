package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TCity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_c_identifier", type = IdType.AUTO)
    private Integer iCIdentifier;

    /**
     * 省ID
     */
    private Integer iPIdentifier;

    /**
     * 市名称
     */
    private String nvcCity;

    /**
     * 排序
     */
    private Integer iSort;

}
