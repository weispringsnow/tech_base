package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author zxq
 * @since 2019-11-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("t_map_title")
public class TMapTitle implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识（地图标题）
     */
    @TableId(value = "i_mt_identifier", type = IdType.AUTO)
    private Integer iMtIdentifier;

    /**
     * 地图标题
     */
    private String nvcMapTitle;

    /**
     * 发布人
     */
    private String nvcPublishPerson;

    /**
     * 网站类型
     */
    private Integer iSiteType;

    /**
     * 前台是否显示（1 是  0否）
     */
    private Boolean isShow;

    /**
     * 是否删除
     */
    private Boolean isDelete;

    /**
     * 添加时间
     */
    private Date dtAddTime;

    /**
     * 修改时间
     */
    private Date dtUpdateTime;

    private String nvcMapTitleBackup;

    private String nvcMapStyle;
}
