package com.chenglian.manager.entity;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-12-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewTypeRecommendManagement implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    private Integer iTrmIdentifier;

    /**
     * 位置
     */
    private Integer iRate;

    /**
     * 标题
     */
    private String nvcTitle;

    /**
     * 分类ID
     */
    private Integer iTrIdentifier;

    /**
     * 是否前台显示(1是/-1否)
     */
    private Boolean isShow;

    /**
     * 是否显示数据列
     */
    private Boolean isDataShow;

    /**
     * 上传时间
     */
    private Date dtUploadTime;

    /**
     * 点击量
     */
    private Integer iClickNumber;

    /**
     * 是否删除(1是/-1否)
     */
    private Boolean isDelete;

    /**
     * 分类
     */
    private String nvcType;

}
