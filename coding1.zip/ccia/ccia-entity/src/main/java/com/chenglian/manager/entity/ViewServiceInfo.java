package com.chenglian.manager.entity;
import java.math.BigDecimal;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-12-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewServiceInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    private Integer iSiIdentifier;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 所选服务ID
     */
    private Integer iScIdentifier;

    /**
     * 开始时间
     */
    private Date dtBeginTime;

    /**
     * 结束时间
     */
    private Date dtOverTime;

    /**
     * 付费金额
     */
    private BigDecimal dPayAmount;

    /**
     * 开通年限
     */
    private Integer iOpenPeriod;

    /**
     * 办理人员
     */
    private String nvcHandlePerson;

    /**
     * 责任人ID
     */
    private Integer iRiIdentifier;

    /**
     * 是否删除(1是/-1否)
     */
    private Boolean isDelete;

    /**
     * 所选服务名称
     */
    private String nvcServiceName;

    /**
     * 推广Json
     */
    private String nvcExtension;

    /**
     * VIP会员---会员编号
     */
    private Integer iMemberNumber;

}
