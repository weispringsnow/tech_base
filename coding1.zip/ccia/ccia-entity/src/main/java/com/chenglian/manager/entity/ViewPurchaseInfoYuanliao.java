package com.chenglian.manager.entity;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author wla
 * @since 2019-12-10
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewPurchaseInfoYuanliao implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    private Integer iPiIdentifier;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 产品一级ID
     */
    private Integer iGfIdentifier;

    /**
     * 审核状态(1不通过)
     */
    private Integer iState;

    /**
     * 产品二级ID
     */
    private Integer iGsIdentifier;

    /**
     * 物理指标
     */
    private String nvcPhysicalIndex;

    /**
     * 化学指标
     */
    private String nvcChemicalIndex;

    /**
     * 月用量
     */
    private String nvcMonthUsed;

    /**
     * 采购类型ID
     */
    private Integer iPtIdentifier;

    /**
     * 发布时间
     */
    private Date dtReleaseTime;

    /**
     * 截止时间
     */
    private Date dtOverTime;

    /**
     * 详情
     */
    private String nvcDetail;

    /**
     * 图片
     */
    private String nvcImage;

    /**
     * 查看权限
     */
    private Integer iLevel;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

    /**
     * 采购类型
     */
    private String nvcPurchaseType;

    /**
     * 联系人
     */
    private String nvcContacts;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 电话
     */
    private String nvcPhone;

    /**
     * 产品名称
     */
    private String nvcGoodsName;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

}
