package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-12-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TCompanyAlbum implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_ca_identifier", type = IdType.AUTO)
    private Integer iCaIdentifier;

    /**
     * 企业用户ID
   
   
     */
    private Integer iUiIdentifier;

    /**
     * 图片名称
     */
    private String nvcPictureName;

    /**
     * 图片
     */
    private String nvcPicture;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

}
