package com.chenglian.manager.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TrackingStatistics implements Serializable {
    private Integer iTrackType;
    private Integer iBumIdentifier;
    private Integer allNum;
    private Integer validNum;
    private Integer allMinutes;
    private Integer personalNum;
    private Integer validPersonalNum;
    private Integer companyNum;
    private Integer validCompanyNum;
}
