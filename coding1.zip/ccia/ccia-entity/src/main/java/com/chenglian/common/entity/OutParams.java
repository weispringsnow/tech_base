package com.chenglian.common.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * 辅助查询类
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class OutParams {
    private String orderByStr;//做排序用
    private Integer search;//对应哪个分类下的关键字
    private Integer service;//所选服务
    private Integer service1;//所选服务(包含已过期)
    private String keyWord;//关键字内容
    private String sDate;//开始时间
    private String eDate;//结束时间
    private String contactNumber;//联系方式
    private String nvcProductName;//产品名称

}
