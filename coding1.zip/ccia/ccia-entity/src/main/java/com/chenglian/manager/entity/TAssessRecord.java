package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 资讯评论表(官网APP)
 * </p>
 *
 * @author wla
 * @since 2020-03-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TAssessRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 评论表ID
     */
    @TableId(value = "ID", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户基础表ID
     */
    private Integer userId;

    /**
     * 资讯文章ID
     */
    private Integer informationId;

    /**
     * 评论内容
     */
    private String content;

    /**
     * 评论时间
     */
    private Date time;

    // 每条评论被赞数量
    @TableField(exist = false)
    private Integer praiseNum;

}
