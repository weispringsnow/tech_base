package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-12-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewTaocifenleiguanli implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 发布时间
     */
    private Date dtReleaseTime;

    /**
     * 品牌名称
     */
    private String nvcBrandName;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    /**
     * 标识
     */
    private Integer iUbIdentifier;

    /**
     * 审核状态(1不通过)
     */
    private Integer iState;

    /**
     * 品牌ID
     */
    private Integer iBiIdentifier;

    @TableField(exist = false)
    private String orderByStr;

}
