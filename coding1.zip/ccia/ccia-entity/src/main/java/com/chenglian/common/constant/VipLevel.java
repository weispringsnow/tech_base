package com.chenglian.common.constant;

/**
 * @author ：wla
 * @date ：Created in 2020/3/25 16:22
 * @description ：给会员类型用的(目前主要用于文章排序)
 */
public class VipLevel {
    public static final String VIP = "9"; //vip
    public static final String GOLD = "8"; // 黄金会员
    public static final String NO = "1"; // 普通会员
//
//    public boolean comp(Integer target) {
//        if (VIP.intValue() == target) {
//            return true;
//        }
//        return false;
//    }
}
