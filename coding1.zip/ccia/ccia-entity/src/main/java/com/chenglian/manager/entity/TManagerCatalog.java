package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-11-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("t_manager_catalog")
public class TManagerCatalog implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_mc_identifier", type = IdType.AUTO)
    private Integer iMcIdentifier;

    /**
     * 会刊管理ID
     */
    private Integer iMjIdentifier;

    /**
     * 标题
     */
    private String nvcTitle;

    /**
     * 页数
     */
    private Integer iPages;

    /**
     * 栏目管理ID
     */
    private Integer iColumnId;

    /**
     * 是否删除(1是 / 0否)
     */
    private Boolean isDelete;

}
