package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-12-12
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TCeramicProductAreaManagement implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_cpam_identifier", type = IdType.AUTO)
    private Integer iCpamIdentifier;

    /**
     * 位置
     */
    private Integer iRate;

    /**
     * 省ID
     */
    private Integer iPIdentifier;

    /**
     * 市ID
     */
    private Integer iCIdentifier;

    /**
     * 区县ID
     */
    private Integer iCoIdentifier;

    /**
     * 陶瓷产区
     */
    private String nvcCeramicProductArea;

    /**
     * 前台显示(1是/-1否)
     */
    private Boolean isStayTop;

    /**
     * 时间
     */
    private Date dtTime;

    /**
     * 是否删除(1是/-1否)
     */
    private Boolean isDelete;

    /**
     * 自定义排序和限制行数
     * 举例：order by d_time desc limit 1
     */
    @TableField(exist = false)
    private String orderAndLimieStr;

}
