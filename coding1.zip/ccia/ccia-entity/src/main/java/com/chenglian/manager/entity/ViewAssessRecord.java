package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.TableName;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author wla
 * @since 2020-03-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("View_assess_record")
public class ViewAssessRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 评论表ID
     */
    @TableField("ID")
    private Integer id;

    /**
     * 用户基础表ID
     */
    private Integer userId;

    /**
     * 资讯文章ID
     */
    private Integer informationId;

    /**
     * 评论内容
     */
    private String content;

    /**
     * 评论时间
     */
    private Date time;

    /**
     * 标题
     */
    private String nvcTitle;

    /**
     * 1、资讯    2、视频
     */
    private Integer iType;

    /**
     * 从 内容里 提取的 图片 集合  保存一条或者三条 图片地址
     */
    private String nvcImagesArray;

    /**
     * 上传文件 视频地址
     */
    private String nvcUploadFile;

}
