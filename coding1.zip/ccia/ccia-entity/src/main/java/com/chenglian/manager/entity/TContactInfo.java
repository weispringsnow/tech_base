package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 *
 * </p>
 *
 * @author weicx
 * @since 2019-11-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TContactInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_ci_identifier", type = IdType.AUTO)
    private Integer iCiIdentifier;

    /**
     * 用户ID
     */
    private Integer iUserIdentifier;

    /**
     * 联系人
     */
    private String nvcContact;

    /**
     * 部门
     */
    private String nvcDepartment;

    /**
     * 职务
     */
    private String nvcPost;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 电话
     */
    private String nvcPhone;

    /**
     * 传真
     */
    private String nvcFax;

    /**
     * 邮箱
     */
    private String nvcEmail;

    /**
     * 是否第一联系人(1是/0否)
     */
    private Boolean isFistContact;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

    /**
     * 是否前台显示（1是、0否）
     */
    private Boolean isShow;

    /**
     * 微信
     */
    private String weChat;

}
