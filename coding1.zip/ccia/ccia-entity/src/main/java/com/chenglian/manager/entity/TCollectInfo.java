package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-12-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TCollectInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_ci_identifier", type = IdType.AUTO)
    private Integer iCiIdentifier;

    /**
     * 用户ID
     */
    private Integer iUserIdentifier;

    /**
     * 收藏企业
     */
    private Integer iColectCompany;

    /**
     * 收藏时间
     */
    private Date dtCollectTime;

    /**
     * 收藏数据ID
     */
    private Integer iCdIdentifier;

    /**
     * 登录来源(1Android/2iOS)
   
     */
    private String nvcLoginResourse;

}
