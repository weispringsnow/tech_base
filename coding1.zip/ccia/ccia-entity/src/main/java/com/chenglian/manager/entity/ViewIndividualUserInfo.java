package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.chenglian.common.entity.OutParams;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewIndividualUserInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 用户ID
     */
    private Integer iBuIdentifier;

    /**
     * 用户名
     */
    private String nvcLoginName;

    /**
     * 责任人ID
     */
    private Integer iRiIdentifier;

    /**
     * 注册时间
     */
    private Date dtResignTime;

    /**
     * 最近登录时间
     */
    private Date dtLatestLoginTime;

    /**
     * 姓名
     */
    private String nvcName;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 所属企业
     */
    private String nvcBelongCompany;

    /**
     * 绑定企业ID
     */
    private Integer iUiIdentifierBind;

    /**
     * 是否删除(1是/-1否)
     */
    private Boolean isDelete;

    /**
     * 标识
     */
    private Integer iIuiIdentifier;

    /**
     * 登录来源(1Android/2iOS)
     */
    private Integer iLoginResourse;

    /**
     * 密码(MD5)
     */
    private String nvcPasswordMd5;

    /**
     * 密码(DES)
     */
    private String nvcPasswordDes;

    /**
     * 协会会员0否1是
     */
    private Boolean isAssociateMember;


    /**
     * 是否挂图0否1是
     */
    private Boolean isWallMap;

    /**
     * 最近跟踪记录时间
     */
    private Date dtLatestFollowTime;


    /**
     * 协会会员编码
     */
    private String associateCode;

    /**
     * 协会会员对应的名字
     */
    private String associateName;

    private String nvcLoginResourse;

    private Integer iRegisterSource;


    @TableField(exist = false)
    private OutParams outParams;
    @TableField(exist = false)
    private Integer order;
    @TableField(exist = false)
    private Integer iRiIdentifierBefore;
    @TableField(exist = false)
    private Boolean isEq;

    @TableField(exist = false)
    private String associateCode1;
    @TableField(exist = false)
    private String associateCode2;

    public String[] getAssociateCodeStrs() {
        String[] strings = new String[2];
        if (StringUtils.isNotBlank(associateCode)) {
            String[] split = associateCode.split("-");
            if (split != null && split.length == 2) {
                strings = split;
            }
        }
        return strings;
    }

    @TableField(exist = false)
    private String loginSource;

    /**
     * 获取平台登录来源
     * 登录来源平台
     * 登录来源
     */
    public String getLoginSource() {
        String str = "";
        if (StringUtils.isNotBlank(nvcLoginResourse)) {
            String[] strings = nvcLoginResourse.split(",");
            if (strings != null && strings.length > 0) {
                for (String s : strings) {
                    if (s.equals("1")) {
                        str += "PC端、";
                    }
                    if (s.equals("2")) {
                        str += "andriod端、";
                    }
                    if (s.equals("3")) {
                        str += "IOS端、";
                    }
                }
            }
            if (str.length() >= 1) {
                str = str.substring(0, str.length() - 1);
            }
        }
        return str;
    }

    @TableField(exist = false)
    private String resisterSource;

    /**
     * 获取平台注册来源
     * 平台注册来源编号
     */
    public String getResisterSource() {
        String str = "";
        iRegisterSource = iRegisterSource == null ? 0 : iRegisterSource;
        if (iRegisterSource == 21) {
            return "陶瓷名录Android";
        } else if (iRegisterSource == 22) {
            return "陶瓷名录IOS";
        } else if (iRegisterSource == 23) {
            return "PC前台";
        } else if (iRegisterSource == 24) {
            return "PC后台";
        } else if (iRegisterSource == 41) {
            return "陶瓷礼购Android";
        } else if (iRegisterSource == 42) {
            return "陶瓷礼购IOS";
        } else if (iRegisterSource == 43) {
            return "陶瓷礼购PC前台";
        } else if (iRegisterSource == 44) {
            return "陶瓷礼购PC后台";
        }
        return str;
    }

}
