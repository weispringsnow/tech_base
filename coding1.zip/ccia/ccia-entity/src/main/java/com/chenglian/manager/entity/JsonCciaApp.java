package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * CCIA-App 返回JSON
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class JsonCciaApp {

    public JsonCciaApp() {
    }

    public JsonCciaApp(String status) {
        this.status = status;
    }

    public JsonCciaApp(String status, String msg) {
        this.status = status;
        this.msg = msg;
    }

    public JsonCciaApp(String status, String msg, Object data) {
        this.status = status;
        this.msg = msg;
        this.data = data;
    }
    public JsonCciaApp(String status, String msg, IPage page) {
        this.status = status;
        this.msg = msg;
        this.data = page;
        this.data = page;
        this.isEnd = !((Page)page).hasNext();
        this.totalCount = page.getTotal();
    }

    public JsonCciaApp(String status, String msg, Object data, IPage page) {
        this.status = status;
        this.msg = msg;
        this.data = data;
        this.isEnd = !((Page)page).hasNext();
        this.totalCount = page.getTotal();
    }

    public static String ERROR = "error";
    public static String SUCCESS = "success";

    // 返回状态
    public String status;
    // 返回消息
    public String msg;
    /// Json数据
    /// 注：data 传递集合数据
    public Object data;
    // 总数
    public long totalCount;
    //是否最后一条
    public boolean isEnd;
}
