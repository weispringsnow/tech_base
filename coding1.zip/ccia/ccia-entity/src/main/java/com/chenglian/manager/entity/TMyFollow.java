package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2020-03-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TMyFollow implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 用户关注表ID(官网APP)
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户基础表ID(关注者)
     */
    private Integer userId;

    /**
     * 用户基础表ID(被关注者)
     */
    private Integer followId;

    /**
     * 关注时间
     */
    private Date followTime;

}
