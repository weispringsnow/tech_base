package com.chenglian.manager.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class JsonModel {

    public JsonModel() {
    }

    public JsonModel(String status, String msg) {
        this.status = status;
        this.msg = msg;
    }

    public JsonModel(String status, String msg, Object data) {
        this.status = status;
        this.msg = msg;
        this.data = data;
    }

    public static String ERROR = "error";
    public static String SUCCESS = "success";
    public static String END = "end";

    public String status;
    public String msg;
    /// Json数据
    /// 注：data 传递集合数据
    public Object data;
}
