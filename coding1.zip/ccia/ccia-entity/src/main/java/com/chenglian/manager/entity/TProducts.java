package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-11-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TProducts implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    @TableId(value = "i_identifier", type = IdType.AUTO)
    private Integer iIdentifier;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 产品一级ID
     */
    private Integer iGfIdentifier;

    /**
     * 产品二级ID
     */
    private Integer iGsIdentifier;

    /**
     * 产品名称
     */
    private String nvcProductName;

    /**
     * 品牌ID
     */
    private Integer iBiIdentifier;

    /**
     * 产品图片
     */
    private String nvcGoodsPicture;

    /**
     * 产地省ID
     */
    private Integer iPIdentifier;

    /**
     * 产地市ID
     */
    private Integer iCIdentifier;

    /**
     * 产地区县ID
     */
    private Integer iCoIdentifier;

    /**
     * 参数
     */
    private String nvcParameter;

    private String nvcMode;

    private String nvcPhysicalIndex;

    private String nvcChemicalIndex;

    /**
     * 价格
     */
    private BigDecimal dPrice;

    /**
     * 详情
     */
    private String nvcDetail;

    /**
     * 联系方式ID
     */
    private Integer iCiIdentifier;

    /**
     * 联系人
     */
    private String nvcContacts;

    /**
     * 电话
     */
    private String nvcPhone;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 发布时间
     */
    private Date dtReleaseTime;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

    private Integer iState;

    /**
     * 产品类型(1设备/2原辅料/3陶瓷产品)
     */
    private Integer iProductType;

    private String nvcUnit;

    private Integer iViewNumber;

}
