package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-11-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TEditionRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_er_identifier", type = IdType.AUTO)
    private Integer iErIdentifier;

    /**
     * 版本号
     */
    private String nvcNumber;

    /**
     * 更新时间
     */
    private Date dtUpdateTime;

    /**
     * 应用途径(1Android 2IOS 3PC)
     */
    private Integer iApplication;

    /**
     * 更新内容
     */
    private String nvcContent;

    @TableField(exist = false)
    private String orderStr;

}
