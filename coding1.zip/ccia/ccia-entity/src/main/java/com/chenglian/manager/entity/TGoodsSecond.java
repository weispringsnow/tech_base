package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * <p>
 *
 * </p>
 *
 * @author wla
 * @since 2019-11-15
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TGoodsSecond implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_gs_identifier", type = IdType.AUTO)
    private Integer iGsIdentifier;

    /**
     * 产品一级ID
     */
    private Integer iGfIdentifier;

    /**
     * 产品二级
     */
    private String nvcGoodsSecondName;

    /**
     * 首写字母
     */
    private String nvcFirstLetter;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

}
