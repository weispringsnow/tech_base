package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-12-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewCollectInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    private Integer iCiIdentifier;

    /**
     * 用户ID
     */
    private Integer iUserIdentifier;

    /**
     * 收藏企业
     */
    private Integer iColectCompany;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    /**
     * 用户ID
     */
    private Integer iBuIdentifier;

    /**
     * 地址
     */
    private String nvcAddress;

    /**
     * 是否推广
     */
    private String nvcExtension;

    /**
     * 企业logo
     */
    private String nvcCompanyLogo;

    /**
     * 收藏时间
     */
    private Date dtCollectTime;

    /**
     * 会员编号
     */
    private Integer iMemberNumber;

    /**
     * 企业类型ID
     */
    private Integer iCtiIdentifier;

    /**
     * 企业类型名称
     */
    private String nvcCompanyTypeName;

    /**
     * 产品类型数组
     */
    private String dictErpCategory;

    @TableField(exist = false)
    private String mainProducts;
    @TableField(exist = false)
    private String nvcExtensionExist;
    @TableField(exist = false)
    private Integer iMemberNumberExist;


}
