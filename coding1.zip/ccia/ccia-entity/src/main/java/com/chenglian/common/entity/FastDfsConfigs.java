package com.chenglian.common.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@EqualsAndHashCode(callSuper = false)
@Component
@ConfigurationProperties(prefix = "fast-dfs")
public class FastDfsConfigs {
    private String charset;
    private String connect_timeout_in_second;
    private String network_timeout_in_seconds;
    private String http_tracker_http_port;
    private String http_anti_steal_token;
    private String tracker_servers;
    private String fastdfsUrl;
    private String storageServiceIp;
    private Integer storageServicePort;
    private Integer storageServicePathIndex;
}
