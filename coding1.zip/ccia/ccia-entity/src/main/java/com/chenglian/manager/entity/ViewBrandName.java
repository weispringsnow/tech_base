package com.chenglian.manager.entity;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-11-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewBrandName implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 品牌名称
     */
    private String nvcBrandName;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

}
