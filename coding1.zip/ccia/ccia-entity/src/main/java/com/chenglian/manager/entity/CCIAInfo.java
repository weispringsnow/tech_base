package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-12-13
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("CCIAInfo")
public class CCIAInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "Identifier", type = IdType.AUTO)
    private Integer Identifier;

    @TableField("UpdateTime")
    private Date UpdateTime;

    // 200000 + 资讯id
    @TableField("TheState")
    private Integer TheState;

    @TableField("InfoTitle")
    private String InfoTitle;

    @TableField("InfoType")
    private Integer InfoType;

    @TableField("InfoContent")
    private String InfoContent;

    @TableField("InfoReleaseTime")
    private Date InfoReleaseTime;

    @TableField("KeyWords")
    private String KeyWords;

    @TableField("PicPath")
    private String PicPath;

    @TableField("SubInfoType")
    private Integer SubInfoType;

    @TableField("Is_IndustryFocus")
    private Boolean isIndustryfocus;

    /**
     * 标题是否加粗
     */
    @TableField("is_titleThickening")
    private Boolean isTitlethickening;

    /**
     * 标题是否标红
     */
    @TableField("is_redTitle")
    private Boolean isRedtitle;

    /**
     * 行业聚焦排序字段

     */
    @TableField("i_industryFocusSort")
    private Integer iIndustryfocussort;

}
