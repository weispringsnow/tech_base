package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TPurchaseInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_pi_identifier", type = IdType.AUTO)
    private Integer iPiIdentifier;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 产品一级ID
     */
    private Integer iGfIdentifier;

    /**
     * 产品二级ID
     */
    private Integer iGsIdentifier;

    /**
     * 产品名称
     */
    private String nvcGoodsName;

    /**
     * 物理指标
     */
    private String nvcPhysicalIndex;

    /**
     * 化学指标
     */
    private String nvcChemicalIndex;

    /**
     * 月用量
     */
    private String nvcMonthUsed;

    /**
     * 采购类型ID
     */
    private Integer iPtIdentifier;

    /**
     * 发布时间
     */
    private Date dtReleaseTime;

    /**
     * 截止时间
     */
    private Date dtOverTime;

    /**
     * 详情
     */
    private String nvcDetail;

    /**
     * 联系方式ID
     */
    private Integer iCiIdentifier;

    /**
     * 联系人
     */
    private String nvcContacts;

    /**
     * 电话
     */
    private String nvcPhone;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 查看权限
     */
    private Integer iLevel;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

    /**
     * 审核状态(1不通过)
     */
    private Integer iState;

    /**
     * 图片
     */
    private String nvcImage;

    private Integer iViewNumber;
}
