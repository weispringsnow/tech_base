package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.chenglian.common.constant.VipLevel;
import com.chenglian.common.entity.OutParams;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-11-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewUserInfoManager implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 企业会员类型(Vip/黄金会员 字典引用静态里面的VipLevel) 原所选服务,现所选服务对多关系放服务表了
     */
    private String nvcServise;

    public String getNvcServiseShow() {
        if (VipLevel.VIP.equals(nvcServise)) return "VIP会员";
        if (VipLevel.GOLD.equals(nvcServise)) return "黄金会员";
        return "普通会员及其他";
    }

    /**
     * 是否不在前台显示（1不显示  0显示   null显示）
     */
    private Boolean isNotShowFront;

    /**
     * 是否后台注册
     */
    private Boolean isRegisteredBack;


    /**
     * 产品类型数组
     */
    private String dictErpCategory;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    /**
     * 标识
     */
    private Integer iUiIdentifier;

    /**
     * 用户ID
     */
    private Integer iBuIdentifier;

    /**
     * 企业logo
     */
    private String nvcCompanyLogo;

    /**
     * 企业类型ID
     */
    private Integer iCtiIdentifier;

    /**
     * 经营模式ID
     */
    private Integer iMmIdentifier;

    /**
     * 省ID
     */
    private Integer iPIdentifier;

    /**
     * 市ID
     */
    private Integer iCIdentifier;

    /**
     * 区县ID
     */
    private Integer iCoIdentifier;

    /**
     * 地址
     */
    private String nvcAddress;

    /**
     * 邮编
     */
    private String nvcPostcode;

    /**
     * pc网址
     */
    private String nvcWebsite;

    /**
     * 手机版网址
     */
    private String nvcPhoneWebsite;

    /**
     * 微官网二维码
     */
    private String nvcWechat;

    /**
     * 简介
     */
    private String nvcAbstract;

    /**
     * 销量
     */
    private String nvcSalesVolume;

    /**
     * 产值
     */
    private Double fOutput;

    /**
     * 年收入额
     */
    private Double fYearIncome;

    /**
     * 推荐序号，>0表示是推荐
     */
    private Integer iRecomendSort;

    /**
     * 潜在客户等级
     */
    private String nvcLevel;

    /**
     * 是否推广
     */
    private String nvcExtension;

    /**
     * 更新时间
     */
    private Date dtUpdateTime;

    /**
     * 注册时间
     */
    private String nvcRegisterTime;

    /**
     * 注册资本
     */
    private String fRegisterMoney;

    /**
     * 最近跟踪记录时间
     */
    private Date dtLatestFollowTime;

    /**
     * 责任人ID
     */
    private Integer iRiIdentifier;

    /**
     * 会员编号
     */
    private Integer iMemberNumber;

    /**
     * 产量
     */
    private BigDecimal dYield;

    /**
     * 生产线
     */
    private Integer iProductLine;

    /**
     * 单位
     */
    private String nvcUnit;

    /**
     * 用户名
     */
    private String nvcLoginName;

    /**
     * 法人
     */
    private String nvcLegalPerson;

    /**
     * 登录来源(1Android/2iOS)
     */
    private Integer iLoginResourse;

    /**
     * 注册时间
     */
    private Date dtResignTime;

    /**
     * 最近登录时间
     */
    private Date dtLatestLoginTime;

    /**
     * 密码(DES)
     */
    private String nvcPasswordDes;

    /**
     * 协会会员0否1是
     */
    private Boolean isAssociateMember;

    /**
     * 是否挂图0否1是
     */
    private Boolean isWallMap;

    /**
     * 来源平台（1：名录；2：礼购；） 表示在哪儿登陆过，多个来源用 逗号隔开
     */
    private String nvcLoginResourse;

    /**
     * 注册来源（1陶瓷大师、2陶瓷名录、3陶瓷快讯、4陶瓷礼购、5陶瓷会刊、6银兴陶）
     */
    private Integer iRegisterSource;

    /**
     * 协会会员编码
     */
    private String associateCode;

    /**
     * 协会会员对应的名字
     */
    private String associateName;

    /**
     * 地图坐标X
     */
    private String amapX;

    /**
     * 地图坐标Y
     */
    private String amapY;
    /**
     * 浏览量
     */
    private Integer iViewNumber;

    /**
     * 收藏量
     */
    private Integer iCollectNumber;

    /**
     * 银兴陶ID
     */
    private Integer yxtId;

    /**
     * 国际站ID
     */
    private Integer winId;


    @TableField(exist = false)
    private Integer order;
    @TableField(exist = false)
    private OutParams outParams;


    @TableField(exist = false)
    private String nvcResponsible;
    @TableField(exist = false)
    private String mainProducts;

    //联系人相关信息
    @TableField(exist = false)
    private String nvcContact;
    @TableField(exist = false)
    private String nvcMobile;
    @TableField(exist = false)
    private String nvcPhone;
    @TableField(exist = false)
    private String nvcBrandName;
    @TableField(exist = false)
    private String nvcService;
    @TableField(exist = false)
    private String provinceCityCounty;
    @TableField(exist = false)
    private Integer iRiIdentifierBefore;
    @TableField(exist = false)
    private Boolean isEq;
    @TableField(exist = false)
    private String nvcExtensionExist;
    @TableField(exist = false)
    private Integer iMemberNumberExist;

    @TableField(exist = false)
    private Integer iProductLineGT0;
    @TableField(exist = false)
    private Integer dYieldGT0;
    @TableField(exist = false)
    private Integer fOutputGT0;

    // 登录来源(用于生成xls)
    @TableField(exist = false)
    private String resisterSource;
    // ids(用于生成xls)
    @TableField(exist = false)
    private String ids;
    // 平台注册来源xls
    @TableField(exist = false)
    private String loginSource;
    @TableField(exist = false)
    private String loginSourc1e;



    /**
     * 获取平台登录来源
     * 登录来源平台
     * 登录来源
     */
    public String getLoginSource() {
        String str = "";
        if (StringUtils.isNotBlank(nvcLoginResourse)) {
            String[] strings = nvcLoginResourse.split(",");
            if (strings != null && strings.length > 0) {
                for (String s : strings) {
                    if (s.equals("1")) {
                        str += "PC端、";
                    }
                    if (s.equals("2")) {
                        str += "andriod端、";
                    }
                    if (s.equals("3")) {
                        str += "IOS端、";
                    }
                }
            }
            if (str.length() >= 1) {
                str = str.substring(0, str.length() - 1);
            }
        }
        return str;
    }


    /**
     * 获取平台注册来源
     * 平台注册来源编号
     */
    public String getResisterSource() {
        String str = "";  // 截至2020.3.21:有9287个  0  没有的
        iRegisterSource = iRegisterSource == null ? 0 : iRegisterSource;
        if (iRegisterSource == 21) {
            return "陶瓷名录Android";
        } else if (iRegisterSource == 22) {
            return "陶瓷名录IOS";
        } else if (iRegisterSource == 23) { // 截至2020.3.21:有5572个
            return "PC前台";
        } else if (iRegisterSource == 24) { // 截至2020.3.21:有16336个
            return "PC后台";
        } else if (iRegisterSource == 41) {// 截至2020.3.21:有1个
            return "陶瓷礼购Android";
        } else if (iRegisterSource == 42) {//截至2020.3.21:有1个
            return "陶瓷礼购IOS";
        } else if (iRegisterSource == 43) {
            return "陶瓷礼购PC前台";
        } else if (iRegisterSource == 44) { //截至2020.3.21:有7个
            return "陶瓷礼购PC后台";
        } else if (iRegisterSource == 11) {
            return "陶瓷官网Android";
        } else if (iRegisterSource == 12) {
            return "陶瓷官网IOS";
        }
        return str;
    }


}
