package com.chenglian.manager.entity;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author zxq
 * @since 2019-11-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewMapAdv implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer iMaIdentifier;

    private Boolean isDelete;

    private Integer iMtIdentifier;

    private Integer iCompanyId;

    private String nvcAdvName;

    private String nvcAdvValue;

    private String nvcAdvUrl;

    private String nvcAdvSmallImage;

    private String nvcAdvBigImage;

    private Date dtAddTime;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

}
