package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-11-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("t_manager_special")
public class TManagerSpecial implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "i_sc_identifier", type = IdType.AUTO)
    private Integer iScIdentifier;

    private String scName;

    private String scImages;

    private String scChannel;

    private Integer scPlace;

    private Boolean scHide;

    private Integer titleCount;

    private Date dtTime;

    /**
     * 专题用途(1app 2pc)
     */
    private Integer iUseType;

    private String nvcAppImage;

    @TableField(exist = false)
    private Integer wenzhangnum;

    @TableField(exist = false)
    private List<TContentInfo> tContactInfoList;
    @TableField(exist = false)
    private List<ViewManagerInformation> viewInfoList;




}
