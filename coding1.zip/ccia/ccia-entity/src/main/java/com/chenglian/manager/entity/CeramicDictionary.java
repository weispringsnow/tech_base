package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 陶瓷词典表
 * </p>
 *
 * @author wla
 * @since 2019-12-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class CeramicDictionary implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 上传时间
     */
    private Date updateTime;

    /**
     * 词条状态(1 通过 2 待审核 3 未通过)
     */
    private Integer state;

    /**
     * 中文释义
     */
    private String chineseName;

    /**
     * 英文释义
     */
    private String englishName;

    /**
     * 音标
     */
    private String phSymbol;

    /**
     * 关键词
     */
    private String keyWords;

    private Integer backUserId;

    @TableField(exist = false)
    private String searchText;

}
