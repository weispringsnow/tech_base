package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * VIEW
 * </p>
 *
 * @author wla
 * @since 2019-12-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewOpenService implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    private Integer iOsIdentifier;

    /**
     * 服务类型(1/名录会员2/关键字推广3/企业推荐4/品牌推广)
     */
    private Integer iServiceType;

    /**
     * 服务内容
     */
    private String nvcServiceContent;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    /**
     * 姓名
     */
    private String nvcName;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 回复状态(1是/0否)
     */
    private Boolean isReply;

    /**
     * 责任人
     */
    private String nvcResponsible;

    /**
     * 回复内容
     */
    private String nvcFeedContent;

    /**
     * 来源
     */
    private Integer iLoginSource;

    /**
     * 时间
     */
    private Date dtTime;

    /**
     * 用户ID
     */
    private Integer iBuIdentifier;

    /**
     * 用户名
     */
    private String nvcBuName;

    // 查询时间用
    @TableField(exist = false)
    private Date bgTime;
    @TableField(exist = false)
    private Date edTime;
}