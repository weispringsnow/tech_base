package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author wla
 * @since 2019-11-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("t_manager_advertisement")
public class TManagerAdvertisement implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_ma_identifier", type = IdType.AUTO)
    private Integer iMaIdentifier;

    /**
     * 企业名称
     */
    private String nvcCompany;

    /**
     * 服务内容ID
     */
    private Integer iServiceId;

    /**
     * 开始时间
     */
    private Date dtStartTime;

    /**
     * 结束时间
     */
    private Date dtEndTime;

    /**
     * 图片路径
     */
    private String nvcImage;

    /**
     * 链接
     */
    private String nvcLink;

    /**
     * 位置
     */
    private String nvcPosition;

    /**
     * 频道ID
     */
    private Integer iChannelId;

    /**
     * 资讯管理ID
     */
    private Integer iMiIdentifier;

    /**
     * 栏目
     */
    private String nvcColumn;

    /**
     * 责任人
     */
    private Integer iResponsibleIdentifier;

    /**
     * 金额
     */
    private BigDecimal dCharge;

    /**
     * 办理入
     */
    private String nvcName;

    /**
     * 广告类型(1启动页2轮播页)
     */
    private Integer iAdType;

    /**
     * 所属专题显示产品编号
     */
    private String nvcProjectNum;

    /**
     * 上传时间
     */
    private Date dtUploadTime;

    // 在有效时间内
    @TableField(exist = false)
    private Boolean inValuableTime;
    // 排序
    @TableField(exist = false)
    private String orderStr;
}
