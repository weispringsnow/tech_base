package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 会刊收藏表(官网APP)
 * </p>
 *
 * @author wla
 * @since 2020-03-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TCollectionMagazineRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 会刊收藏表ID(陶瓷官网APP)
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户基础表ID
     */
    private Integer userId;

    /**
     * 会刊ID
     */
    private Integer magazineId;

    /**
     * 会刊期数
     */
    private Integer magazineNum;

    /**
     * 栏目
     */
    private String column;

    /**
     * 标题
     */
    private String title;

    /**
     * 页码
     */
    private Integer page;

    /**
     * 收藏时间
     */
    private Date cTime;

    /**
     * 收藏来源(1Android/2iOS)
     */
    private Integer cSource;

}
