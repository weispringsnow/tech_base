package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 后台部门管理字典表
 * </p>
 *
 * @author weicx
 * @since 2019-11-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TBackManage implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识列ID
     */
    @TableId(value = "i_bm_identifier", type = IdType.AUTO)
    private Integer iBmIdentifier;

    /**
     * 业务员所在部门
     */
    private String nvcDepartmentName;

    /**
     * 排序
     */
    private Integer iSort;

}
