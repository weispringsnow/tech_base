package com.chenglian.common.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TBanWord implements Serializable {
    private int iBwIdentifier;
    // 禁止词汇
    private String nvcWordContent;
    // 提示内容
    private String nvcCueContent;

    public static List<TBanWord> getBanWord() {
        List<TBanWord> list = new ArrayList<>();
        StringBuffer sb = new StringBuffer();
        sb.append("最,第一,唯一,NO1,TOP1,独一无二,一流 ,一天,仅此一次,仅此一款,最后一波,大品牌之一,销冠,");
        sb.append("国家级,国际级,世界级,千万级,百万级,星级,5A,甲级,");
        sb.append("顶级,高级,极品,极佳,绝对,终极,极致,致极,极具,完美,绝佳,极佳,至,臻品,臻致,臻席,压轴,问鼎,空前,绝后,绝版,无双,非此莫属,巅峰,前所未有,无人能及,");
        sb.append("顶级,鼎级,鼎冠,定鼎,完美,翘楚之作,不可再生,不可复制,绝无仅有,寸土寸金,淋漓尽致,无与伦比,唯一,卓越,卓著,");
        sb.append("前无古人后无来者,绝版,珍稀,臻稀,稀少,绝无仅有,绝不在有,稀世珍宝,千金难求,世所罕见,不可多得,空前绝后,寥寥无几,屈指可数,史无前例,");
        sb.append("独家,独创,独据,开发者,缔造者,创始者,发明者,");
        sb.append("首个,首选,独家,首发,首席,首府,首选,首屈一指,全国首家,国家领导人,国门,国宅,首次,填补国内空白,国际品质,");
        sb.append("大牌,金牌,名牌,王牌,领先上市,巨星,著名,掌门人,领袖品牌,至尊,冠军,皇家,");
        sb.append("世界领先,遥遥领先,领导者,领袖,引领,创领,领航,耀领,");
        sb.append("牌,至尊,冠军,皇家,");
        sb.append("世界领先,遥遥领先,领导者,领袖,引领,创领,领航,耀领,");
        sb.append("特供,专供,专家推荐,领导人推荐,专家推荐,人民币");
        String[] split = sb.toString().split(",");
        int i = 0;
        for (String item : split) {
            i++;
            list.add(new TBanWord().setIBwIdentifier(i).setNvcWordContent(item).setNvcCueContent((item == "大品牌之一") ? "存在禁用词汇[xx大品牌之一]" : "存在禁用词汇[" + item + "]"));
        }
        return list;
    }
}