package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2020-03-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TVersionRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 官网APP版本更新ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 提醒
     */
    private String notice;

    /**
     * 是否强制更新?
     */
    private Boolean isForced;

    /**
     * 版本号
     */
    private String number;

    /**
     * 更新系统类型，2 android 3 ios
     */
    private Integer source;

    /**
     * 下载地址
     */
    private String download;

    /**
     * 责任人ID
     */
    private Integer responsibleId;

    /**
     * 产品名称
     */
    private String projectName;

    /**
     * 更新时间
     */
    private Date updateTime;

}
