package com.chenglian.manager.entity;
import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TServiceInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_si_identifier", type = IdType.AUTO)
    private Integer iSiIdentifier;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 所选服务ID
     */
    private Integer iScIdentifier;

    /**
     * 开始时间
     */
    private Date dtBeginTime;

    /**
     * 结束时间
     */
    private Date dtOverTime;

    /**
     * 付费金额
     */
    private BigDecimal dPayAmount;

    /**
     * 开通年限
     */
    private Integer iOpenPeriod;

    /**
     * 办理人员
     */
    private String nvcHandlePerson;

    /**
     * 责任人ID
     */
    private Integer iRiIdentifier;

    /**
     * 是否删除(1是/-1否)
     */
    private Boolean isDelete;

    /**
     * VIP会员---会员编号
     */
    private Integer iMemberNumber;

    /**
     * 推广Json
     */
    private String nvcExtension;

}
