package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 *
 * </p>
 *
 * @author wla
 * @since 2019-12-07
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TFeedBack implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识(意见反馈-pc官网的反馈)
     */
    @TableId(value = "i_fb_identifier", type = IdType.AUTO)
    private Integer iFbIdentifier;

    /**
     * 用户ID
     */
    private Integer iUserIdentifier;

    /**
     * 来源(1Andriod / 2IOS) 暂时无效
     */
    private Integer nvcSource;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 意见内容/音频路径
     */
    private String nvcOpinionContent;

    /**
     * 提交时间
     */
    private Date dtUploadTime;

    /**
     * 回复内容
     */
    private String nvcFeedContent;

    /**
     * 回复时间
     */
    private Date dtFeedTime;

    /**
     * 回复状态(1是/-1否)
     */
    private Boolean isReply;

    /**
     * 是否是语音(1是/-1否)
     */
    private Boolean isVoice;

    /**
     * 通话时长
     */
    private Integer iCallDuration;

    /**
     * 是否删除(1是/-1否)
     */
    private Boolean isDelete;

    /**
     * 反馈类型标识
     */
    private Integer iFtIdentifier;

    /**
     * 责任人标识
     */
    private Integer iRiIdentifier;

    /**
     * 反馈者姓名
     */
    private String nvcResponderName;
    /**
     * 反馈图片(,分隔)
     */
    private String pics;

    // 获取图片数组
    public String[] getPicArray() {
        String[] pic = {};
        if (StringUtils.isBlank(pics)) {
            return pic;
        }
        return pics.split(",");
    }

    public String getPicFirst() {
        if (StringUtils.isBlank(pics)) {
            return "";
        }
        String[] strings = pics.split(",");
        if (strings.length <= 0) {
            return "";
        }
        return strings[0];
    }
}
