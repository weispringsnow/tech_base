package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-11-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TMagagementModel implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_mm_identifier", type = IdType.AUTO)
    private Integer iMmIdentifier;

    /**
     * 经营模式
     */
    private String nvcManagementType;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

}
