package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 陶瓷书店表
 * </p>
 *
 * @author wla
 * @since 2019-11-23
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class Bookstore implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 陶瓷书店ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 标题(唯一)
     */
    private String title;

    /**
     * 作者(关键词)
     */
    private String author;

    /**
     * 出版社
     */
    private String press;

    /**
     * 定价
     */
    private String price;

    /**
     * 出版时间
     */
    private Date publishDate;

    /**
     * 封面图片
     */
    private String picture;

    /**
     * 简介
     */
    private String introduction;

}
