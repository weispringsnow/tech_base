package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-11-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TTypeRecommendManagement implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_trm_identifier", type = IdType.AUTO)
    private Integer iTrmIdentifier;

    /**
     * 位置
     */
    private Integer iRate;

    /**
     * 标题
     */
    private String nvcTitle;

    /**
     * 分类ID
     */
    private Integer iTrIdentifier;

    /**
     * 是否前台显示(1是/-1否)
     */
    private Boolean isShow;

    /**
     * 是否显示数据列
     */
    private Boolean isDataShow;

    /**
     * 上传时间
     */
    private Date dtUploadTime;

    /**
     * 点击量
     */
    private Integer iClickNumber;

    /**
     * 是否删除(1是/-1否)
     */
    private Boolean isDelete;

    /**
     * 图片地址
     */
    private String nvcImage;

    /**
     * 单位
     */
    private String nvcUnit;

    /**
     * 自定义排序和限制行数
     * 举例：order by d_time desc limit 1
     */
    @TableField(exist = false)
    private String orderAndLimieStr;

}
