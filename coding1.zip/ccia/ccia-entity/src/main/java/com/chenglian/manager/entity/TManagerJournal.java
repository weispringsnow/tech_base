package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-11-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("t_manager_journal")
public class TManagerJournal implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_mj_identifier", type = IdType.AUTO)
    private Integer iMjIdentifier;

    /**
     * 杂志期数
     */
    private Integer iMagazineNum;

    /**
     * 年
     */
    private Integer iYear;

    /**
     * 月
     */
    private Integer iMonth;

    /**
     * 上传文件
     */
    private String nvcUploadFile;

    /**
     * 上传时间
     */
    private Date nvcUploadTime;

    /**
     * 上传人ID
     */
    private Integer uploadPersonId;

    /**
     * 是否删除(1是 / 0否)
     */
    private Boolean isDelete;

    /**
     * 是否前台显示(1是 / 0否)
     */
    private Boolean isVisible;

    /**
     * 来源产品编号
     */
    private String nvcProjectNum;

    /**
     * 导读
     */
    private String nvcAbstract;
    /**
     * 导读
     */
    private String picture;
    /**
     * 同步至APP(1是/0否)
     */
    private Boolean syncApp;

}
