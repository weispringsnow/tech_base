package com.chenglian.manager.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 点赞表(官网APP)
 * </p>
 *
 * @author wla
 * @since 2020-03-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TPraiseRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 点赞表ID(官网APP)
     */
    private Integer id;

    /**
     * 点赞类型(1资讯/2评论)
     */
    private Integer type;

    /**
     * 用户基础表ID
     */
    private Integer userId;

    /**
     * 内容ID(资讯ID或评论ID)
     */
    private Integer dataId;

    /**
     * 点赞时间
     */
    private Date time;

    //"您赞了这篇文章"
    @TableField(exist = false)
    private String praise;
    // "用户名:评论内容"
    @TableField(exist = false)
    private String assess;

    // information 信息
    @TableField(exist = false)
    private String title;
    @TableField(exist = false)
    private String nvcImagesArray;
    @TableField(exist = false)
    private String nvcUploadFile;
    @TableField(exist = false)
    private Integer infoType;

//     .net代码返回的部分内容
//    praise_time = DateTool.toString(item.dt_time),
//    assess = assess,
//    assess_time = DateTool.toString(item.nvc_time),
//    mi_id = item.i_mi_identifier,
//    title = item.nvc_title,
//    nvc_images_array = item.nvc_images_array ?? "",
//    nvc_upload_file = Commons.manInfo(item.i_mi_identifier).nvc_upload_file,
//    type = Commons.manInfo(item.i_mi_identifier).i_type == 1 ? 1 : 3


}
