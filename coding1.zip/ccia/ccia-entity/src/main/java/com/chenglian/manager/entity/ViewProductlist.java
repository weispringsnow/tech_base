package com.chenglian.manager.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author weicx
 * @since 2019-12-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ViewProductlist implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private Integer iIdentifier;

    /**
     * 品牌名称
     */
    private String nvcBrandName;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 产品图片
     */
    private String nvcGoodsPicture;

    /**
     * 参数
     */
    private String nvcParameter;

    /**
     * 价格
     */
    private BigDecimal dPrice;

    private Integer iState;

    /**
     * 详情
     */
    private String nvcDetail;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

    /**
     * 发布时间
     */
    private Date dtReleaseTime;

    /**
     * 省名称
     */
    private String nvcProvince;

    /**
     * 市名称
     */
    private String nvcCity;

    /**
     * 区县名称
     */
    private String nvcCounty;

    /**
     * 产品二级
     */
    private String nvcProductName;

    /**
     * 联系方式ID
     */
    private Integer iCiIdentifier;

    /**
     * 联系人
     */
    private String nvcContacts;

    /**
     * 电话
     */
    private String nvcPhone;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 产品一级ID
     */
    private Integer iGfIdentifier;

    /**
     * 产品二级ID
     */
    private Integer iGsIdentifier;

    private String nvcUnit;

    private String nvcChemicalIndex;

    private String nvcPhysicalIndex;

    // 规格型号
    private String nvcMode;

    /**
     * 产品类型(1设备/2原辅料/3陶瓷产品)
     */
    private Integer iProductType;

    /**
     * 企业名称
     */
    private String nvcCompanyName;

    /**
     * 省ID
     */
    private Integer iPIdentifier;

    /**
     * 市ID
     */
    private Integer iCIdentifier;

    /**
     * 区县ID
     */
    private Integer iCoIdentifier;

    /**
     * 品牌ID
     */
    private Integer iBiIdentifier;

    private Integer iViewNumber;

    public String getPriceStr() {
        if (dPrice != null && dPrice.doubleValue() > 0) {
            return dPrice + nvcUnit;
        } else {
            return "电联";
        }
    }

}
