package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 栏目简介表
 * </p>
 *
 * @author wla
 * @since 2019-11-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class ColumnDescription implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 栏目名称(a陶瓷设计-b陶瓷问诊-c陶瓷营销)
     */
    private String columnName;

    /**
     * 栏目简介
     */
    private String description;

    /**
     * 更新时间
     */
    private Date updateTime;

}
