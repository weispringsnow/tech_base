package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 *
 * </p>
 *
 * @author zxq
 * @since 2019-11-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TMapAdv implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "i_ma_identifier", type = IdType.AUTO)
    private Integer iMaIdentifier;

    private Integer iMtIdentifier;

    private Boolean isDelete;

    private Integer iCompanyId;

    private String nvcAdvName;

    private String nvcAdvValue;

    private String nvcAdvUrl;

    private String nvcAdvSmallImage;

    private String nvcAdvBigImage;

    private Date dtAddTime;

}
