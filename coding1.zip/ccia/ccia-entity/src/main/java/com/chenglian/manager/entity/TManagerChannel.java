package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.Date;
/**
 * <p>
 * 
 * </p>
 *
 * @author wla
 * @since 2019-11-14
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("t_manager_channel")
public class TManagerChannel implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_mc_identifier", type = IdType.AUTO)
    private Integer iMcIdentifier;

    /**
     * 频道
     */
    private String nvcName;

    /**
     * 是否前台显示(1是 / 0否)
     */
    private Boolean isVisible;

    /**
     * 排序
     */
    private Integer iSort;

    /**
     * 是否删除(1是 / 0否)
     */
    private Boolean isDelete;

    /**
     * 时间
     */
    private Date dtAddTime;

    public int getIMpIdentifier() {
        return 0;
    }
}
