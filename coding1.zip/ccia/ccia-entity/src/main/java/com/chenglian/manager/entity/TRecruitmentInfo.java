package com.chenglian.manager.entity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.util.Date;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
/**
 * <p>
 * 
 * </p>
 *
 * @author weicx
 * @since 2019-12-05
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
public class TRecruitmentInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 标识
     */
    @TableId(value = "i_ri_identifier", type = IdType.AUTO)
    private Integer iRiIdentifier;

    /**
     * 企业用户ID
     */
    private Integer iUiIdentifier;

    /**
     * 职位名称
     */
    private String nvcJobName;

    /**
     * 招聘人数
     */
    private String nvcRecruitmentNumber;

    /**
     * 性别要求(1男 / 2女 / 3不限)
     */
    private Integer iSex;

    /**
     * 学历要求(1本科 / 2专科 / 3不限)
     */
    private Integer nvcEducationRequirements;

    /**
     * 工作年限
     */
    private String nvcWorkYears;

    /**
     * 工作地区省ID
     */
    private Integer iPIdentifier;

    /**
     * 工作地区市ID
     */
    private Integer iCIdentifier;

    /**
     * 工作地区区县ID
     */
    private Integer iCoIdentifier;

    /**
     * 月薪
     */
    private String nvcMonthSalary;

    /**
     * 有效期
     */
    private Date dtValidityTime;

    /**
     * 职位描述
     */
    private String nvcJobDescription;

    /**
     * 详情
     */
    private String nvcJobDetail;

    /**
     * 联系方式ID
     */
    private Integer iCiIdentifier;

    /**
     * 联系人
     */
    private String nvcContacts;

    /**
     * 电话
   
     */
    private String nvcPhone;

    /**
     * 手机
     */
    private String nvcMobile;

    /**
     * 邮箱
     */
    private String nvcEmail;

    /**
     * 发布时间
     */
    private Date dtReleaseTime;

    /**
     * 是否删除(1是/0否)
     */
    private Boolean isDelete;

    /**
     * 审核状态(1不通过)
     */
    private Integer iState;

    /**
     * 图片
     */
    private String nvcImage;

}
